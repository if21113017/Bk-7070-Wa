<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
?>
<div class="row">
						  <div class="col-md-3">
							  <div class="card ">
								<div class="card-content">
										<?php
												/**										 
												* Cek apakah ada jadwal sekarang
												**/
												$tgl_nowAC_Toilet_32 = date("Y-m-d");
												$plut_num_32  = $_GET['plut_num_ac_32'];
												$sqlAC_Toilet_32 = "SELECT * FROM _tbl_jadwal WHERE tgl_berangkat='".$tgl_nowAC_Toilet_32."' AND status='0' AND kd_bus='AC' AND no_plat='".$plut_num_32."' ORDER BY id DESC";												
												$hAC_Toilet_32   = mysql_query($sqlAC_Toilet_32);												
												$adaAC_Toilet_32 = mysql_num_rows($hAC_Toilet_32);
												if($adaAC_Toilet_32 > 0){
														$rAC_Toilet_32   = mysql_fetch_array($hAC_Toilet_32);
														?>
															<script type="text/javascript">
																	$(document).ready(function(){																		
																				$("#tbl_Simpan_AC_32").attr("disabled", true);
																				$("#frmAC_Toilet_32 :input").attr("disabled", true);
																				$("#cetakSJAC_Toilet_32").attr("disabled", false);
																				$("#tiketMulti_ac32").attr("disabled", false);
																				
																				$("#cetakSJAC_Toilet_32").click(function(){																							
																					window.open('<?php echo $apps->setHost(printSJ.php); ?>?id='+<?php echo $rAC_Toilet_32['id']; ?>,'CetakSuratJalan', 'width=1080, height=800');
																					window.location.reload();																			
																				});
																	})
															</script>
														<?php
														
														$no_plat_AC_Toilet_32 	 = $rAC_Toilet_32['no_plat'];
														$nm_supir_AC_Toilet_32 	 = $rAC_Toilet_32['nm_supir'];
														$j_berangkat_AC_Toilet_32  = $rAC_Toilet_32['jam_berangkat'];
														$berangkat_AC_Toilet_32   = explode("-", $rAC_Toilet_32['tgl_berangkat']);
														$thn_AC_Toilet_32         = $berangkat_AC_Toilet_32[0];
														$bln_AC_Toilet_32         = $berangkat_AC_Toilet_32[1];
														$tglnya_AC_Toilet_32      = $berangkat_AC_Toilet_32[2];
														$t_berangkat_AC_Toilet_32 = $tglnya_AC_Toilet_32."/".$bln_AC_Toilet_32."/".$thn_AC_Toilet_32;
														$dari_AC_Toilet_32        = $rAC_Toilet_32['dari'];
														$tujuan_AC_Toilet_32      = $rAC_Toilet_32['tujuan'];
														
														$bisa_isi_tiket_ac32 = "md-trigger";
												}
												else{
														?>
															<script type="text/javascript">
																	$(document).ready(function(){
																		$("#cetakSJAC_Toilet_32").attr("disabled", true);
																		$("#tbl_Simpan_AC_32").attr("disabled", false);	
																		$("#tiketMulti_ac32").attr("disabled", true);
																		
																		$(".belum_ada_jadwal_ac32").click(function(){
																			alert("Belum ada jadwal!\nSilahkan isi Nomor Plat dan Nama Supir Bus terlebih dahulu");
																		});
																		
																	})
															</script>
														<?php
														$no_plat_AC_Toilet_32 		 = "";
														$nm_supir_AC_Toilet_32 	 = "";
														$j_berangkat_AC_Toilet_32 = $jam_sekarang;
														$t_berangkat_AC_Toilet_32 = $tgl_sekarang;
														$dari_AC_Toilet_32        = "";
														$tujuan_AC_Toilet_32      = "";
														$bisa_isi_tiket_ac32 	  = "belum_ada_jadwal_ac32";
												}
												
												
										?>
									  <table id="tg-VbtHW" style="width: 210px;">
										  <tr>
											<th colspan="2"><center></center></th>
											<th rowspan="10"></th>
											<th colspan="2">
												<center>
													<img src="assets/img/supir.png" style="width: 30px; padding-bottom: 7px;" />
												</center>
											</th>
										  </tr>										  
										  <tr>
											<th colspan="2" style="text-align: center;">KERNET</th>
											<th  colspan="2" style="text-align: center;">SUPIR</th>
										  </tr>		  
										  <tr>
											<td>
												<center>
												<?php
													$no_bangku_1 = $apps->cekKursi_AC32("1");													
													if($no_bangku_1 == "ADA"){
												?>
													<div data-modal="md-stickyUp_AC41" class="kursi_berisi">1</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">1</div>
												<?php
													}
												?>													
												</center>
												<form name="frmKursi1_AC41" id="frmKursi1_AC41" method="post" action="#">
													<div id="md-stickyUp_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="1">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
												<?php
													$no_bangku_2 = $apps->cekKursi_AC32("2");													
													if($no_bangku_2 == "ADA"){
												?>
													<div data-modal="md-stickyUp2_AC41" class="kursi_berisi">2</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp2_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">2</div>
												<?php
													}
												?>
													
												</center>
												<form name="frmKursi2_AC41" id="frmKursi2_AC41" method="post" action="#">
													<div id="md-stickyUp2_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="2">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" type="number" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
											<center>
												<?php
													$no_bangku_3 = $apps->cekKursi_AC32("3");													
													if($no_bangku_3 == "ADA"){
												?>
													<div data-modal="md-stickyUp3_AC41" class="kursi_berisi">3</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp3_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">3</div>
												<?php
													}
												?>
											</center>
											<form name="frmKursi3_AC41" id="frmKursi3_AC41" method="post" action="#">
													<div id="md-stickyUp3_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="3">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
											<center>
												<?php
													$no_bangku_4 = $apps->cekKursi_AC32("4");													
													if($no_bangku_4 == "ADA"){
												?>
													<div data-modal="md-stickyUp4a_AC41" class="kursi_berisi">4</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp4a_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">4</div>
												<?php		
													}
												?>
												
											</center>
											<form name="frmKursi4a_AC41" id="frmKursi4a_AC41" method="post" action="#">
													<div id="md-stickyUp4a_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly value="4">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
											<center>
													<?php
														$no_bangku_5 = $apps->cekKursi_AC32("5");
														if($no_bangku_5 == "ADA"){
													?>
														<div data-modal="md-stickyUp5_AC41" class="kursi_berisi">5</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp5_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">5</div>
													<?php
														}
													?>
												
											</center>
											<form name="frmKursi5_AC41" id="frmKursi5_AC41" method="post" action="#">
													<div id="md-stickyUp5_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="5">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_6 = $apps->cekKursi_AC32("6");
														if($no_bangku_6 == "ADA"){
													?>
														<div data-modal="md-stickyUp6_AC41" class="kursi_berisi">6</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp6_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">6</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi6_AC41" id="frmKursi6_AC41" method="post" action="#">
													<div id="md-stickyUp6_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="6">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_7 = $apps->cekKursi_AC32("7");
														if($no_bangku_7 == "ADA"){
													?>
														<div data-modal="md-stickyUp7_AC41" class="kursi_berisi">7</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp7_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">7</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi7_AC41" id="frmKursi7_AC41" method="post" action="#">
													<div id="md-stickyUp7_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="7">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_8 = $apps->cekKursi_AC32("8");
														if($no_bangku_8 == "ADA"){
													?>
														<div data-modal="md-stickyUp8_AC41" class="kursi_berisi">8</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp8_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">8</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi8_AC41" id="frmKursi8_AC41" method="post" action="#">
													<div id="md-stickyUp8_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="8">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_9 = $apps->cekKursi_AC32("9");
														if($no_bangku_9 == "ADA"){
													?>
														<div data-modal="md-stickyUp9_AC41" class="kursi_berisi">9</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp9_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">9</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi9_AC41" id="frmKursi9_AC41" method="post" action="#">
													<div id="md-stickyUp9_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="9">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_10 = $apps->cekKursi_AC32("10");
														if($no_bangku_10 == "ADA"){
													?>
														<div data-modal="md-stickyUp10_AC41" class="kursi_berisi">10</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp10_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">10</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi10_AC41" id="frmKursi10_AC41" method="post" action="#">
													<div id="md-stickyUp10_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="10">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_11 = $apps->cekKursi_AC32("11");
														if($no_bangku_11 == "ADA"){
													?>
														<div data-modal="md-stickyUp11_AC41" class="kursi_berisi">11</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp11_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">11</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi11_AC41" id="frmKursi11_AC41" method="post" action="#">
													<div id="md-stickyUp11_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="11">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_12 = $apps->cekKursi_AC32("12");
														if($no_bangku_12 == "ADA"){
													?>
														<div data-modal="md-stickyUp12_AC41" class="kursi_berisi">12</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp12_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">12</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi12_AC41" id="frmKursi12_AC41" method="post" action="#">
													<div id="md-stickyUp12_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="12">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form></td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_13 = $apps->cekKursi_AC32("13");
														if($no_bangku_13 == "ADA"){
													?>
														<div data-modal="md-stickyUp13_AC41" class="kursi_berisi">13</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp13_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">13</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi13_AC41" id="frmKursi13_AC41" method="post" action="#">
													<div id="md-stickyUp13_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="13">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_14 = $apps->cekKursi_AC32("14");
														if($no_bangku_14 == "ADA"){
													?>
														<div data-modal="md-stickyUp14_AC41" class="kursi_berisi">14</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp14_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">14</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi14_AC41" id="frmKursi14_AC41" method="post" action="#">
													<div id="md-stickyUp14_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="14">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_15 = $apps->cekKursi_AC32("15");
														if($no_bangku_15 == "ADA"){
													?>
														<div data-modal="md-stickyUp15_AC41" class="kursi_berisi">15</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp15_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">15</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi15_AC41" id="frmKursi15_AC41" method="post" action="#">
													<div id="md-stickyUp15_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="15">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>

											<td>
												<center>
													<?php
														$no_bangku_16 = $apps->cekKursi_AC32("16");
														if($no_bangku_16 == "ADA"){
													?>
														<div data-modal="md-stickyUp16_AC41" class="kursi_berisi">16</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp16_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">16</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi16_AC41" id="frmKursi16_AC41" method="post" action="#">
													<div id="md-stickyUp16_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="16">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_17 = $apps->cekKursi_AC32("17");
														if($no_bangku_17 == "ADA"){
													?>
														<div data-modal="md-stickyUp17_AC41" class="kursi_berisi">17</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp17_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">17</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi17_AC41" id="frmKursi17_AC41" method="post" action="#">
													<div id="md-stickyUp17_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="17">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_18 = $apps->cekKursi_AC32("18");													
														if($no_bangku_18 == "ADA"){
													?>
														<div data-modal="md-stickyUp18_AC41" class="kursi_berisi">18</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp18_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">18</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi18_AC41" id="frmKursi18_AC41" method="post" action="#">
													<div id="md-stickyUp18_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="18">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_19 = $apps->cekKursi_AC32("19");													
														if($no_bangku_19 == "ADA"){
													?>
														<div data-modal="md-stickyUp19_AC41" class="kursi_berisi">19</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp19_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">19</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi19_AC41" id="frmKursi19_AC41" method="post" action="#">
													<div id="md-stickyUp19_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="19">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_20 = $apps->cekKursi_AC32("20");													
														if($no_bangku_20 == "ADA"){
													?>
														<div data-modal="md-stickyUp20_AC41" class="kursi_berisi">20</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp20_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">20</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi20_AC41" id="frmKursi20_AC41" method="post" action="#">
													<div id="md-stickyUp20_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="20">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_21 = $apps->cekKursi_AC32("21");													
														if($no_bangku_21 == "ADA"){
													?>
														<div data-modal="md-stickyUp21_AC41" class="kursi_berisi">21</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp21_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">21</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi21_AC41" id="frmKursi21_AC41" method="post" action="#">
													<div id="md-stickyUp21_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="21">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_22 = $apps->cekKursi_AC32("22");													
														if($no_bangku_22 == "ADA"){
													?>
														<div data-modal="md-stickyUp22_AC41" class="kursi_berisi">22</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp22_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">22</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi22_AC41" id="frmKursi22_AC41" method="post" action="#">
													<div id="md-stickyUp22_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="22">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_23 = $apps->cekKursi_AC32("23");													
														if($no_bangku_23 == "ADA"){
													?>
														<div data-modal="md-stickyUp23_AC41" class="kursi_berisi">23</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp23_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">23</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi23_AC41" id="frmKursi23_AC41" method="post" action="#">
													<div id="md-stickyUp23_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="23">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_24 = $apps->cekKursi_AC32("24");													
														if($no_bangku_24 == "ADA"){
													?>
														<div data-modal="md-stickyUp24_AC41" class="kursi_berisi">24</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp24_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">24</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi24_AC41" id="frmKursi24_AC41" method="post" action="#">
													<div id="md-stickyUp24_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="24">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_25 = $apps->cekKursi_AC32("25");													
														if($no_bangku_25 == "ADA"){
													?>
													<div data-modal="md-stickyUp25_AC41" class="kursi_berisi">25</div>
													<?php
														}
														else{
													?>
													<div data-modal="md-stickyUp25_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">25</div>	
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi25_AC41" id="frmKursi25_AC41" method="post" action="#">
													<div id="md-stickyUp25_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="25">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_26 = $apps->cekKursi_AC32("26");													
														if($no_bangku_26 == "ADA"){
													?>
														<div data-modal="md-stickyUp26_AC41" class="kursi_berisi">26</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp26_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">26</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi26_AC41" id="frmKursi26_AC41" method="post" action="#">
													<div id="md-stickyUp26_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="26">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_27 = $apps->cekKursi_AC32("27");													
														if($no_bangku_27 == "ADA"){
													?>
														<div data-modal="md-stickyUp27_AC41" class="kursi_berisi">27</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp27_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">27</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi27_AC41" id="frmKursi27_AC41" method="post" action="#">
													<div id="md-stickyUp27_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="27">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_28 = $apps->cekKursi_AC32("28");													
														if($no_bangku_28 == "ADA"){
													?>
														<div data-modal="md-stickyUp28_AC41" class="kursi_berisi">28</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp28_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">28</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi28_AC41" id="frmKursi28_AC41" method="post" action="#">
													<div id="md-stickyUp28_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="28">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>
										  <tr>
											<td colspan="2"></td>
											<td>
												<center>
													<?php
														$no_bangku_29 = $apps->cekKursi_AC32("29");													
														if($no_bangku_29 == "ADA"){
													?>
														<div data-modal="md-stickyUp29_AC41" class="kursi_berisi">29</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp29_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">29</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi29_AC41" id="frmKursi29_AC41" method="post" action="#">
													<div id="md-stickyUp29_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="29">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_30 = $apps->cekKursi_AC32("30");													
														if($no_bangku_30 == "ADA"){
													?>
														<div data-modal="md-stickyUp30_AC41" class="kursi_berisi">30</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp30_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">30</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi30_AC41" id="frmKursi30_AC41" method="post" action="#">
													<div id="md-stickyUp30_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="30">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>											
										  </tr>

										  
										  <tr>
											
											<td>
												<center>
													<?php
														$no_bangku_31 = $apps->cekKursi_AC32("31");													
														if($no_bangku_31 == "ADA"){
													?>
														<div data-modal="md-stickyUp31_AC41" class="kursi_berisi">31</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp31_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">31</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi31_AC41" id="frmKursi31_AC41" method="post" action="#">
													<div id="md-stickyUp31_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="31">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form></td>
											<td>
												<center>
													<?php
														$no_bangku_32 = $apps->cekKursi_AC32("32");													
														if($no_bangku_32 == "ADA"){
													?>
														<div data-modal="md-stickyUp32_AC41" class="kursi_berisi">32</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp32_AC41" class="kursi_kosongbook <?php echo $bisa_isi_tiket_ac32; ?>">32</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi32_AC41" id="frmKursi32_AC41" method="post" action="#">
													<div id="md-stickyUp32_AC41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="32">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rAC_Toilet_32['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											
											<td style="width: 25px;">&nbsp;</td>
											<th colspan="2" style="text-align: center;"><div class="box_toilet">TOILET<div></th>
										  </tr>
										  <tr>
											<td colspan="5" style="text-align: center;"><div class="box_belakang">&nbsp;</div></td>
										  </tr>
									</table>
								</div>
							  </div>
						 </div>
						 <div class="col-md-9">
							  <div class="card ">
								<div class="card-content">								
									<form action="#" method="POST" name="frmAC_Toilet_32" id="frmAC_Toilet_32">	
										<table style="width: 100%; border-bottom: 2px solid #CCC; margin-bottom: 6px;">
											<tr>
													<td style="width: 50%;">
														<table>
															<tr>
																<td style="width: 21%;">Nomor Plat</td>
																<td style="width: 25%;">
																	<select style="width: 160px; text-transform: uppercase;" name="txtplat_AC32" id="txtplat_AC32">
																		<option value=''>- Pilih Bus -</option>
																		<?php
																			$bus32 = "SELECT no_plat, nm_bus, nm_supir FROM _tbl_bus WHERE jum_kursi='32' ORDER BY no_plat ASC";
																			$hb32  = mysql_query($bus32);
																			while($rb32 = mysql_fetch_array($hb32)){
																				if($rb32['no_plat'] == $no_plat_AC_Toilet_32){
																					echo "
																						<option value='$rb32[no_plat]-$rb32[nm_supir]' selected>$rb32[no_plat]</option>
																					";
																				}
																				else{
																					echo "
																						<option value='$rb32[no_plat]-$rb32[nm_supir]'>$rb32[no_plat]</option>
																					";
																				}
																				
																			}
																		?>
																	</select>
																	<!--
																	<input type="text" class="form-control input-xs" style="width: 160px; text-transform: uppercase;" required name="txtplat" value="<?php echo $no_plat_AC_Toilet_32; ?>" />
																	-->
																</td>
															</tr>
															<tr>
																<td>Nama Supir</td>
																<td>
																	<input type="text" class="form-control input-xs" style="width: 240px" required name="txtnmsupir_ac32" id="txtnmsupir_ac32" value="<?php echo $nm_supir_AC_Toilet_32; ?>" readonly />
																	<input type="hidden" class="form-control input-xs" name="tmp_jum_kursi_ac32" value="32" />		
																	<input type="hidden" class="form-control input-xs" style="width: 240px" required name="txtnomor_ac32" id="txtnomor_ac32" readonly />
																</td>
															</tr>
															<tr>
																<td>Tgl Berangkat</td>
																<td>
																	<input type="date" class="form-control input-xs" style="width: 160px;" name="txttgl_AC_32" value="<?php echo $t_berangkat_AC_Toilet_32; ?>">
																</td>
															</tr>
															<tr>
																<td>Jam Berangkat</td>
																<td>
																	<select style="width: 160px; text-transform: uppercase;" required name="txtjam_ac_toilet32" id="txtjam_ac_toilet32">
																		<?php
																			$qjam32  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
																			$hjam32  = mysql_query($qjam32);
																			while($rjam32 = mysql_fetch_array($hjam32)){
																				if($rjam32['jam'] == $j_berangkat_AC_Toilet_32){
																					echo "
																							<option value='$rjam32[jam]' selected>$rjam32[jam] WIB</option>
																				 		 ";
																				}
																				else{
																					echo "
																							<option value='$rjam32[jam]'>$rjam32[jam] WIB</option>
																						";
																				}
																				
																			}
																		?>
																	</select>
																	<!--
																	<input type="text" class="form-control input-xs" style="width: 160px;" name="txtjam" required  value="<?php echo $j_berangkat_AC_Toilet_32; ?>" />
																	-->
																</td>
															</tr>
														</table>
													</td>
													<td style="vertical-align: top; width: 50%;">
														<table>
															<!--	
															<tr>
																<td style="width: 22%;">Dari</td>
																<td>
																	<input type="text" class="form-control input-xs" style="width: 250px; text-transform: uppercase;" required name="txtdari" value="<?php echo $dari_AC_Toilet_32; ?>" />
																</td>
															</tr>
															-->
															<tr>
																<td style="width: 4%;">Tujuan</td>
																<td style="width: 46%;">
																	<!--<input type="text" class="form-control input-xs" style="width: 250px; text-transform: uppercase;" required name="txttujuan" value="<?php echo $tujuan_AC_Toilet_32; ?>" />-->
																	<select class="form-control input-sm" required name="txttujuan_ac_toilet32" id="txttujuan_ac_toilet32" style="width: 100%;">
																		<?php
																			$tuj32 = "SELECT * FROM _tbl_harga_tiket WHERE class_bus='PATAS/AC' ORDER BY tujuan ASC";
																			$hACt32  = mysql_query($tuj32);
																			while($x32 = mysql_fetch_array($hACt32)){
																				if($rAC_Toilet_32['id_tujuan'] == $x32['id']){
																					echo "
																						<option value='$x32[id]' selected>$x32[tujuan]</option>
																					 ";
																				}
																				else{
																					echo "
																						<option value='$x32[id]'>$x32[tujuan]</option>
																					 ";
																				}
																				
																			}
																		?>																		
																	</select>
																</td>
															</tr>															
															<tr>
																<td style="width: 15%;">&nbsp;</td>
																<td>
																	<div class="btn-group">
																		<button class="btn btn-primary hover" type="submit" id="tbl_Simpan_AC_32">
																			<i class="icon icon-left mdi mdi-check-all" id="ic_simpan"></i> <span id="txt_Simpan_AC_32">SIMPAN</span>
																		</button>
																		<button class="btn btn-success hover" type="button" id="cetakSJAC_Toilet_32">
																			<i class="icon icon-left mdi mdi-print"></i> CETAK SURAT JALAN
																		</button>																		
																	</div>
																	<hr style="margin-bottom: 8px; margin-top: 8px;"/>
																	<button data-modal="md-stickyUpMulti_AC_32" class="md-trigger btn btn-danger btn-block hover" type="button" id="tiketMulti_ac32">
																			<i class="icon icon-left mdi mdi-edit"></i> BELI TIKET BANYAK PENUMPANG
																	</button>	
																</td>
															</tr>
														</table>
													</td>
											</tr>											
										</table>
									 </form>
									 <table id="table2AC32" class="table table-striped table-fw-widget" style="border-top: 2px solid #CCC; width: 100%; background-color: #F8F8F8;">
										<thead>
										  <tr>
											<th style="width:12%; text-align: center">No. Bangku</th>
											<th style="width:30%;">Nama Penumpang</th>
											<th style="width:20%;">Alamat</th>
											<th style="width:15%;">No.Hp</th>											
											<th style="width:5%;"></th>
										  </tr>
										</thead>
                    					<tbody style="width: 100%;">
                    	<?php
												$query_AC41 = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='".$rAC_Toilet_32['id']."'";
												$hAC_Toilet_32asil = mysql_query($query_AC41);												
												while($rAC_Toilet_32ow = mysql_fetch_array($hAC_Toilet_32asil)){															
															echo "
																		<tr>
																			<td><b><center>".$rAC_Toilet_32ow[no_bangku]."</center></b></td>
																			<td class='user-avatar'>".$rAC_Toilet_32ow[nm_penumpang]."
																			</td>
																			<td>".$rAC_Toilet_32ow[alamat]."</td>
																			<td>".$rAC_Toilet_32ow[no_hp]."</td>
																			<td class='actions'>
																				<a href='delPenumpang.php?id=$rAC_Toilet_32ow[id]&kursi=$rAC_Toilet_32ow[no_bangku]&jadwal_code=$rAC_Toilet_32ow[kd_jadwal]&view=ac_toilet_32&nomor=".$_GET['nomor']."&plut_num_eko_41=".$_GET['plut_num_eko_41']."&plut_num_ac_41=".$_GET['plut_num_ac_41']."&plut_num_ac_32=".$_GET['plut_num_ac_32']."&plut_num_se_18=".$_GET['plut_num_se_18']."' onClick=\"return confirm('Yakinkan anda untuk menghapus penumpang dengan nama: $rAC_Toilet_32ow[nm_penumpang] ?')\" class='icon'><i class='mdi mdi-delete'></i></a>
																			</td>
																		</tr>
																	 ";
												}
										  ?>
										</tbody>
									  </table>
								</div>
							  </div>
						 </div>
					</div>
					
					<form name="frmMultiKursi_ac_32" id="frmMultiKursi_ac_32" method="POST" action="#">
																		<div id="md-stickyUpMulti_AC_32" class="modal-container modal-effect-7">
																			<div class="modal-content">
																				
																				<div class="modal-body">
																					<table id="penumpang_append_ac_32" class="info" width="100%">
																						<tr id="buat_nama_ac_32">
																							<td style="width: 22%;">
																								Pilih Kursi
																							</td>
																							<td style="padding-left: 5px; " colspan="2">																								
																								<select name="pil_kursi_multi_ac_32" id="pil_kursi_multi_ac_32" multiple>
																									<?php																										
																										$tmp_kursi_ac_t32  = "SELECT kursi_num FROM _tbm_tempkursi WHERE sts_kursi='0' AND id_jadwal='$rAC_Toilet_32[id]' AND no_plat='$rAC_Toilet_32[no_plat]' AND tgl_berangkat='$rAC_Toilet_32[tgl_berangkat]'";
																										$h_tmp_ac_32 	   = mysql_query($tmp_kursi_ac_t32);
																										while($r_kursi_ac_32 = mysql_fetch_array($h_tmp_ac_32)){
																											echo "<option vapue='$r_kursi_ac_32[kursi_num]'>$r_kursi_ac_32[kursi_num]</option>";
																										}
																									?>
																								</select>	
																								<input type="hidden" name="tmp_kursi_ac_32" id="tmp_kursi_ac_32" />
																								<input type="hidden" name="txt_tujuanhideMulti_ac_32" value="<?php echo $rAC_Toilet_32['tujuan']; ?>" />
																								<input type="hidden" name="txt_darinhideMulti_ac_32" value="<?php echo $rAC_Toilet_32['dari']; ?>" />
																								<input type="hidden" name="txt_idhideMulti_ac_32" id="txt_idhideMulti_ac_32" value="<?php echo $rAC_Toilet_32['id']; ?>" />																								
																							</td>
																						</tr>																						
																						<tr>
																							<td>
																								Alamat
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtAlamatMulti_ac_32" class="form-control input-sm"></textarea>
																							</td>
																						</tr>
																						<tr>
																							<td>
																								Nomor. HP
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<input name="txtNoHpMulti_ac_32" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																							</td>				
																						</tr>
																						<tr>
																							<td>
																								Total Ongkos
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																							<div class="input-group"><span class="input-group-addon">Rp</span>
																								<input type="hidden" name="hiddenOngkos_ac_32" id="hiddenOngkos_ac_32" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" />
																								<input name="txtOngkosMulti_ac_32" id="txtOngkosMulti_ac_32" style="width: 200px;" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" type="number" class="form-control input-sm" readonly />
																							</td>				
																						</tr>
																						<tr>
																							<td>
																								Keterangan
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtket_eko_41" class="form-control input-sm"></textarea>
																								<input type="hidden" name="hargaNormal_ac_32" value="<?php echo $rAC_Toilet_32['harga_tiket']; ?>" />
																							</td>				
																						</tr>
																					</table>
																				</div>
																				<div class="modal-footer">
																					<div class="btn-group btn-space">        	
																						<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																						<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="modal-overlay"></div>
																	</form>
 <script type="text/javascript">
		$(document).ready(function(){	
			
			$("#pil_kursi_multi_ac_32").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Kursi tidak ada!",
				width: "100%"
			});				
			$("#pil_kursi_multi_ac_32").chosen().change(function(){	
				
				if($("#pil_kursi_multi_ac_32").val() == ""){
					$(markup_ac_32).remove();				
				}
				else{										
					arrData_ac_32  = new Array($("#pil_kursi_multi_ac_32").chosen().val());	
					var valData_ac_32  = arrData_ac_32[0];
					arrKursi_ac_32 = valData_ac_32.pop();
					var jum_pen_ac_32 = arrData_ac_32[0].length
					if(jum_pen_ac_32 == 0){
						var hit_penumpang_ac_32 = 1;
					}{
						var hit_penumpang_ac_32 = 1 + jum_pen_ac_32;
					}
					var getOngkos_ac_32   = $("#hiddenOngkos_ac_32").val();
					var ongkosMulti_ac_32 = hit_penumpang_ac_32 * parseInt(getOngkos_ac_32);
					$("#txtOngkosMulti_ac_32").val(ongkosMulti_ac_32);
					//console.log(ongkosMulti);				
					$("#tmp_kursi_ac_32").val($("#pil_kursi_multi_ac_32").chosen().val());
					var markup_ac_32 = "<tr><td style='vertical-align: middle;'>Nama Penumpang </td><td style='padding-left: 5px; width: 250px;'><input name='txtNamaPenumpang_ac_32_" + arrKursi_ac_32 +"' id='txtNamaPenumpang_ac_32_"+ arrKursi_ac_32 +"' type='text' class='form-control input-xs' required></td><td style='vertical-align: bottom;'><div class='input-group'><span class='input-group-addon input-xs'>Rp</span><input name='txtOPMulti__ac_32_"+ arrKursi_ac_32 +"' id='txtOPMulti__ac_32_"+ arrKursi_ac_32 +"' style='width: 100px;' value='<?php echo $rAC_Toilet_32['harga_tiket']; ?>' type='number' class='form-control input-xs' required></div></td></tr>";
					$(markup_ac_32).insertAfter("#buat_nama_ac_32");	
					
					
					
				}				
			});
			
			
			
			$("#frmMultiKursi_ac_32").submit(function(e) {			
				saveMultiKursi_Eko_41();
				e.preventDefault();			
			});	

			function saveMultiKursi_Eko_41(){
				if($("#pil_kursi_multi_ac_32").chosen().val()==""){
					alert("Pilih Kursi Terlebih dahulu");
				}
				else{
					var confMsg = confirm('Yakinkan anda untuk melakukan Cetak Tiket ?');
					if(confMsg == true){
						var str = $("#frmMultiKursi_ac_32").serialize();
						$.ajax({
							type: "POST",
							url: "saveMulti_AC_32.php",
							data: str,
							success: function(msgNew){
								window.open('<?php echo $apps->setHost("printTiketMulti.php"); ?>?id='+ $("#txt_idhideMulti_ac_32").val() +'&no_kursi='+ $("#tmp_kursi_ac_32").val(),'PrintTiket', 'width=700, height=400');						
								window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";										
							}
						})
					}
					else{
						return false;
					}
				}				
			}
			
			
			$("#txtplat_AC32").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Nomor plat tidak ada!",
				width: "100%"
			});
			$("#txttujuan_ac_toilet32").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Tujuan tidak ada!",
				width: "100%"
			});
			$("#txtplat_AC32").change(function(){
				var nama_supir = $("#txtplat_AC32 option:selected").val();				
				var has_nama   = nama_supir.split("-");
				$("#txtnmsupir_ac32").val(has_nama[1]);
				$("#txtnomor_ac32").val(has_nama[0]);
				//console.log(has_nama);
			});

			

			/** 
			 * BUS AC
			 * 
			 **/

			 // Kursi No. 1
      		$("#frmKursi1_AC41").submit(function(e) {			
				saveAC_01();
				e.preventDefault();			
			});	

			function saveAC_01(){
				var str = $("#frmKursi1_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){											
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=600');						
					}
				})
			}

			 // Kursi No. 2
      		$("#frmKursi2_AC41").submit(function(e) {			
				saveAC_02();
				e.preventDefault();			
			});	

			function saveAC_02(){
				var str = $("#frmKursi2_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 3
      		$("#frmKursi3_AC41").submit(function(e) {			
				saveAC_03();
				e.preventDefault();			
			});	

			function saveAC_03(){
				var str = $("#frmKursi3_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 4
      		$("#frmKursi4a_AC41").submit(function(e) {			
				saveAC_04a();
				e.preventDefault();			
			});	

			function saveAC_04a(){
				var str = $("#frmKursi4a_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 5
      		$("#frmKursi5_AC41").submit(function(e) {			
				saveAC_05();
				e.preventDefault();			
			});	

			function saveAC_05(){
				var str = $("#frmKursi5_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 6
      		$("#frmKursi6_AC41").submit(function(e) {			
				saveAC_06();
				e.preventDefault();			
			});	

			function saveAC_06(){
				var str = $("#frmKursi6_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 7
      		$("#frmKursi7_AC41").submit(function(e) {			
				saveAC_07();
				e.preventDefault();			
			});	

			function saveAC_07(){
				var str = $("#frmKursi7_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 8
      		$("#frmKursi8_AC41").submit(function(e) {			
				saveAC_08();
				e.preventDefault();			
			});	

			function saveAC_08(){
				var str = $("#frmKursi8_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 9
      		$("#frmKursi9_AC41").submit(function(e) {			
				saveAC_09();
				e.preventDefault();			
			});	

			function saveAC_09(){
				var str = $("#frmKursi9_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No.10
      		$("#frmKursi10_AC41").submit(function(e) {			
				saveAC_10();
				e.preventDefault();			
			});	

			function saveAC_10(){
				var str = $("#frmKursi10_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 11
      		$("#frmKursi11_AC41").submit(function(e) {			
				saveAC_11();
				e.preventDefault();			
			});	

			function saveAC_11(){
				var str = $("#frmKursi11_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 12
      		$("#frmKursi12_AC41").submit(function(e) {			
				saveAC_12();
				e.preventDefault();			
			});	

			function saveAC_12(){
				var str = $("#frmKursi12_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			
			 // Kursi No. 13
      		$("#frmKursi13_AC41").submit(function(e) {			
				saveAC_13();
				e.preventDefault();			
			});	

			function saveAC_13(){
				var str = $("#frmKursi13_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 14
      		$("#frmKursi14_AC41").submit(function(e) {			
				saveAC_14();
				e.preventDefault();			
			});	

			function saveAC_14(){
				var str = $("#frmKursi14_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);				
						//window.location.reload();			
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 15
      		$("#frmKursi15_AC41").submit(function(e) {			
				saveAC_15();
				e.preventDefault();			
			});	

			function saveAC_15(){
				var str = $("#frmKursi15_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 16
      		$("#frmKursi16_AC41").submit(function(e) {			
				saveAC_16();
				e.preventDefault();			
			});	

			function saveAC_16(){
				var str = $("#frmKursi16_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);			
						//window.location.reload();				
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 17
      		$("#frmKursi17_AC41").submit(function(e) {			
				saveAC_17();
				e.preventDefault();			
			});	

			function saveAC_17(){
				var str = $("#frmKursi17_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 18
      		$("#frmKursi18_AC41").submit(function(e) {			
				saveAC_18();
				e.preventDefault();			
			});	

			function saveAC_18(){
				var str = $("#frmKursi18_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 19
      		$("#frmKursi19_AC41").submit(function(e) {			
				saveAC_19();
				e.preventDefault();			
			});	

			function saveAC_19(){
				var str = $("#frmKursi19_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 20
      		$("#frmKursi20_AC41").submit(function(e) {			
				saveAC_20();
				e.preventDefault();			
			});	

			function saveAC_20(){
				var str = $("#frmKursi20_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 21
      		$("#frmKursi21_AC41").submit(function(e) {			
				saveAC_21();
				e.preventDefault();			
			});	

			function saveAC_21(){
				var str = $("#frmKursi21_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);				
						//window.location.reload();			
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 22
      		$("#frmKursi22_AC41").submit(function(e) {			
				saveAC_22();
				e.preventDefault();			
			});	

			function saveAC_22(){
				var str = $("#frmKursi22_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 23
      		$("#frmKursi23_AC41").submit(function(e) {			
				saveAC_23();
				e.preventDefault();			
			});	

			function saveAC_23(){
				var str = $("#frmKursi23_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 24
      		$("#frmKursi24_AC41").submit(function(e) {			
				saveAC_24();
				e.preventDefault();			
			});	

			function saveAC_24(){
				var str = $("#frmKursi24_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 25
      		$("#frmKursi25_AC41").submit(function(e) {			
				saveAC_25();
				e.preventDefault();			
			});	

			function saveAC_25(){
				var str = $("#frmKursi25_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 26
      		$("#frmKursi26_AC41").submit(function(e) {			
				saveAC_26();
				e.preventDefault();			
			});	

			function saveAC_26(){
				var str = $("#frmKursi26_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 27
      		$("#frmKursi27_AC41").submit(function(e) {			
				saveAC_27();
				e.preventDefault();			
			});	

			function saveAC_27(){
				var str = $("#frmKursi27_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 28
      		$("#frmKursi28_AC41").submit(function(e) {			
				saveAC_28();
				e.preventDefault();			
			});	

			function saveAC_28(){
				var str = $("#frmKursi28_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 29
      		$("#frmKursi29_AC41").submit(function(e) {			
				saveAC_29();
				e.preventDefault();			
			});	

			function saveAC_29(){
				var str = $("#frmKursi29_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 30
      		$("#frmKursi30_AC41").submit(function(e) {			
				saveAC_30();
				e.preventDefault();			
			});	

			function saveAC_30(){
				var str = $("#frmKursi30_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 31
      		$("#frmKursi31_AC41").submit(function(e) {			
				saveAC_31();
				e.preventDefault();			
			});	

			function saveAC_31(){
				var str = $("#frmKursi31_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 32
      		$("#frmKursi32_AC41").submit(function(e) {			
				saveAC_32();
				e.preventDefault();			
			});	

			function saveAC_32(){
				var str = $("#frmKursi32_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 33
      		$("#frmKursi33_AC41").submit(function(e) {			
				saveAC_33();
				e.preventDefault();			
			});	

			function saveAC_33(){
				var str = $("#frmKursi33_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);			
						//window.location.reload();				
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 34
      		$("#frmKursi34_AC41").submit(function(e) {			
				saveAC_34();
				e.preventDefault();			
			});	

			function saveAC_34(){
				var str = $("#frmKursi34_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 35
      		$("#frmKursi35_AC41").submit(function(e) {			
				saveAC_35();
				e.preventDefault();			
			});	

			function saveAC_35(){
				var str = $("#frmKursi35_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 36
      		$("#frmKursi36_AC41").submit(function(e) {			
				saveAC_36();
				e.preventDefault();			
			});	

			function saveAC_36(){
				var str = $("#frmKursi36_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 37
      		$("#frmKursi37_AC41").submit(function(e) {			
				saveAC_37();
				e.preventDefault();			
			});	

			function saveAC_37(){
				var str = $("#frmKursi37_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 38
      		$("#frmKursi38_AC41").submit(function(e) {			
				saveAC_38();
				e.preventDefault();			
			});	

			function saveAC_38(){
				var str = $("#frmKursi38_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 39
      		$("#frmKursi39_AC41").submit(function(e) {			
				saveAC_39();
				e.preventDefault();			
			});	

			function saveAC_39(){
				var str = $("#frmKursi39_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 40
      		$("#frmKursi40_AC41").submit(function(e) {			
				saveAC_40();
				e.preventDefault();			
			});	

			function saveAC_40(){
				var str = $("#frmKursi40_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 41
      		$("#frmKursi41_AC41").submit(function(e) {			
				saveAC_41();
				e.preventDefault();			
			});	

			function saveAC_41(){
				var str = $("#frmKursi41_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 42
      		$("#frmKursi42_AC41").submit(function(e) {			
				saveAC_42();
				e.preventDefault();			
			});	

			function saveAC_42(){
				var str = $("#frmKursi42_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 43
      		$("#frmKursi43_AC41").submit(function(e) {			
				saveAC_43();
				e.preventDefault();			
			});	

			function saveAC_43(){
				var str = $("#frmKursi43_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 44
      		$("#frmKursi44_AC41").submit(function(e) {			
				saveAC_44();
				e.preventDefault();			
			});	

			function saveAC_44(){
				var str = $("#frmKursi44_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 45
      		$("#frmKursi45_AC41").submit(function(e) {			
				saveAC_45();
				e.preventDefault();			
			});	

			function saveAC_45(){
				var str = $("#frmKursi45_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 46
      		$("#frmKursi46_AC41").submit(function(e) {			
				saveAC_46();
				e.preventDefault();			
			});	

			function saveAC_46(){
				var str = $("#frmKursi46_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 48
      		$("#frmKursi48_AC41").submit(function(e) {			
				saveAC_48();
				e.preventDefault();			
			});	

			function saveAC_48(){
				var str = $("#frmKursi48_AC41").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_32.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();	
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_toilet_32=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=650, height=400');																	
						if(msg == "OK"){
								//setTimeout("menyimpan()", 800);
								
						}
						else{

						}
					}
				})
			}
		
			/**
			 * Fungsi Simpan Nomor Plat, Nama Supir dan Tujuan
			 *  
			 **/ 
			$("#frmAC_Toilet_32").submit(function(e) {			
				saveKeberangkatan_AC_Toilet_32();
				e.preventDefault();			
			});	
			
			function saveKeberangkatan_AC_Toilet_32(){
				var str = $("#frmAC_Toilet_32").serialize();
				$.ajax({
					type: "POST",
					url: "saveKeberangkatan_AC_Toilet_32.php",
					data: str,
					success: function(msg){	
						console.log(msg);					
						if(msg == "OK"){
							setTimeout("menyimpan_AC_Toilet_32()", 800);											
						}
						else{

						}
					}
				})
			}


			
		})
			function displayMsg(){
					$.extend($.gritter.options, { position: 'bottom-right' });
					$.gritter.add({
							title: "<i class='icon mdi mdi-info'></i> Informasi",
							text: "Data berhasil disimpan",
							class_name: 'color success',
							sticky: true
					});
					return false;					
			}
			function menyimpan(){
					$("#ic_simapn").hide();
					$("#txt_Simpan").text("SIMPAN...");
					setTimeout("displayMsg()", 1200);
					disableAll();
			}
			function disableAll(){
					$("#frmEkonomi :input").attr("disabled", true);
					$("#cetakSJ").attr("disabled", false);
					setTimeout("kembali()", 800);
			}

			function kembali(){
					$("#ic_simapn").show();
					$("#txt_Simpan").text("SIMPAN");
					window.location.href="apps.php?ekonomi=active";
			}



			/**
			 * Bagian AC
			 * 
			 **/ 

			 function displayMsg_AC41(){
					$.extend($.gritter.options, { position: 'bottom-right' });
					$.gritter.add({
							title: "<i class='icon mdi mdi-info'></i> Informasi",
							text: "Data berhasil disimpan",
							class_name: 'color success',
							sticky: true
					});
					return false;					
			}
			function menyimpan_AC_Toilet_32(){
					$("#ic_simapn_AC41").hide();
					$("#txt_Simpan_AC_32").text("SIMPAN...");
					//setTimeout("displayMsg_AC41()", 1200);
					disableAll_AC_Toilet_32();
			}
			function disableAll_AC_Toilet_32(){
					$("#frmAC_Toilet_32 :input").attr("disabled", true);
					$("#cetakSJAC_Toilet_32").attr("disabled", false);
					setTimeout("kembali_AC_Toilet_32()", 800);
			}

			function kembali_AC_Toilet_32(){
					$("#ic_simapn_AC41").show();
					$("#txt_Simpan_AC_32").text("SIMPAN");
					window.location.href="apps.php?ac_toilet_32=active&plut_num_ac_32=" + $("#txtnomor_ac32").val() + "&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&nomor=<?php echo $_GET['nomor']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
			}
	</script>