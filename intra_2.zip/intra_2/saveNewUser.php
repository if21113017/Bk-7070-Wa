<?php
	require_once "Class/ConfigApp.php";	
	$apps = new ConfigApp();
	
	$uname  = $_POST['uName'];
	$nama   = $_POST['nName'];
	$passwd = $_POST['passwd'];
	$level  = $_POST['levelU'];
	
	$newPass  = $apps->setPasswd($passwd);
	$newToken = rand(10,100);
	$cek = "SELECT * FROM _tbl_user WHERE user_id='$uname'";
	$h   = mysql_query($cek);
	$ada = mysql_fetch_array($h);
	if($ada > 0){
		echo "Fail";
	}
	else{
		$sql   = "INSERT INTO _tbl_user SET user_id='$uname', nama='$nama', password='$newPass', level='$level', token='__".$uname.$newToken."__'";
		$hasil = mysql_query($sql);
		echo "OK";
	}
	
	
	