<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	
	if($_GET['menu'] == "false"){
		$bidang = "style='margin-top: 12px;'";
	}
	else{
		$bidang = "";
	}
	
	echo "
		 <div class='col-sm-12' $bidang>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>
					MANAJEMEN USERS
                </div>				
				
                <div class='panel-body'>
					<div class='btn-group pull-right'>					
						<a href='?view=home' class='btn btn-default'><i class='icon mdi mdi-arrow-back'></i> Kembali</a>
						<a href='#' data-modal='md-stickyUpAddUser' class='md-trigger btn btn-success'><i class='icon mdi mdi-plus-circle'></i> Tambah User</a>
					</div>
					  <hr class='style15' style='margin-top: 40px;' />
					  <table id='table1' class='table table-striped table-hover' style='border-top: 1px solid #DDD;'>
						<thead>
						  <tr>
							<th style='width:8%;'>No.</th>
							<th style='width:15%;'>User Name</th>
							<th style='width:15%;'>Nama Lengkap</th>
							<th style='width:20%;'>Token</th>
							<th style='width:20%;'>Level User</th>
							<th style='width:10%;'>Aksi</th>
						  </tr>
						</thead>
						<tbody>";
						$sql = "SELECT * FROM _tbl_user WHERE user_id !='root' ORDER BY user_id, level ASC";
						$h   = mysql_query($sql);
						$no  = 0;
						while($r = mysql_fetch_array($h)){
							$no++;
							$setToken = md5($r['token']).hash("sha1", $r['token']);
							
							echo "
									<tr>
										<td>$no.</td>
										<td>$r[user_id]</td>
										<td>$r[nama]</td>
										<td>$setToken</td>
										<td>".$apps->setLevel($r['level'])."</td>
										<td>
											";
											?>
											<script type="text/javascript">
												$(document).ready(function(){
													
													$("#frmAddUserEdit_<?php echo $no; ?>").submit(function(e) {			
														saveUserEdit();
														e.preventDefault();			
													});
													
													function saveUserEdit(){				
														var str = $("#frmAddUserEdit_<?php echo $no; ?>").serialize();
														$.ajax({
															type: "POST",
															url: "saveNewUserEdit.php",
															data: str,
															success: function(msg){	
																console.log(msg);					
																if(msg == "OK"){
																	alert("User berhasil diubah");
																	window.location.reload();
																}
																else{
																	alert("User gagal disimpan\nUser dengan nama: "+$("#uName").val()+" sudah ada!");						
																}
															}
														})
													}
												})
											</script>
										<?php
											echo "
											<div class='btn-toolbar'>
												<div class='btn-group'>
													<a href='#' data-modal='md-stickyUpAddUserEdit_$no' class='md-trigger btn btn-sm btn-primary hover'><i class='mdi mdi-comment-edit'></i></a>
													<a href='?mod=delUser&id=$r[user_id]' onClick=\"return confirm('Yakinkan anda untuk menghapus user dengan nama: $r[nama] ?')\" class='btn btn-sm btn-danger hover'><i class='mdi mdi-delete'></i></a>
												</div>
											</div>
											<div id='md-stickyUpAddUserEdit_$no' class='modal-container colored-header colored-header-success modal-effect-11'>
											<div class='modal-content' style='border-radius: 5px;'>
												<div class='modal-header' style='padding: 10px;'>																	
													<a href='#' data-dismiss='modal' aria-hidden='true' class='close modal-close'><span class='mdi mdi-close'></span></a>
													<h3 class='modal-title'><i class='icon mdi mdi-comment-edit'></i> Ubah Data User</h3>
												</div>	
												<div class='modal-body'>
													<form name='frmAddUserEdit_$no' id='frmAddUserEdit_$no' method='POST'>
													<table class='table table-striped'>
														<tr>
															<th style='width: 19%; vertical-align: middle;'>User Name</th>
															<td>
																<input type='text' value='$r[user_id]' name='uNameEdit' id='uNameEdit' class='form-control input-xs' style='width: 250px;' required maxlength='30' />
																<input type='hidden' name='id_edit' value='$r[id]' />
															</td>					
														</tr>
														<tr>
															<th style='width: 19%; vertical-align: middle;'>Nama Lengkap</th>
															<td>
																<input type='text' name='nNameEdit' value='$r[nama]' id='nNameEdit' class='form-control input-xs' style='width: 250px;' required maxlength='75' />
															</td>
														</tr>
														<tr>
															<th style='width: 19%; vertical-align: middle;'>Password</th>
															<td>
																<input type='password' name='passwdEdit' id='passwdEdit' class='form-control input-xs' style='width: 250px;' maxlength='75' />
															</td>
														</tr>
														<tr>
															<th style='width: 19%; vertical-align: middle;'>Level</th>
															<td>
																<select name='levelUEdit' id='levelUEdit' class='form-control input-xs' style='width: 150px;'>";
																	if($r['level'] == "2"){
																		echo "
																		     <option value='2' selected>Administrator</option>
																			 <option value='3'>Tiketing</option>";
																	}
																	elseif($r['level'] == "3"){
																		echo "
																		     <option value='2'>Administrator</option>
																			 <option value='3'  selected>Tiketing</option>";
																	}
																	elseif($r['level'] == "1"){
																		echo "
																		     <option value='2'>Administrator</option>
																			 <option value='1'  selected>Superuser</option>
																			 <option value='3'>Tiketing</option>";
																	}
																	else{
																		echo "
																			<option value='0'>- Pilih Level -</option>
																			<option value='2'>Administrator</option>
																			<option value='3'>Tiketing</option>";
																	}
																echo "
																</select>
															</td>
														</tr>
													</table>
													<hr class='style15' />
													<div class='pull-right' style='margin-bottom: 15px;'>
															<button type='submit' id='cetakSJ' class='btn btn-success hover'>
															<i class='icon icon-left mdi mdi-save'></i> Simpan Perubahan User
														</button>
													</div>
													</form>
												</div>
											</div>
										</div>
										<div class='modal-overlay'></div>
										</td>
									</tr>
							     ";
						}
						echo "
						</tbody>
					</table>
				</div>
				
			  </div>
		 </div>";
?>
<div id="md-stickyUpAddUser" class="modal-container colored-header colored-header-primary modal-effect-11">
	<div class="modal-content" style="border-radius: 5px;">
		<div class="modal-header" style="padding: 10px;">																	
			<a href="#" data-dismiss="modal" aria-hidden="true" class="close modal-close"><span class="mdi mdi-close"></span></a>
			<h3 class="modal-title"><i class="icon mdi mdi-plus-circle"></i> Tambah Data User</h3>
		</div>	
		<div class="modal-body">
			<form name="frmAddUser" id="frmAddUser" method="POST">
			<table class="table table-striped">
				<tr>
					<th style="width: 19%; vertical-align: middle;">User Name</th>
					<td>
						<input type="text" name="uName" id="uName" class="form-control input-xs" style="width: 250px;" required maxlength="30" />
					</td>					
				</tr>
				<tr>
					<th style="width: 19%; vertical-align: middle;">Nama Lengkap</th>
					<td>
						<input type="text" name="nName" id="nName" class="form-control input-xs" style="width: 250px;" required maxlength="75" />
					</td>
				</tr>
				<tr>
					<th style="width: 19%; vertical-align: middle;">Password</th>
					<td>
						<input type="password" name="passwd" id="passwd" class="form-control input-xs" style="width: 250px;" required maxlength="75" />
					</td>
				</tr>
				<tr>
					<th style="width: 19%; vertical-align: middle;">Level</th>
					<td>
						<select name="levelU" id="levelU" class="form-control input-xs" style="width: 150px;">
							<option value="0">- Pilih Level -</option>
							<option value="2">Administrator</option>
							<option value="3">Tiketing</option>
						</select>
					</td>
				</tr>
			</table>
			<hr class="style15" />
			<div class="pull-right" style="margin-bottom: 15px;">
					<button type="submit" id="cetakSJ" class="btn btn-primary hover">
					<i class="icon icon-left mdi mdi-save"></i> Simpan User
				</button>
			</div>
			</form>
		</div>
	</div>
</div>
<div class="modal-overlay"></div>

<script type="text/javascript">
	$(document).ready(function(){
		
		$("#frmAddUser").submit(function(e) {			
			saveUser();
			e.preventDefault();			
		});
		
		function saveUser(){				
			var str = $("#frmAddUser").serialize();
			$.ajax({
				type: "POST",
				url: "saveNewUser.php",
				data: str,
				success: function(msg){	
					console.log(msg);					
					if(msg == "OK"){
						alert("User berhasil disimpan");
						window.location.reload();
					}
					else{
						alert("User gagal disimpan\nUser dengan nama: "+$("#uName").val()+" sudah ada!");						
					}
				}
			})
		}
	})
</script>
