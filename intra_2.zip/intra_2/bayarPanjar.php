<?php
	require_once "Class/ConfigApp.php";
	require_once "Class/fungsi_indotgl.php";
	$apps = new ConfigApp();
	
	$r = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_booking WHERE kd_booking='$_GET[id]'"));	
	$get_tipe  		 = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$r[tipe_bus]'"));
	echo "
			<body onLoad=\"frmBayarSisa.txtOngkosBookingBayar.focus();\">
			<div class='col-sm-12'>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>BAYAR PANJAR BOOKING TIKET
                </div>
                <div class='panel-body'>
					<form name='frmBayarSisa' id='frmBayarSisa' method='POST'>
					<table class='table table-striped'>						
							<tr>
								<td style='width: 15%;'>Tanggal Berangkat</td><th>: ".tgl_indo($r['tgl_booking'])."</th>
							</tr>
							<tr>
								<td>Jam Berangkat</td><th>: $r[jam_booking] WIB</th>
							</tr>
							<tr>
								<td>Tujuan</td><th>: $r[dari] - $r[tujuan]</th>
							</tr>
							<tr>
								<td>Tipe Bus</td>
								<th>: $get_tipe[nm_class]</th>
							</tr>		
							<tr>
								<td>Sisa Ongkos</td>
								<th>
									<div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input name='txtOngkosBookingSisa' id='txtOngkosBookingSisa' style='width: 180px; font-weight: bold;' type='number' class='form-control input-xs' readonly required value='".number_format($r['sisa'], 0, ".", ".")."' ></div>
									<input type='hidden' name='sisahide' id='sisahide' value='$r[sisa]' />
								</th>
							</tr>
							<tr>
								<td>Bayar Ongkos</td>
								<th>
									<div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input name='txtOngkosBookingBayar' id='txtOngkosBookingBayar' style='width: 180px; font-weight: bold;' type='number' class='form-control input-xs' required /></div>
								</th>
							</tr>
					</table>
					<input type='hidden' name='kode_book' value='$r[kd_booking]' />
					<hr class='style15' style='margin-top: -15px;' />
					<div class='btn-group pull-right' style='margin-bottom: 4px;'>
						<a href='?mod=bookPanjar&menu=false' class='btn btn-md btn-default'><i class='icon mdi mdi-arrow-back'></i> KEMBALI</a>
						<button type='submit' class='btn btn-md btn-primary'><i class='icon mdi mdi-save'></i> SIMPAN BAYAR PANJAR &amp; CETAK TIKET</button>						
					</div>
					<input type='hidden' name='kodeTemp' id='kodeTemp' value='$_GET[id]'/>
					<input type='hidden' name='tmp_kursi_book' id='tmp_kursi_book' value='$_GET[kursi]'/>
					</form>
				</div>
			  </div>
			</div>
			</body>
		";
?>
<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
      $(document).ready(function(){		  
			
		$("#frmBayarSisa").submit(function(e) {			
			saveBookingTiket();
			e.preventDefault();			
		});	  
		
		function saveBookingTiket(){
			var confMsg = confirm('Yakinkan anda untuk menyimpan data sisa panjar ?');
			var sisanya = $("#txtOngkosBookingSisa").val();
			if(confMsg == true){
				var str = $("#frmBayarSisa").serialize();
				$.ajax({
					type: "POST",
					url: "saveSisaPanjar.php",
					data: str,
					success: function(msgNew){
						console.log(msgNew);						
						if(sisanya == 0){							
							window.open('<?php echo $apps->setHost("printTiketBook.php"); ?>?id='+ $("#kodeTemp").val() +'&no_kursi='+ $("#tmp_kursi_book").val(),'PrintTiket', 'width=700, height=380');												
							window.location.href="?mod=bookPanjar&menu=false";
							alert("Data berhasil disimpan");
						}
						else{
							alert("Data berhasil disimpan");
							window.location.href="?mod=bookPanjar&menu=false";
						}
						
					}
				})
			}
		}
		
		  $("#txtOngkosBookingBayar").keyup(function(){
				var OngkosSisa  = $("#sisahide").val();	
				var OngkosBayar = $("#txtOngkosBookingBayar").val();					
				var hitSisa     = OngkosBayar - OngkosSisa;
				
				$("#txtOngkosBookingSisa").val(hitSisa);
				
				if($("#txtOngkosBookingSisa").val() > OngkosBayar){
					alert("Ongkos bayar tidak boleh lebih!");
					$("#txtOngkosBookingBayar").val("");
					$("#txtOngkosBookingBayar").focus();
				}
				else{
				}
		  });
		  
		  
	  })
</script>