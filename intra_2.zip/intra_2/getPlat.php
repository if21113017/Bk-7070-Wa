<?php
    require_once "Class/ConfigApp.php";
    $apps = new ConfigApp();
    $ttmp = explode("#", $_POST['tujuan']);
    $tujuan = $ttmp[1];
    $nomor  = $_POST['nomor'];
    $sql = "SELECT no_plat, nm_supir FROM _tbl_bus WHERE tipe_bus='$nomor'";
    $h   = mysql_query($sql);
    $ada = mysql_num_rows($h);
    if($ada > 0){        
        while($r = mysql_fetch_array($h)){
            $get_ongkos = mysql_fetch_array(mysql_query("SELECT harga FROM _tbl_harga_tiket WHERE class_bus='$nomor' AND tujuan='$tujuan'"));
            $ongkos = $get_ongkos['harga'];
            echo "
                    <option value='$r[no_plat]#$r[nm_supir]#$ongkos'>$r[no_plat]</option>
                 ";
           
        }
    }
    else{
        echo "
                <option value=''>Tidak ada bus untuk ditampilkan</option>
             ";
    }
?>