<?php
    session_start();
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	echo "
         <br />
		 
		 <div class='col-sm-12'>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>
					<i class='icon mdi mdi-time'></i> HISTORY SYSTEM             
					<button class='btn btn-danger pull-right' style='margin-top: -8px;' onClick=\"window.location.href='apps.php?view=home'\"><i class='icon mdi mdi-arrow-left'></i> KEMBALI</button>
                </div>
                <div class='panel-body'>								
					<table id='table1' class='table table-striped table-hover' style='border-top: 1px solid #DDD;'>
                    <thead>
                      <tr>
					  	<th style='width:8%;'>No.</th>
                        <th style='width:45%;'>Logs History</th>
                        <th style='width:15%;'>Time</th>
						<th style='width:20%;'>User</th>                        
                      </tr>
                    </thead>
                    <tbody>
						";
						$sql = "SELECT * FROM _tbl_log ORDER BY time_stamp ASC";						
						$h   = mysql_query($sql);
						$no =0 ;
						while($r = mysql_fetch_array($h)){
							$no++;
							echo "
									<tr>
										<td>$no</td>
										<td>$r[logs]</td>
										<td>$r[time_stamp]</td>
										<td>$r[user]</td>
									</tr>
								 ";
						}
						echo "
					</tbody>
					</table>
                </div>
                
            </div>
        </div>
        </form>
                      ";    