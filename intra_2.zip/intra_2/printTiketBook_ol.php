<!DOCTYPE html>
<html>
<head>
    <title>Cetak Tiket</title>
    <link rel="stylesheet" href="assets/css/invTiket.css" />
</head>
<body onLoad="window.print();">
<?php
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    require_once __DIR__."/Class/ClassIndoTgl.php";
    $id_tiket = $_GET['id'];
    $no_kursi = $_GET['no_kursi'];

	$kursi      = str_replace(",", "','", "'".$no_kursi."'");	
    $tiket      = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_booking WHERE kd_booking='$id_tiket' AND no_bangku IN ($kursi)"));    
	$sql        = "SELECT * FROM _tbl_booking WHERE kd_booking='$id_tiket' AND no_bangku IN ($kursi)";	
	$h          = mysql_query($sql);
	$r          = mysql_fetch_array($h);
	
	$tipe_class = $r['tipe	_bus'];
	if($tipe_class == "non_ac_biasa"){
		$kelas = "EKONOMI";
	}
	elseif($tipe_class == "non_ac_toilet"){
		$kelas = "EKONOMI TOILET";
	}
	else{
		$kelas = "AC TOILET";
	}
	$n  = mysql_query($sql);
	while($x = mysql_fetch_array($n)){		
		$tot_tiket += $x['harga_tiket'];
	}
	
    echo "<div class='box_tiket'>            
			<table>				
                <tr>
                    <td class='td_atas' style='vertical-align: bottom;'>
						<div class='info_tiket'>T I K E T</div>
						<span class='tgl_info'>".hariIndo($tiket['tgl_booking']).", ".tgl_indo($tiket['tgl_booking'])."</span>
                    </td>
					<td style='text-align: center; width: 315px; vertical-align: middle;'>
						<div class='pt_class'>
							PT. INTRA
						</div>
						<div class='ket_class'>
							ANGKUTAN BUS UMUM
						</div>
						<div class='jln_class'>
							Jl. Sisingamangaraja No. 194. Telp: 24701 - Pematang Siantar
						</div>
					</td>
                </tr>
            </table>
            <div class='tgl_atas'></div>
            <div class='box_isi'>  
            <table>
                <tr>
                    <td class='td_left'>Nama</td>
                    <td class='td_center'>: &nbsp;&nbsp;$r[nm_penumpang]";
						/**echo "
						 <ul style='margin-top: 0px; margin-left: -16px; margin-bottom: 0px; font-size: 12px;'>";**/
							/**while($r = mysql_fetch_array($h)){
								echo "<li>". $r['nm_penumpang']."</li>";
								$tot_tiket += $r['harga_tiket'];
							}**/
							/**
							echo "
						</ul>";**/
						echo "
					</td>
                    <td rowspan='8' class='td_right'>
                        <div class='info'>No. Kursi</div>
                        <div class='no_kursiMulti' style='margin-left: -45px !important; border: 0px solid red; width: 150px; text-align: center;'>
                            $no_kursi
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class='td_left'>Alamat</td>
                    <td class='td_center'>: &nbsp;&nbsp;$tiket[alamat]</td>
                </tr>
                <tr>
                    <td class='td_left'>No. HP</td>
                    <td class='td_center'>: &nbsp;&nbsp;$tiket[no_hp]</td>
                </tr>                
                <tr>
                    <td class='td_left'>Tujuan</td>
                    <td class='td_center'>: &nbsp;&nbsp;$tiket[dari] - $tiket[tujuan]</td>
                </tr>                                
				<tr>
                    <td class='td_left'>Kelas Bus</td>
                    <td class='td_center'>: &nbsp;&nbsp;$kelas</td>
                </tr>
                <tr>
                    <td class='td_left'>Jam</td>
                    <td class='td_center'>: &nbsp;&nbsp;$r[jam_booking] WIB</td>
                </tr>
                <tr>
                    <td class='td_left'>Ongkos</td>
                    <td class='td_center'>: &nbsp;&nbsp;Rp.".number_format($tot_tiket, 2, ",", ".")."-</td>
                </tr>
				";
				if($tiket['sts_ongkos'] == "Panjar"){
					echo "
							<tr>
								<td class='td_left'>Panjar</td>
								<td class='td_center'>: Rp.".number_format($tiket['panjar'], 2, ",", ".")."-</td>
							</tr>                                
							<tr>
								<td class='td_left'>Sisa</td>
								<td class='td_center'>: Rp.".number_format($tiket['sisa'], 2, ",", ".")."-</td>
							</tr>
					     ";
				}
				else{
					
				}
				echo "
            </table>
            </div>
            <div class='info_thanks'>
                Terima Kasih, Semoga anda selamat sampai tujuan.
            </div>
        </div>
         ";
?>
</body>
</html>
