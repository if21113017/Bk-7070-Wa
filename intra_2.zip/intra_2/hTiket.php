<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	
	
	echo "
		 <div class='col-sm-12'>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>
					PENGATURAN HARGA TIKET               
                </div>				
				
                <div class='panel-body'>";
				  if($_SESSION['level'] == "3"){
					 echo "
                                                  <a href='?mod=tiketHarga' class='btn btn-success pull-right'>Tambah Harga Tiket</a>
                                                  <hr class='style15' style='margin-top: 40px;' />
                                                  ";
				  }
				  else{
					echo "
						  <a href='?mod=tiketHarga' class='btn btn-success pull-right'>Tambah Harga Tiket</a>
						  <hr class='style15' style='margin-top: 40px;' />
						  ";
				  }
				  echo "
				  
                  <table id='table1' class='table table-striped table-hover' style='border-top: 1px solid #DDD;'>
                    <thead>
                      <tr>
					  	<th style='width:8%;'>No.</th>
                        <th style='width:42%;'>Tujuan</th>
                        <th style='width:21%;'>Harga Tiket (Rp)</th>
						<th style='width:20%;'>Kelas Bus</th>
                        <th style='width:10%;'>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>";
			$sql = "SELECT * FROM _tbl_harga_tiket ORDER BY tujuan, class_bus ASC";
			$h   = mysql_query($sql);
			$no  = 0;
			while($r = mysql_fetch_array($h)){
				$no++;
				$get_class = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$r[class_bus]'"));
			echo "
                      <tr>
					  	<td>".$no.".</td>
                        <td>".$r[tujuan]."</td>
                        <td><b>".number_format($r[harga], 0, '', '.')."</b></td>  
						<td>".$get_class['nm_class']."</td>
                        <td>
							";
							if($_SESSION['level'] == "3"){
								echo "-";
							}
							else{								
								echo "
								<div class='btn-toolbar'>
									<div class='btn-group'>
										<a href='?mod=utiketHarga&id=$r[id]' class='btn btn-sm btn-primary hover'><i class='mdi mdi-comment-edit'></i></a>
										<a href='?mod=deltiketHarga&id=$r[id]' onClick=\"return confirm('Yakinkan anda untuk menghapus data ini ?')\" class='btn btn-sm btn-danger hover'><i class='mdi mdi-delete'></i></a>
									</div>
								</div>";
							}
						echo "
						</td>
                      </tr>";
				}
			echo "
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
	     ";
