<!DOCTYPE html>
<html>
<head>
    <title>Cetak Tiket</title>
    <link rel="stylesheet" href="assets/css/invTiket.css" />
</head>
<body onLoad="window.print();">
<?php
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    require_once __DIR__."/Class/ClassIndoTgl.php";
    $id_tiket = $_GET['id'];
    $no_kursi = $_GET['no_kursi'];

	$kursi      = str_replace(",", "','", "'".$no_kursi."'");	
    //$tiket      = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_booking WHERE kd_booking='$id_tiket' AND no_bangku IN ($kursi)"));    
	$tiket      = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_booking WHERE kd_booking='$id_tiket'"));    
	//$sql        = "SELECT * FROM _tbl_booking WHERE kd_booking='$id_tiket' AND no_bangku IN ($kursi)";	
	$sql        = "SELECT * FROM _tbl_booking WHERE kd_booking='$id_tiket'";	
	$h          = mysql_query($sql);
	$r          = mysql_fetch_array($h);
	
	$tipe_class = $r['tipe_bus'];
	if($tipe_class == "non_ac_biasa"){
		$kelas = "EKONOMI BIASA";
	}
	elseif($tipe_class == "non_ac_toilet"){
		$kelas = "EKONOMI TOILET";
	}
	else{
		$kelas = "AC TOILET";
	}
	$n  = mysql_query($sql);
	while($x = mysql_fetch_array($n)){		
		$tot_tiket += $x['harga_tiket'];
	}
	
    echo "<div class='box_tiket'>            
			<table>				
                <tr>
					<td class='td_atas' style='vertical-align: bottom; width: 130px;'>
						<div class='info_tiket'>T I K E T</div>
						<span class='tgl_info'>".hariIndo($tiket['tgl_booking']).", ".tgl_indo($tiket['tgl_booking'])."</span>
                    </td>
					<td style='text-align: center; width: 300px; vertical-align: middle; margin-right: 120px;'>
						<div class='pt_class' style='margin-left: -210px;'>
							PT. INTRA
						</div>
						<div class='ket_class' style='margin-left: -210px;'>
							ANGKUTAN BUS UMUM
						</div>
						<div class='jln_class' style='margin-left: -210px;'>
                            Jl. Sisingamangara No. 194. <br />Telp: 24701 Pematang Siantar
						</div>
					</td>
                </tr>
            </table>
            <div class='tgl_atas'></div>
            <div class='box_isi'>  
            <table style='font-size: 10pt;'>
                <tr>
                    <td class='td_left' style='vertical-align: top;'>Nama</td>
                    <td class='td_center' style='vertical-align: top;'>: &nbsp;&nbsp;$r[nm_penumpang]
					</td>
                    <td rowspan='8' class='td_right'>
						<div class='info' style='margin-left: -18px;'>No. Kursi</div>
						<div class='no_kursi' style='margin-left: -13px;'>
							$no_kursi
						</div>
                    </td>
                </tr>
                <tr>
                    <td class='td_left'>Alamat</td>
                    <td class='td_center'>: &nbsp;&nbsp;$tiket[alamat]</td>
                </tr>
                <tr>
                    <td class='td_left'>No. HP</td>
                    <td class='td_center'>: &nbsp;&nbsp;$tiket[no_hp]</td>
                </tr>                
                <tr>
                    <td class='td_left'>Tujuan</td>
                    <td class='td_center'>: &nbsp;&nbsp;$tiket[dari] - $tiket[tujuan]</td>
                </tr>                                
				<tr>
                    <td class='td_left'>Kelas Bus</td>
                    <td class='td_center'>: &nbsp;&nbsp;$kelas</td>
                </tr>
                <tr>
                    <td class='td_left'>Jam</td>
                    <td class='td_center'>: &nbsp;&nbsp;$r[jam_booking] WIB</td>
                </tr>
                <tr>
                    <td class='td_left'>Ongkos</td>
                    <td class='td_center'>: &nbsp;&nbsp;Rp.".number_format($tot_tiket, 2, ",", ".")."-
					";
					if($tiket['sts_ongkos'] == "Panjar"){ echo " (DP: Rp.".number_format($tiket['panjar'], 2, ",", ".")."-, Sisa: ".number_format($tiket['sisa'], 2, ",", ".")."-)"; }else{ }
					echo "
					</td>
                </tr>
				";
				if($tiket['sts_ongkos'] == "Panjar"){
					/**
					echo "
							<tr>
								<td class='td_left'>DP</td>
								<td class='td_center'>: Rp.".number_format($tiket['panjar'], 2, ",", ".")."-</td>
							</tr>                                
							<tr>
								<td class='td_left'>Sisa</td>
								<td class='td_center'>: Rp.".number_format($tiket['sisa'], 2, ",", ".")."-</td>
							</tr>
					     ";
					**/
				}
				else{
					
				}
				echo "
            </table>
            </div>
            <div class='info_thanks'>
            <ol>
                    <li>
                        Tiket berlaku 1x perjalanan, 
                    </li>
                    <li>
                        Kerusakan atau kehilangan barang selama dalam perjalanan tanggung jawab <br />sendiri.
                    </li>
                    <li>
                        Pembatalan Keberangkatan dikenakan pemtongan sebesar 50% <br />dari harga tiket.
                    </li>
                    <li>
                        Bila pada jam keberangkatan mobil mendadak rusak atau terjadi diluar <br />kemampuan kami, maka pemberangkatan diundur/uang dikembalikan.
                    </li>
                    <li>
                        Tegurlah pengemudi apabila membahayakan keselamatan,
                    </li>
                    <li>
                        Bagi penumpang yang naik dijalan, apabila tidak naik atau tertinggal tidak <br />menjadi tanggung jawab kami,
                    </li>
                    <li>
                        Tidak diperkenankan memasukkan emas atau surat berharga kedalam bagasi.  
                    </li>
                </ol>
        </div>
        <p style='text-align: center; margin-left: -315px;'>~Terima Kasih, Semoga anda selamat sampai tujuan~</p>
        </div>
         ";
?>
</body>
</html>
