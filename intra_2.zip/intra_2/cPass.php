<?php
    session_start();
	date_default_timezone_set("Asia/Bangkok");
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	echo "
         <form name='iTiket' method='POST' action='' onSubmit=\"return confirm('Anda yakin untuk mengganti password ?')\">
		 <div class='col-sm-12'>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>GANTI PASSWORD                 
                </div>
                <div class='panel-body'>								
                  <table class='table table-striped table-hover'>                    
                      <tr>
                        <th style='vertical-align: middle; width: 120px;'>
                            Password Lama
                        </th>
                        <td>                            
                            <input type='password' name='old_pass' class='form-control input-sm' style='width: 300px;' required />
                        </td>                        
                      </tr>
                      <tr>
                        <th style='vertical-align: middle;'>
                           Password Baru
                        </th>
                        <td>
                           <input type='password' name='new_pass' class='form-control input-sm' style='width: 300px;' required />
                        </td>
                      </tr>
                      
                      <tr>
                        <th>&nbsp;</th>
                        <td colspan='2>
                            <div class='btn-group'>
                                <a href='?mod=hTiket' name='batal' class='btn btn-default'><i class='icon icon-left mdi mdi-arrow-left'></i> Kembali</a>
                                <button type='submit' name='simpan' class='btn btn-success'><i class='icon icon-left mdi mdi-check-all'></i> Ganti Password</button>
                            </div>
                        </td>
                      </tr>

                 </table>
                </div>
                
            </div>
        </div>
        </form>
                      ";

        if(isset($_POST['simpan'])){
            
            
           
            $cek = "SELECT password FROM _tbl_user WHERE user_id='".$_SESSION['user_id']."' AND password='".md5($_POST['old_pass'])."'";
           
            $h   = mysql_query($cek);
            $ada = mysql_num_rows($h);
            if($ada > 0){
               mysql_query("UPDATE _tbl_user SET password='".md5($_POST['new_pass'])."' WHERE user_id='".$_SESSION['user_id']."'");                                
				$time_stamp           = date("Y-m-d h:m:s");
				mysql_query("INSERT INTO _tbl_log SET logs='melakukan ganti password user: ".$_SESSION['user_id']."', time_stamp='".$time_stamp."', user='$_SESSION[namauser]'");
                echo "<div style='margin-left: 20px; color: green; font-size: 15px;'>
                        <i class='icon icon-left mdi mdi-check-all'></i> Password berhasil diganti
                      </div>";
                
            }
            else{
                echo "
                        <div style='margin-left: 20px; color: red; font-size: 15px;'>
                            <i class='icon icon-left mdi mdi-block'></i> Password gagal diubah, Password lama anda salah!
                        </div>
                        ";
            }
        }        
        else{

        }
                    