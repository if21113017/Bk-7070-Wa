<?php
    session_start();
    require_once "../Class/ConfigApp.php";
	date_default_timezone_set("Asia/Bangkok");
    $apps = new ConfigApp();

    $uname = $apps->escapeString($_POST['username']);
    $pass  = $apps->escapeString($_POST['passwd']);
    $rpass = md5($pass);

    $sql = "SELECT * FROM _tbl_user WHERE user_id='".$uname."' AND password='".$rpass."' AND status='T'";
    $h   = mysql_query($sql);
    $ada = mysql_num_rows($h);

    if($ada > 0){
        $r = mysql_fetch_array($h);
        $_SESSION['namauser'] = $r['nama'];
        $_SESSION['user_id']  = $r['user_id'];
        $_SESSION['token']    = $r['token'];
	$_SESSION['level']    = $r['level'];
	$time_stamp           = date("Y-m-d h:m:s");
	mysql_query("INSERT INTO _tbl_log SET logs='Login ke sistem dari IP: ".$_SERVER['REMOTE_ADDR']."', time_stamp='".$time_stamp."', user='$_SESSION[namauser]'");
        $apps->redirectPage("sukses");
    }
    else{
		$apps->redirectPage("fail");
    }