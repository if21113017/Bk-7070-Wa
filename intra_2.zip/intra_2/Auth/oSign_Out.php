<?php
	session_start();
	session_destroy();

	require_once "../Class/ConfigApp.php";
	$apps = new ConfigApp();

	$apps->redirectPage("sig_out");