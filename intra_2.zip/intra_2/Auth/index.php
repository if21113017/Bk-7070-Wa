<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../assets/img/logo.png">
    <title>Login | Bus Ticketing System</title>
    <link rel="stylesheet" type="text/css" href="../assets/lib/perfect-scrollbar/css/perfect-scrollbar.min.css"/>
    <link rel="stylesheet" type="text/css" href="../assets/lib/material-design-icons/css/material-design-iconic-font.min.css"/>
    <link rel="stylesheet" href="../assets/css/style.css" type="text/css" />
	<style type="text/css">
		::-webkit-scrollbar { 
			display: none; 
		}
	</style>
  </head>
  <body class="be-splash-screen" onLoad="frmLogin.username.focus();" style="background: linear-gradient(to right, rgba(0,140,201,0.5),rgba(0,158,165,0.4)), url('../assets/bg.jpg') no-repeat center/cover; background-size: 100% 100%;">
    <div class="be-wrapper be-login">
      <div class="be-content">
        <div class="main-content container-fluid">
          <div class="splash-container">
            <div class="panel panel-default panel-border-color panel-border-color-primary" style="border-radius: 7px;">
              
              <div class="panel-heading"><img src="../assets/img/logo.png" alt="logo" width="75%" height="75%" class="logo-img">
                <span class="splash-description">Bus Ticketing System <br />Versi 1.10.8</span>
              </div>
              <div class="panel-body">
                <form method="POST" action="oAuth.php" name="frmLogin" id="frmLogin" autocomplete="off">
                  <div class="form-group">
                    <input id="username" name="username" type="text" placeholder="Username" class="form-control" required autocomplete="new-password" />
                  </div>
                  <div class="form-group">
                    <input id="passwd" name="passwd" type="password" placeholder="Password" class="form-control" required autocomplete="new-password" />
                  </div>
                  <?php
                      error_reporting(0);
                      if($_GET['msg']=="msg_sukses"){
                        echo "
                        <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible' id='msg_sukses'>
                          <div class='icon'><span class='mdi mdi-check'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Anda telah berhasil Log-out
                          </div>
                        </div>";
                      }
                      elseif($_GET['msg']=="msg_attempt"){
                        echo "
                        <div role='alert' class='alert alert-warning alert-icon alert-icon-border alert-dismissible' id='msg_login_first'>
                          <div class='icon'><span class='mdi mdi-alert-triangle'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Silahkan Login terlebih dahulu!
                          </div>
                        </div>";
                      }
                      elseif($_GET['msg']=="msg_fail"){
                        echo "
                        <div role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible' id='msg_login_fail'>
                          <div class='icon'><span class='mdi mdi-close-circle-o'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Username atau Password anda salah
                          </div>
                        </div>";
                      }                     
                  ?>   

                  <div class="form-group login-submit">
                    <button data-dismiss="modal" type="submit" class="btn btn-primary btn-xl">LOGIN</button>
                  </div>
                </form>
              </div>
            </div>            
          </div>
        </div>
      </div>
    </div>
    <script src="../assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="../assets/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="../assets/js/main.js" type="text/javascript"></script>
    <script src="../assets/lib/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script type="text/javascript">
      $(document).ready(function(){
      	//initialize the javascript
        //$("#msg_sukses").hide();
        //$("#msg_login_first").hide();
        //$("#msg_login_fail").hide();
      	App.init();
      });
      
    </script>
  </body>
</html>