<?php
    session_start();
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();

    $id_jadwal      = $_POST['txt_idhide_ac_toilet_41'];
    $no_bangku      = $_POST['txtNoKursi_AC_Toilet_41'];
    $nm_penumpang   = strtoupper($_POST['txtNamaPenumpang_AC_Toilet_41']);
    $alamat         = strtoupper($_POST['txtAlamat_AC_Toilet_41']);
    $no_hp          = $_POST['txtNoHp_AC_Toilet_41'];
    $harga_tiket    = $_POST['txtOngkos_AC_Toilet_41'];
    $date_modif     = date("Y-m-d");

    $data = array(
        'kd_jadwal'     => $id_jadwal,
        'no_bangku'     => $no_bangku,
        'nm_penumpang'  => $nm_penumpang,
        'alamat'        => $alamat,
        'no_hp'         => $no_hp,
        'harga_tiket'   => $harga_tiket,
        'user_modify'   => '',
        'date_modify'   => $date_modif
    );


    $apps->insertData('_tbl_tiket', $data);
    $response = json_encode($data);
    echo $response;