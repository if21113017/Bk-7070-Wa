<?php
    session_start();
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();

    $tmp_kursi = explode(',', $_POST['tmp_kursi_ac_36']);
    $jum_kursi = count($tmp_kursi);
	
	/** Penambahan **/
	$jum_multi = $tmp_kursi[$jum_kursi - $jum_kursi];
	$nama_penumpang_temp = $_POST['txtNamaPenumpang_ac_36_'.$tmp_kursi[$jum_kursi - $jum_kursi]];
	$harga_tiket_temp    = $_POST['txtOPMulti__ac_36_'.$tmp_kursi[$jum_kursi - $jum_kursi]];	
	$harga_tiket_multi_temp    = $_POST['txtOPMulti__ac_36_'.$tmp_kursi[$jum_kursi - $jum_kursi + 1]];
	/** Batas Penambahan **/

    $id_jadwal      = $_POST['txt_idhideMulti_ac_36'];
    $harga_tiket    = $_POST['hiddenOngkos_ac_36'];
    $tot_tiket      = $_POST['txtOngkosMulti_ac_36'];
    $date_modif     = date("Y-m-d");
    $alamat         = $_POST['txtAlamatMulti_ac_36'];
    $txtNoHp        = $_POST['txtNoHpMulti_ac_36'];
	$tiketNormal	= $_POST['hargaNormal_ac_36'];
	$ket			= $_POST['txtket_ac_36'];
	
	$txttujuanManual = $_POST['txttujuanManualMulti_AC_36'];
		
	$pisah_temp      = explode(" - ", $txttujuanManual);
	$tujuan_temp     = $pisah_temp[1];
	$dari_temp       = $pisah_temp[0];
	
	$pisah_tujuan    = explode("#", $tujuan_temp);
	$tujuan_manual   = $pisah_tujuan[0];
	
	if($txttujuanManual == "0"){
		$PTujuan = $_POST['txt_tujuanhideMulti_ac_36'];
		$dari_p   = $_POST['txt_darinhideMulti_ac_36'];
	}
	else{
		$PTujuan = $tujuan_manual;
		$dari_p   = $dari_temp;
	}
	
	$nomor_plat	     = str_replace(" ", "%20", $_GET['nomor']);
	$plut_num_ac_41	 = str_replace(" ", "%20", $_GET['plut_num_ac_41']);
	$plut_num_eko_41 = str_replace(" ", "%20", $_GET['plut_num_eko_41']);
	$plut_num_ac_36  = str_replace(" ", "%20", $_GET['plut_num_ac_36']);
	$plut_num_ac_32  = str_replace(" ", "%20", $_GET['plut_num_ac_32']);
	$plut_num_ac_25  = str_replace(" ", "%20", $_GET['plut_num_ac_25']);
	$plut_num_ac_23	 = str_replace(" ", "%20", $_GET['plut_num_ac_23']);		
	
	$uriSave = $apps->getHost()."apps.php?mod=welcomeApp&view=ac_toilet_36&ac_toilet_36=active&menu=false&nomor=".$nomor_plat."&plut_num_ac_41=".$plut_num_ac_41."&plut_num_eko_41=".$plut_num_eko_41."&plut_num_ac_36=".$plut_num_ac_36."&plut_num_ac_32=".$plut_num_ac_32."&plut_num_ac_25=".$plut_num_ac_25."&plut_num_ac_23=".$plut_num_ac_23;
		
	$n = 0;
    for($i=0; $i<=$jum_kursi; $i++){
		$n++;
        $nm_penumpang    = strtoupper($_POST['txtNamaPenumpang_ac_36_'.$tmp_kursi[$i]]);
        $kursi_penumpang = $tmp_kursi[$i];
        $HargaTiketPen	= $_POST['txtOPMulti__ac_36_'.$kursi_penumpang];
		
        if($nm_penumpang == ""){

        }
        else{
				
			if($HargaTiketPen == $tiketNormal || $HargaTiketPen == NULL){
				$remark  = "-";				
			}
			else{
				$remark  = $ket;				
            }
			$data = array(
					'kd_jadwal'     => $id_jadwal,
					'no_bangku'     => $kursi_penumpang,
					'nm_penumpang'  => $nm_penumpang,
					'alamat'        => $alamat,
					'no_hp'         => $txtNoHp,
					'dari'			=> $dari_p,
					'tujuan'		=> $PTujuan,
					'harga_tiket'   => $HargaTiketPen,
					'user_modify'   => $_SESSION['namauser'],
					'date_modify'   => $date_modif,
					'remark'		=> $remark,
					'is_multi'		=> 'Y',
					'no_bangku_multi' => $_POST['tmp_kursi_ac_36']
			);
            $apps->insertData('_tbl_tiket', $data);
            var_dump($data);           
			
            $tmp_kursi_up = "UPDATE _tbm_tempkursi SET sts_kursi='1' WHERE id_jadwal='$id_jadwal' AND kursi_num='$kursi_penumpang'";
            mysql_query($tmp_kursi_up);
			
			mysql_query("UPDATE _tbl_uri_temp SET uri=\"".$uriSave."\" WHERE id='1'");
        }        
    }
	
	/** Penambahan **/
	$sql_ongkos = "INSERT INTO 
						_tbl_temp_ongkos 
				   SET 
						kd_jadwal='$id_jadwal', 
						no_bangku='".$jum_multi."', 
						nm_penumpang='".strtoupper($nama_penumpang_temp)."',
						harga_temp='".$harga_tiket_temp."',
						is_multi='Y',
						harga_multi_temp='".$harga_tiket_multi_temp."'";	
	mysql_query($sql_ongkos);
	/** Batas Penambahan **/
	
	mysql_query("UPDATE _tbl_tiket SET sts_notif='1' WHERE no_bangku='".$tmp_kursi[0]."'");