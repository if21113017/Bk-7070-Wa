<?php
	require_once "Class/ConfigApp.php";
	require_once "Class/fungsi_indotgl.php";
	$apps = new ConfigApp();
	
	echo "<div class='col-sm-12' style='margin-top: 12px;'>
              <div class='panel panel-border-color panel-border-color-success panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>
					DATA BOOKING PANJAR               
                </div>				
				
                <div class='panel-body'>	
				  <div class='btn-group pull-right'>	
				  <a href='apps.php?view=home' class='btn btn-default'><i class='icon mdi mdi-arrow-back'></i> Kembali</a>
				  <a href='?mod=booking' class='btn btn-success'>Booking Tiket</a>
				  </div>
				  <hr class='style15' style='margin-top: 40px;' />
                  <table id='table1' class='table table-striped table-hover' style='border-top: 1px solid #DDD;'>
                    <thead>
                      <tr>
					  	<th style='width:2%;'>No.</th>
						<th style='width:4%; text-align: center;'>No. Bangku</th>
						<th style='width:17%;'>Nama Penumpang</th>
                        <th style='width:15%;'>Tujuan</th>
						 <th style='width:15%;'>Tgl Booking</th>
                        <th style='width:11%; text-align: right;'>Harga Tiket</th>
						<th style='width:12%; text-align: right;'>Sisa</th>
						<th style='width:16%;'>Kelas Bus</th>
                        <th style='width:14%; text-align: center;'>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>";
					
		$sql = "SELECT * FROM _tbl_booking WHERE sts_ongkos='Panjar' GROUP BY kd_booking ORDER BY tgl_booking, no_bangku ASC";
		$h   = mysql_query($sql);
		$no  = 0;
		while($r = mysql_fetch_array($h)){
			$sql_class = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$r[tipe_bus]'"));
			$no++;			
			echo "
					<tr>
						<td style='text-align: center;'>$no</td>
						<td style='text-align: center; font-weight: bold;'>$r[no_bangku]</td>
						<td><i>$r[kd_booking]</i><br /><b>$r[nm_penumpang]</b></td>
						<td>$r[dari]<br />$r[tujuan]</td>
						<td>".tgl_indo($r['tgl_booking'])."<br />$r[jam_booking] WIB</td>
						<td style='text-align: right;'>Rp. ".number_format($r['tot_hargatiket'], 0, ",",".")."</td>
						<td style='text-align: right;'>Rp. ".number_format($r['sisa'], 0, ",",".")."</td>
						<td>$sql_class[nm_class]</td>
						<td style='text-align: center;'>
							<div class='btn-group'>
								<a href='?mod=bayarPanjar&id=$r[kd_booking]&kursi=$r[no_bangku_multi]' class='btn btn-sm btn-success hover'><i class='mdi mdi-edit'></i></a>
								<a href='?mod=deltiketBook&id=$r[kd_booking]' onClick=\"return confirm('Yakinkan anda untuk menghapus data dengan kode booking [$r[kd_booking]] ini ?')\" class='btn btn-sm btn-danger hover'><i class='mdi mdi-delete'></i></a>
							</div>							
						</td>
					</tr>
			     ";			
		}
		echo "</table>
		</div>
	</div>
</div>
		";