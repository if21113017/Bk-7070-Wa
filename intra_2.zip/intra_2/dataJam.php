<?php
  require_once "Class/ConfigApp.php";
  $apps = new ConfigApp();
  $act = $_GET['act'];
  if($act == "addJam"){
      $judul = "TAMBAH DATA JAM KEBERANGKATAN";
  }
  elseif($act == "editBus"){
    $judul = "UBAH JAM KEBERANGKATAN";
  }
  else{
    $judul = "DATA JAM KEBERANGKATAN";
  }
?>
<div class="col-md-12">
 <div class="panel panel-border-color panel-border-color-primary panel-contrast">
    <div class="panel-heading panel-heading-contrast"><?php echo $judul;  ?></div>
    <div class="panel-body">
      <?php
        
        switch($act){
          case "addJam":
               echo "
                        <form name='iTiket' method='POST' action='?mod=dataJam&act=addJam&api=simpan' onSubmit=\"return confirm('Anda yakin untuk menyimpan data ?')\">
                          <table class='table table-striped table-hover'>                    
                            <tr>
                              <th style='vertical-align: middle; width: 120px;'>
                                  Jam Berangkat
                              </th>
                              <td colspan='2'>                           
                                  <input type='text' name='jam' id='jam' class='form-control input-sm' placeholder='08:00:00' required style='text-transform: uppercase; width: 180px;'/>                                  
                              </td>
                            </tr>

                            <tr>
                              <th style='vertical-align: middle;'>
                                  Keterangan
                              </th>
                              <td colspan='2'>
                                  <textarea name='ket' class='form-control'></textarea>
                              </td>
                            </tr>

                            <tr>
                              <th>&nbsp;</th>
                              <td colspan='2>
                                  <div class='btn-group'>
                                      <a href='?mod=dataJam' name='batal' class='btn btn-default'><i class='icon icon-left mdi mdi-arrow-left'></i> Kembali</a>
                                      <button type='submit' name='simpan' class='btn btn-success'><i class='icon icon-left mdi mdi-check-all'></i> Simpan Data</button>
                                  </div>
                              </td>
                            </tr>
      
                          </table>
                        </form>
                    ";
              $api = $_GET['api'];
              if($api == "simpan"){
                  $jam  = $apps->escapeString($_POST['jam']);
                  $ket  = $apps->escapeString($_POST['ket']);                  
                  $data = array(
                      'jam'  => $jam,
                      'ket'  => $ket
                  );
                  $cek = "SELECT * FROM _tbl_jam WHERE jam='$jam'";
                  $hc  = mysql_query($cek);
                  $ada = mysql_num_rows($hc);
                  if($ada > 0){
                    echo "
                    <div role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
                      <div class='icon'><span class='mdi mdi-close-circle-o'></span></div>
                      <div class='message'>
                        <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan sudah ada!
                      </div>
                    </div>
                     ";
                  }
                  else{
                    $res = $apps->insertData('_tbl_jam', $data);
                    if($res == true){
                        echo "
                            <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                              <div class='icon'><span class='mdi mdi-check'></span></div>
                              <div class='message'>
                                <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan berhasil disimpan
                              </div>
                            </div>
                             ";
                    }
                  }
                 

              }
          break;

          case "editJam":
          $get = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_jam WHERE id='$_GET[id]'"));
          echo "
                <form name='iTiket' method='POST' action='?mod=dataJam&act=editJam&api=simpan' onSubmit=\"return confirm('Anda yakin untuk menyimpan data ?')\">
                  <table class='table table-striped table-hover'>                    
                  <tr>
                    <th style='vertical-align: middle; width: 120px;'>
                        Jam Berangkat
                    </th>
                    <td colspan='2'>                           
                        <input type='text' name='jam' id='jam' class='form-control input-sm' value='$get[jam]' placeholder='08:00:00' required style='text-transform: uppercase; width: 180px;'/>                                  
                    </td>
                    </tr>

                    <tr>
                    <th style='vertical-align: middle;'>
                        Keterangan
                    </th>
                    <td colspan='2'>
                        <textarea name='ket' class='form-control'>$get[ket]</textarea>
                    </td>
                    </tr>
                    <tr>
                      <th>&nbsp;</th>
                      <td colspan='2>
                          <div class='btn-group'>
                              <input type='hidden' value='$get[id]' name='id' class='form-control input-sm' required style='width: 350px;'/>
                              <a href='?mod=dataJam' name='batal' class='btn btn-default'><i class='icon icon-left mdi mdi-arrow-left'></i> Kembali</a>
                              <button type='submit' name='simpan' class='btn btn-success'><i class='icon icon-left mdi mdi-check-all'></i> Ubah Data</button>
                          </div>
                      </td>
                    </tr>

                  </table>
                </form>
            ";
            $api = $_GET['api'];
            if($api == "simpan"){
                $jam  = $apps->escapeString($_POST['jam']);
                $ket  = $apps->escapeString($_POST['ket']);     

                $sql = "UPDATE _tbl_jam SET jam='".$jam."', ket='$ket' WHERE id='$_POST[id]'";
                
                $res = mysql_query($sql);
                if($res == true){
                    echo "
                        <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-check'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan berhasil diubah
                          </div>
                        </div>
                    ";
                }
                else{
                    echo "
                        <div role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-close-circle-o'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan tidak bisa ubah!
                          </div>
                        </div>
                    ";
                }
            }
          break;

          default:
            
            if($_GET['msg'] == "sukses"){
                echo "
                    <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                      <div class='icon'><span class='mdi mdi-check'></span></div>
                      <div class='message'>
                        <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan berhasil dihapus
                      </div>
                    </div>
                ";
            }
            echo "<div class='btn-group pull-right' style='margin-bottom: 5px;'>
                      <button type='button' class='btn btn-default' onClick='window.location.reload();'><i class='icon mdi mdi-refresh'></i> Refresh</button>";
					  if($_SESSION['level'] == "3"){
echo "
                        <a href='?mod=dataJam&act=addJam' class='btn btn-success'><i class='icon mdi mdi-plus-circle-o'></i> Tambah Jam Keberangkatan</a>";

					  }
					  else{
		  echo "
			<a href='?mod=dataJam&act=addJam' class='btn btn-success'><i class='icon mdi mdi-plus-circle-o'></i> Tambah Jam Keberangkatan</a>";
					  }
					echo "
                  </div>
				  <hr class='style15' style='margin-top: 40px;'/>
				  ";

            echo "
                <table id='table1' class='table table-striped table-hover' style='border-top: 1px solid #DDD;'>
                  <thead>
                    <tr>
                      <th style='width:5%;'>No.</th>
                      <th style='width:10%;'>Jam Berangkat</th>
                      <th style='width:26%;'>Keterangan</th>                      
                      <th style='width:10%;'>Aksi</th>
                    </tr>
                  </thead>
                <tbody>
                 ";
                $q  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
                $h  = mysql_query($q);
                $no = 0;
                while($r = mysql_fetch_array($h)){
                  $no++;
                  echo "
                        <tr>
                          <td>$no.</td>
                          <td>$r[jam]</td>                          
                          <td>$r[ket]</td>
                          <td>";
							if($_SESSION['level'] == "3"){
							  echo " <div class='btn-group'>
										<a href='?mod=dataJam&act=editJam&id=$r[id]' class='btn btn-sm btn-primary hover'><i class='mdi mdi-comment-edit'></i></a>
									 </div> 	
                            ";
							}
							else{
							  echo "
                              <div class='btn-group'>
                                <a href='?mod=dataJam&act=editJam&id=$r[id]' class='btn btn-sm btn-primary hover'><i class='mdi mdi-comment-edit'></i></a>
                                <a href='deltJam.php?id=$r[id]' onClick=\"return confirm('Yakinkan anda untuk menghapus data ini ?')\" class='btn btn-sm btn-danger hover'><i class='mdi mdi-delete'></i></a>
                              </div>";
							}
							echo "
                          </td>
                        </tr>
                       ";
                }
        }
      ?>
      
    </div>
 </div>
</div>
