<?php
	require_once "Class/ConfigApp.php";
	require_once "Class/fungsi_indotgl.php";
	$apps = new ConfigApp();
	
	$pil_tgl		= $_POST['pil_tgl'];
	$tuj_book		= explode("#", $_POST['tuj_book']);
	$tujuan			= $tuj_book[1];
	$kode_harga     = $tuj_book[0];
	$pil_jam		= $_POST['pil_jam'];
	$pil_tipe_bus	= $_POST['class_bus'];
	
	$pisah_tujuan   = explode(" - ", $tujuan);
	$hasil_dari     = $pisah_tujuan[0];
	$hasil_tujuan   = $pisah_tujuan[1];
	
	if($pil_tipe_bus == "non_ac_biasa"){
		$jum_kursi   = 44;
	}
	
	elseif($pil_tipe_bus == "non_ac_toilet"){
		$jum_kursi   = 44;
	}
	
	elseif($pil_tipe_bus == "ac_toilet_22_41"){
		$jum_kursi   = 41;
	}
	
	elseif($pil_tipe_bus == "ac_toilet_22_32"){
		$jum_kursi   = 32;
	}
	
	elseif($pil_tipe_bus == "ac_toilet_22_36"){
		$jum_kursi   = 36;
	}
	elseif($pil_tipe_bus == "ac_toilet_21_23"){
		$jum_kursi   = 23;
	}
	elseif($pil_tipe_bus == "ac_toilet_21_25"){
		$jum_kursi   = 25;
	}
	
	$get_tipe  		 = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$pil_tipe_bus'"));
	$get_harga_tiket = mysql_fetch_array(mysql_query("SELECT harga FROM _tbl_harga_tiket WHERE tujuan='$tujuan' AND class_bus='$pil_tipe_bus'"));
	//var_dump($get_harga_tiket);
        //die();
	$query = "SELECT MAX(id) as maxID FROM _tbl_booking";
	$hasil = mysql_query($query);
	$data  = mysql_fetch_array($hasil);
	$idMax = $data['maxID'];
	$noUrut = (int) substr($idMax, 0, 9);
	$noUrut++;
	$new = sprintf("%010s", $noUrut);
	$kode_book = "BOOK".$new;
	
	echo "
			<div class='col-sm-12'>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>BOOKING TIKET
                </div>
                <div class='panel-body'>
					<table class='table table-striped'>						
							<tr>
								<td style='width: 15%;'>Tanggal Berangkat</td><th>: ".tgl_indo($pil_tgl)."</th>
							</tr>
							<tr>
								<td>Jam Berangkat</td><th>: $pil_jam WIB</th>
							</tr>
							<tr>
								<td>Tujuan</td><th>: $tujuan</th>
							</tr>
							<tr>
								<td>Tipe Bus</td>
								<th>
									: $get_tipe[nm_class]									
									<input type='hidden' name='ongkosTemp' id='ongkosTemp' value='$get_harga_tiket[harga]' />
								</th>
							</tr>					
					</table>
					<form name='frmBooking' id='frmBooking' method='POST'>
					<hr class='style15' style='margin-top: -15px;' />
					<div class='btn-group pull-right' style='margin-bottom: 4px;'>
						<a href='?mod=booking' class='btn btn-md btn-default'><i class='icon mdi mdi-arrow-back'></i> KEMBALI</a>
						<button type='submit' class='btn btn-md btn-primary'><i class='icon mdi mdi-print'></i> SIMPAN &amp; CETAK BOOKING</button>						
					</div>
					<table class='table table-striped'>		
						<tr id='atas_nama'>
							<th style='width: 15%; vertical-align: middle;'>Pilih Kursi</th>
							<td colspan='2' style='width: 85%;'>
								<select class='form-control input-sm' required name='pil_kursi' id='pil_kursi' multiple>";
								for($i=1; $i <= $jum_kursi; $i++){
									$q = "SELECT kursi_num FROM _tbm_tempkursi_booking WHERE tgl_booking='$pil_tgl' AND jam_booking='$pil_jam' AND tujuan='$hasil_tujuan' AND tipe_bus='$pil_tipe_bus' AND kursi_num='$i'";
									$h = mysql_query($q);
									$r = mysql_fetch_array($h);
									if($r['kursi_num'] == $i){
										// Kursi Sudah Dibooking
									}
									else{
										echo "<option value='$i'>$i</option>";
									}
								}
								echo "
									</select>
									<input type='hidden' name='tmp_kursi_book' id='tmp_kursi_book' />									
							</td>
						</tr>						
						<div id='bus_kursi_tmp'></div>
						<tr>
							<th style='width: 15%; vertical-align: middle;'>Alamat</th>
							<td colspan='2'>
								<textarea name='txtAlamat' class='form-control input-sm' style='width: 350px;'>PEMATANGSIANTAR</textarea>
							</td>
						</tr>
						<tr>
							<th style='width: 15%; vertical-align: middle;'>Nomor. HP</th>
							<td colspan='2'>
								<input name='txtNoHp' type='text' class='form-control input-xs' style='width: 217px;' maxlength=12 value='0'>
							</td>				
						</tr>
						<tr id='atas_nama'>
							<th style='width: 15%; vertical-align: middle;'>Total Ongkos</th>
							<td colspan='2'>
								<div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input name='txtOngkosBooking' id='txtOngkosBooking' style='width: 180px; font-weight: bold;' type='number' class='form-control input-xs' readonly required ></div>																
							</td>
						</tr>
						<tr id='atas_nama'>
							<th style='width: 15%; vertical-align: middle;'>Panjar/Lunas</th>
							<td colspan='2'>
								<div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input type='text' name='txtpanjar_lunas_temp' id='txtpanjar_lunas_temp' data-a-sep='.' data-a-dec=',' class='form-control input-xs' style='width: 180px;' required /></div>
								<input type='hidden' name='txtpanjar_lunas' id='txtpanjar_lunas' class='form-control input-xs' style='width: 180px;' required />	
								
							</td>
						</tr>
						<tr>
							<th style='width: 15%; vertical-align: middle;'>Sisa</th>
							<td colspan='2'>
								<div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input name='txtOngkosSisa' id='txtOngkosSisa' style='width: 180px; font-weight: bold;' type='number' class='form-control input-xs' readonly required ></div>
								
								<input type='hidden' name='tglTemp' id='tglTemp' value='$pil_tgl' />
								<input type='hidden' name='jamTemp' id='jamTemp' value='$pil_jam' />
								<input type='hidden' name='tujuanTemp' id='tujuanTemp' value='$hasil_tujuan' />
								<input type='hidden' name='dariTemp' id='dariTemp' value='$hasil_dari' />
								<input type='hidden' name='busTemp' id='busTemp' value='$pil_tipe_bus' />
								<input type='hidden' name='kodeTemp' id='kodeTemp' value='$kode_book' />
								
							</td>
						</tr>
					</table>
					</form>
				</div>
			  </div>
			</div>
			
	     ";
?>
<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript" src="assets/js/autoNumeric.js"></script>
<script type="text/javascript">
jQuery(function($) {
    $('#txtpanjar_lunas_temp').autoNumeric('init');
	//$('#admintiket').autoNumeric('init');
});
</script>
<script type="text/javascript">
      $(document).ready(function(){
		  
		$("#frmBooking").submit(function(e) {			
			saveBookingTiket();
			e.preventDefault();			
		});	  
		
		function saveBookingTiket(){
			var confMsg = confirm('Yakinkan anda untuk melakukan Booking dan Cetak Tiket ?');
			var panjar = $("#txtpanjar_lunas_temp").val();
			var ongkos_sisanya = $("#txtOngkosSisa").val();
			if(confMsg == true){
				var str = $("#frmBooking").serialize();
				$.ajax({
					type: "POST",
					url: "saveBookTiketNew.php",
					data: str,
					success: function(msgNew){
						console.log(msgNew);
						//alert(ongkos_sisanya);
						if(ongkos_sisanya == 0){
							alert("Data berhasil disimpan");
							location.reload();
							window.open('<?php echo $apps->setHost("printTiketBook.php"); ?>?id='+ $("#kodeTemp").val() +'&no_kursi='+ $("#tmp_kursi_book").val(),'PrintTiket', 'width=700, height=380');												
						}
						else{
							// Tiket dicetak setelah sisa bayar tiket dilunasi
							alert("Data berhasil disimpan");
							window.open('<?php echo $apps->setHost("printTiketBook.php"); ?>?id='+ $("#kodeTemp").val() +'&no_kursi='+ $("#tmp_kursi_book").val(),'PrintTiket', 'width=700, height=380');
							location.reload();
						}						
					}
				})
			}
		}		
		  
		$("#pil_kursi").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Kursi tidak ada!",
          width: "500"
        });
		
		$("#txtpanjar_lunas_temp").keyup(function(){
			//var pisahkan = $("#txtpanjar_lunas_temp").val();
			//var hasilpisah = pisahkan.replace(".","");
			//$("#txtpanjar_lunas").val(hasilpisah);
			var pisahkan = $("#txtpanjar_lunas_temp").val();
			var hasilpisah = pisahkan.replace(".","");
			var hasilJuta  = hasilpisah.replace(".","");
			//$("#txtpanjar_lunas").val(hasilpisah);
			$("#txtpanjar_lunas").val(hasilJuta);
			var ongkosHitTotal  = $("#txtOngkosBooking").val();
			var ongkosHitPanjar = $("#txtpanjar_lunas").val();
			
			var hitPanjarLunas  = parseInt(ongkosHitTotal) - parseInt(ongkosHitPanjar);
			
			$("#txtOngkosSisa").val(hitPanjarLunas);
			
		});
		
		var setOngkos = $("#ongkosTemp").val();
			
		$("#pil_kursi").chosen().change(function(){
			arrJumlah  	   = new Array($("#pil_kursi").chosen().val());	
			var valJumlah  = arrJumlah[0];
			arrJumKursi    = valJumlah.pop();
			var jum_pen_book = arrJumlah[0].length
			if(jum_pen_book == 0){
				var hit_penumpang_book = 1;
			}{
				var hit_penumpang_book = 1 + jum_pen_book;
			}
			
			var ongkosMultiFinal = hit_penumpang_book * parseInt(setOngkos);
			$("#txtOngkosBooking").val(ongkosMultiFinal);	
			
			arrData_se_18  = new Array($("#pil_kursi").chosen().val());	
			var valData_se_18  = arrData_se_18[0];
			arrKursi_se_18 = valData_se_18.pop();						
			$("#tmp_kursi_book").val($("#pil_kursi").chosen().val());
			var markup_se_18 = "<tr><th style='vertical-align: middle;'>Nama Penumpang <br />(<span style='font-weight: normal; font-style: italic; color: red;'>Kursi " + arrKursi_se_18 + "</span>) </th><td><input name='txtNamaPenumpang_" + arrKursi_se_18 +"' id='txtNamaPenumpang_"+ arrKursi_se_18 +"' type='text' class='form-control input-xs' required style='width: 500px;'></td><td><div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input name='txtOngkos_"+ arrKursi_se_18 +"' id='txtOngkos_"+ arrKursi_se_18 +"' style='width: 100px; font-weight: bold;' value='" + setOngkos + "' type='number' class='form-control input-xs' readonly required ></div></td></tr>";
			$(markup_se_18).insertAfter("#atas_nama");				
			console.log(hit_penumpang_book);
		});
		
		

	  })
</script>
