<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan Booking Tiket</title>
    <link rel="stylesheet" href="assets/css/invTiket.css" />
    <style type="text/css">
        body{
            font-family: 'Roboto', Arial, sans-serif;
           
        }
        .box_tiket2{
            padding: 0px;
            border: 0px solid #000;   
        }
        h3{
            text-align: center;
            text-decoration: underline;
        }
        .tabel_atas{            
            font-size: 14px;            
            border-bottom: 0px solid #000;            
            margin-right: 0px;
            margin-bottom: 5px;
        }
        .table_atas td{
            font-size: 14px;
        }
        .tabel_bawah{ 
            font-size: 8pt;
            border-width: 0px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;            
            width:100%;
        }
        .tabel_bawah td{ 
            padding: 0.5em;
            vertical-align: top;
            border-width: 1px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            width:auto;
        }
         .tabel_bawah th{ 
            color: #000;
            font-size: 12px;
            text-transform: uppercase;
            text-align: left;
            padding: 0.5em;
            border-width: 1px;
            border-bottom: 2px solid #000;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            background-color: #FFF;
        }
        
    </style>
</head>
<body onLoad="window.print();">
    <div class="box_tiket2">
        <h3>LAPORAN BOOKING TIKET</h3>
    <?php
        error_reporting(0);
        date_default_timezone_set("Asia/Bangkok");
        require_once __DIR__."/Class/ConfigApp.php";
        require_once "Class/fungsi_indotgl.php";
        $id_tiket = $_GET['id'];
        $sql = "SELECT * FROM _tbl_jadwal WHERE id='$id_tiket' ORDER BY id DESC";
		$h   = mysql_query($sql);
        $r   = mysql_fetch_array($h);

        $pop_tipe_bus  = $_GET['pop_tipe_bus'];
		$pop_tujuan    = $_GET['pop_tujuan'];
		$pop_jam       = $_GET['pop_jam'];
		$pop_tgl_awal  = $_GET['pop_tgl_awal'];
		$pop_tgl_akhir = $_GET['pop_tgl_akhir'];
		
		if($pop_tipe_bus == "ALL"){
			$jeni_bus = "Semua Tipe Bus";			
		}
		else{
			$jeni_bus = $pop_tipe_bus;
		}
		
		if($pop_tujuan == "ALL"){
			$jenis_tujuan = "Semua Tujuan";
		}
		else{
			$jenis_tujuan = $pop_tujuan;
		}
		
		if($pop_jam == "ALL"){
			$jenis_jam = "Semua Jam";
		}
		else{
			$jenis_jam = $pop_jam." WIB";
		}
		
		
		if($pop_tipe_bus == "ALL" && $pop_tujuan == "ALL" && $pop_jam == "ALL"){
			//echo "Query ALL";
			$sql = "SELECT * FROM _tbl_booking WHERE tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";								   
		}
						   
		elseif($pop_tipe_bus == "ALL" && $pop_jam == "ALL"){
			//echo "Query ALL TIPE BUS dan JAM";
			$sql = "SELECT * FROM _tbl_booking WHERE tujuan='$pop_tujuan' AND tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";								   
		}
						   
		elseif($pop_tipe_bus == "ALL"){
			//echo "Query ALL TIPE BUS";
			$sql = "SELECT * FROM _tbl_booking WHERE tujuan='$pop_tujuan' AND jam_booking='$pop_jam' AND tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";							   							   
		}
							
		elseif($pop_tujuan == "ALL" && $pop_jam == "ALL"){
			//echo "Query ALL TUJUAN dan JAM";
			$sql = "SELECT * FROM _tbl_booking WHERE tipe_bus='$tipe_bus' AND tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";								  
		}
						   
						   						   
		elseif($pop_jam == "ALL"){
			//echo "Query ALL JAM";
			$sql = "SELECT * FROM _tbl_booking WHERE tujuan='$pop_tujuan' AND tipe_bus='$tipe_bus' AND tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";
		}
						   
		elseif($pop_tujuan == "ALL"){
			//echo "Query ALL JAM";
			$sql = "SELECT * FROM _tbl_booking WHERE jam_booking='$pop_jam' AND tipe_bus='$tipe_bus' AND tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";							   
		}
						   
		else{
			$sql = "SELECT * FROM _tbl_booking WHERE tujuan='$pop_tujuan' AND tipe_bus='$tipe_bus' AND jam_booking='$pop_jam' AND tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";							   
		}
          
        /**		  
		if($pop_tipe_bus == "ALL" && $pop_tujuan == "ALL"){
			$sql = "SELECT * FROM _tbl_booking WHERE jam_booking='$pop_jam' AND tgl_booking BETWEEN '$pop_tgl_awal' AND '$pop_tgl_akhir'";			
		}**/
		
        echo "
                <table class='tabel_atas'>
                    <tr>
                        <td style='padding-left: 10px; width: 120px;'>Tipe Bus</td><td>: $jeni_bus</td>
                    </tr>                   
                    <tr>
                        <td style='padding-left: 10px;'>Tujuan</td><td>: $jenis_tujuan</td>
                    </tr>     
					<tr>
                        <td style='padding-left: 10px; width: 120px;'>Jam Berangkat</td><td>: $jenis_jam</td>
                    </tr>  
					<tr>
                        <td style='padding-left: 10px; width: 120px;'>Tanggal</td><td>: ".tgl_indo($_GET['pop_tgl_awal'])." s/d ".tgl_indo($_GET['pop_tgl_akhir'])."</td>
                    </tr>  
                </table>

                <table class='tabel_bawah'>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th style='width: 5%;'>Nomor Bangku</th>
                            <th>Nama Penumpang</th>
                            <th>Alamat</th> 
							<th>Tipe Bus</th>
							<th>Tujuan</th>
							<th>Tgl Booking</th>												
							<th style='width: 4%;'>Ket</th>
							<th style='width: 10%; text-align: right;'>Ongkos</th>
							<th style='width: 10%; text-align: right;'>Panjar</th>
							<th style='width: 10%; text-align: right;'>Sisa</th>
                        </tr>
                    </thead>
                    <tbody>
                    ";                
				$hasil = mysql_query($sql);												
				while($row = mysql_fetch_array($hasil)){
                    echo "
						<tr>
                            <td style='width: 20px;'>$no.</td>
                            <td>$row[no_bangku]</td>
                            <td>$row[nm_penumpang]</td>
                            <td>$row[alamat]</td>                                                												
							<td>$get_tipe[nm_class]</td> 
							<td>$row[dari]<br />$row[tujuan]</td>
                            <td>".tgl_indo($row[tgl_booking])."<br />$row[jam_booking] WIB</td>
							<td><i>$row[sts_ongkos]</i></td>
							<td style='text-align: right;'>Rp. ".number_format($row[harga_tiket], 0, ".", ".")."</td>												
							<td style='text-align: right;'>Rp. ".number_format($row[panjar], 0, ".", ".")."</td>
							<td style='text-align: right;'>Rp. ".number_format($row[sisa], 0, ".", ".")."</td>
                           </tr>
						";
                        $sub_total += $row[harga_tiket];
						$sub_panjar += $row['panjar'];
						$sub_sisa   += $row['sisa'];
                }
				 echo "  
                    <tr>
                        <th colspan='8'></th>
                        <th style='text-align: right; border-left: 0px solid #000; border-right: 0px solid #000;'>Sub Total:</th>
						<th style='text-align: right;'>Rp. ".number_format($sub_panjar, 0, ".", ".")."</th>
						<th style='text-align: right;'>Rp. ".number_format($sub_sisa, 0, ".", ".")."</th>
                    </tr>";
                
            echo "</tbody>
                </table>
                
             ";
        //mysql_query("INSERT INTO _tbl_hissj SET kd_jadwal='$r[id]', tgl='$t_berangkat', user='$_SESSION[user_id]'");
        //mysql_query("UPDATE _tbl_jadwal SET status='1' WHERE id='$id_tiket'");
?>
</div>
</body>
</html>