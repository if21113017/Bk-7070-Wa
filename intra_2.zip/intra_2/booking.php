<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
		
	echo "
		 <div class='col-sm-12'>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>BOOKING TIKET
                </div>
                <div class='panel-body'>
					<form name='iBooking' id='iBooking' method='POST' action='?mod=cekBooking'>
						<table class='table table-striped'>
							<tr>
								<th style='width: 170px; vertical-align: middle;'>Pilih Tanggal Berangkat</th>
								<td><input type='text' name='pil_tgl' id='pil_tgl' class='form-control input-xs' style='width: 200px;' required /></td>
							</tr>
							<tr>
								<th style='width: 170px; vertical-align: middle;'>Pilih Jam Berangkat</th>
								<td>
									<select style='width: 200px; text-transform: uppercase;' class='form-control input-xs' required name='pil_jam' id='pil_jam'>
									";
										$qjam18  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
										$hjam18  = mysql_query($qjam18);
										while($rjam18 = mysql_fetch_array($hjam18)){
											echo "
													<option value='$rjam18[jam]'>$rjam18[jam] WIB</option>
												 ";
										}
									echo "
									</select>
								</td>							
							</tr>
							<tr>
								<th style='width: 170px; vertical-align: middle;'>Tujuan</th>
								<td>
									<select class='form-control input-sm' required name='tuj_book' id='tuj_book' style='width: 100%;'>
									";
									$tuj = "SELECT DISTINCT id, tujuan, class_bus, harga FROM _tbl_harga_tiket GROUP BY tujuan ASC";
									$ht  = mysql_query($tuj);
									while($x = mysql_fetch_array($ht)){
											echo "
												<option value='$x[id]#$x[tujuan]'>$x[tujuan]</option>
												 ";										
									}
									echo "
									</select>
								</td>
							</tr>
							<tr>
								<th style='width: 170px; vertical-align: middle;'>Pilih Tipe Bus</th>
								<td>
									<select name='class_bus' id='class_bus' class='form-control input-sm' style='width: 200px;'>";
										$sql_class = "SELECT * FROM _tbl_class_bus ORDER BY id ASC";
										$h_class   = mysql_query($sql_class);
										while($x_class = mysql_fetch_array($h_class)){
											echo "
													<option value='$x_class[kd_class]'>$x_class[nm_class]</option>
												 ";
										}
										echo "								
									</select>
								</td>
							</tr>
						</table>
						<hr class='style15' />
						<div class='btn-group pull-left'>
						<a href='apps.php?view=home' class='btn btn-md btn-default'><i class='icon mdi mdi-arrow-back'></i> Kembali</a>
						<button type='submit' class='btn btn-md btn-primary'>LANJUTKAN BOOKING <i class='icon mdi mdi-arrow-right'></i></button>
						</div>
					</form>
				</div>
			  </div>
         </div>
	     ";

?>
<!--
<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){			
		$('#class_bus').chosen().change(function() {
			var varTipe_bus = $("#class_bus").chosen().val();
			$.ajax({
				type: 'POST', 
				url: 'tipeBus.php',
				data: 'tipenya=' + varTipe_bus,
				success: function(record) {
					$("#bus_kursi_tmp").fadeIn();
					$('#bus_kursi_tmp').html(record);
					console.log(varTipe_bus);
				}
			});
		});
	})
</script>
-->