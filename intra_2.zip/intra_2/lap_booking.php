<?php
    session_start();
	require_once "Class/ConfigApp.php";
    require_once "Class/fungsi_indotgl.php";
	$apps = new ConfigApp();
    date_default_timezone_set("Asia/Bangkok");
?> 
 <?php
	if($_GET['menu'] == "false"){
		$bidang = "style='margin-top: 12px;'";
	}
	else{
		$bidang = "";
	}
 ?>
 <div class='col-sm-12' <?php echo $bidang; ?>>
              <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
                <div class='panel-heading panel-heading-contrast'>LAPORAN BOOKING TIKET        
                </div>
                <div class='panel-body'>	
                    <form name="pil_busFrm" id="pil_busFrm" method="POST" action="?mod=lap_booking&act=tampil&menu=false">
                        <table class="table table-striped">
                            <?php
								echo "
										<tr>
											<th style='width: 15%; vertical-align: middle;'>Pilih Tipe Bus</th>
											<td colspan='2'>
												<select name='pil_class' id='pil_class' class='form-control input-xs' style='width: 190px;'>
													<option value='ALL'>SEMUA TIPE BUS</option>";
													$sql_class = "SELECT * FROM _tbl_class_bus ORDER BY id ASC";
													$h_class   = mysql_query($sql_class);
													while($x_class = mysql_fetch_array($h_class)){
														if($_POST['pil_class'] == $x_class['kd_class']){
															echo "
																	<option value='$x_class[kd_class]' selected>$x_class[nm_class]</option>
																 ";
														}
														else{
															echo "
																	<option value='$x_class[kd_class]'>$x_class[nm_class]</option>
																 ";

														}
													}
													echo "								
												</select>
											</td>
										</tr>
										
										<tr>
											<th style='width: 15%; vertical-align: middle;'>Pilih Tujuan</th>
											<td colspan='2'>
												<select class='form-control input-xs' required name='tuj_booking' id='tuj_booking' style='width: 450px;'>
												<option value='ALL'>SEMUA TUJUAN</option>
												";
												$tuj = "SELECT DISTINCT id, tujuan, class_bus, harga FROM _tbl_harga_tiket GROUP BY tujuan ASC";
												$ht  = mysql_query($tuj);
												while($x = mysql_fetch_array($ht)){
													if($_POST['tuj_booking'] == $x['id']."#".$x['tujuan']){
														echo "
															<option value='$x[id]#$x[tujuan]' selected>$x[tujuan]</option>
															 ";										
													}
													else{
														echo "
															<option value='$x[id]#$x[tujuan]'>$x[tujuan]</option>
															 ";										
													}
												}
												echo "
												</select>
											</td>
										</tr>
										<tr>
											<th style='width: 15%; vertical-align: middle;'>Pilih Jam Berangkat</th>
											<td colspan='2'>
												<select style='width: 190px; text-transform: uppercase;' class='form-control input-xs' required name='pil_jam_book' id='pil_jam_book'>
												<option value='ALL'>SEMUA JAM BERANGKAT</option>
												";
													$qjam18  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
													$hjam18  = mysql_query($qjam18);
													while($rjam18 = mysql_fetch_array($hjam18)){
														if($_POST['pil_jam_book'] == $rjam18['jam']){
															echo "
																	<option value='$rjam18[jam]' selected>$rjam18[jam] WIB</option>
																 ";
														}
														else{
															echo "
																<option value='$rjam18[jam]'>$rjam18[jam] WIB</option>
															 ";
														}
													}
												echo "
												</select>
											</td>							
										</tr>
								     ";
							?>
                            <tr>
								<th style="width: 15%; vertical-align: middle;">Pilih Tanggal</th>
								<td style="width: 15%; vertical-align: middle;">
									<div class="btn-group pull-left">										
										<div class='input-group'><input type="text" class="form-control input-xs" name="dari_tgl" id="dari_tgl" required style="width: 190px;" value="<?php echo $_POST[dari_tgl]; ?>" /><span class='input-group-addon input-xs'><b>s/d</b></span><input type="text" class="form-control input-xs" name="sm_tgl" id="sm_tgl" required style="width: 190px;" value="<?php echo $_POST[sm_tgl]; ?>" /></div>
									</div>									
								</td>								
								<td>
									<div class="btn-group pull-left">
										<button type="submit" name="tampil" class="btn btn-primary"><i class="icon mdi mdi-eye"></i> Tampilkan</button>
										<?php
											if($_GET['act']=="tampil"){
												echo "
														<button type='button' id='cetak' class='btn btn-success'><i class='icon icon-left mdi mdi-print'></i> Cetak</button>
													 ";
											}
										?>
										<a href="?mod=lap_booking" class="btn btn-default"><i class="icon mdi mdi-arrow-back"></i> Kembali</a>
									</div>
								</td>
							</tr>                            
                        </table>
						<hr class="style15" style="margin-top: -15px" />
                    </form>
                  
                    
                    <?php
                        if(isset($_POST['tampil'])){
						   $tgl_awal  = $_POST['dari_tgl'];
						   $tgl_akhir = $_POST['sm_tgl'];
						   $tipe_bus  = $_POST['pil_class'];
						   $pisah_tuj = explode(" - ",$_POST['tuj_booking']);
						   if($_POST['tuj_booking'] == "ALL"){
							   $tujuan_bk = "ALL";
						   }
						   else{
								$tujuan_bk = $pisah_tuj[1];
						   }
						   $jam 	  = $_POST['pil_jam_book']; 
						   
						   
						   
						   if($_POST['pil_class'] == "ALL" && $tujuan_bk == "ALL" && $_POST['pil_jam_book'] == "ALL"){
							   //echo "Query ALL";
							   $sql = "SELECT * FROM _tbl_booking WHERE tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";							   
						   }
						   
						   elseif($_POST['pil_class'] == "ALL" && $_POST['pil_jam_book'] == "ALL"){
							   //echo "Query ALL TIPE BUS dan JAM";
							   $sql = "SELECT * FROM _tbl_booking WHERE tujuan='$tujuan_bk' AND tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";								   
						   }
						   
						   elseif($_POST['pil_class'] == "ALL"){
							   //echo "Query ALL TIPE BUS";
							   $sql = "SELECT * FROM _tbl_booking WHERE tujuan='$tujuan_bk' AND jam_booking='$jam' AND tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";							   							   
						   }
							
						   elseif($_POST['tuj_booking'] == "ALL" && $_POST['pil_jam_book'] == "ALL"){
							   //echo "Query ALL TUJUAN dan JAM";
							   $sql = "SELECT * FROM _tbl_booking WHERE tipe_bus='$tipe_bus' AND tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";								  
						   }
						   
						   						   
						   elseif($_POST['pil_jam_book'] == "ALL"){
							   //echo "Query ALL JAM";
							   $sql = "SELECT * FROM _tbl_booking WHERE tujuan='$tujuan_bk' AND tipe_bus='$tipe_bus' AND tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";
							   
						   }
						   
						   elseif($_POST['tuj_booking'] == "ALL"){
							   //echo "Query ALL JAM";
							   $sql = "SELECT * FROM _tbl_booking WHERE jam_booking='$jam' AND tipe_bus='$tipe_bus' AND tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";							   
							   
						   }
						   
						   else{
							   $sql = "SELECT * FROM _tbl_booking WHERE tujuan='$tujuan_bk' AND tipe_bus='$tipe_bus' AND jam_booking='$jam' AND tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";							   
						   }
							 
						   /**	 
						   if($_POST['pil_class'] == "ALL" && $_POST['tuj_booking'] == "ALL"){
							   $sql = "SELECT * FROM _tbl_booking WHERE jam_booking='$jam' AND tgl_booking BETWEEN '$tgl_awal' AND '$tgl_akhir'";
							   
						   }**/
						   
                    ?>
					
                    <script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
                    <script type="text/javascript">
                        $(document).ready(function(){
                            $("#cetak").click(function(){                               
                                window.open('<?php echo $apps->setHost("printLapBooking.php"); ?>?pop_tipe_bus=<?php echo $tipe_bus; ?>&pop_tujuan=<?php echo $tujuan_bk; ?>&pop_jam=<?php echo $jam; ?>&pop_tgl_awal=<?php echo $tgl_awal; ?>&pop_tgl_akhir=<?php echo $tgl_akhir; ?>','CetakSuratJalan', 'width=1080, height=800');
                            });
                        })
						
					</script>
                    <?php
                           echo "
                                    <table class='table table-striped'>
                                        <thead>
                                            <tr style='border-top: 2px solid #CCC;'>
                                                <th>No.</th>
                                                <th style='width: 5%;'>Nomor Bangku</th>
                                                <th>Nama Penumpang</th>
                                                <th>Alamat</th> 
												<th>Tipe Bus</th>
												<th>Tujuan</th>
												<th>Tgl Booking</th>												
												<th style='width: 4%;'>Ket</th>
												<th style='width: 10%; text-align: right;'>Ongkos</th>
												<th style='width: 10%; text-align: right;'>Panjar</th>
												<th style='width: 10%; text-align: right;'>Sisa</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                ";
						   $h   = mysql_query($sql);
						   $ada = mysql_num_rows($h);
                           if($ada > 0){
                                $no =0;
                                while($row = mysql_fetch_array($h)){
									$get_tipe  = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$row[tipe_bus]'"));
                                    $no++;
                                    echo "  
                                            <tr>
                                                <td style='width: 20px;'>$no.</td>
                                                <td>$row[no_bangku]</td>
                                                <td>$row[nm_penumpang]</td>
                                                <td>$row[alamat]</td>                                                												
												<td>$get_tipe[nm_class]</td> 
												<td>$row[dari]<br />$row[tujuan]</td>
                                                <td>".tgl_indo($row[tgl_booking])."<br />$row[jam_booking] WIB</td>
												<td><i>$row[sts_ongkos]</i></td>
												<td style='text-align: right;'>Rp. ".number_format($row[harga_tiket], 0, ".", ".")."</td>												
												<td style='text-align: right;'>Rp. ".number_format($row[panjar], 0, ".", ".")."</td>
												<td style='text-align: right;'>Rp. ".number_format($row[sisa], 0, ".", ".")."</td>
                                            </tr>
                                         ";
                                         $sub_total += $row[harga_tiket];
										 $sub_panjar += $row['panjar'];
										 $sub_sisa   += $row['sisa'];
                                }
                                echo "  
                                            <tr>
                                                <th colspan='8'></th>
                                                <th style='text-align: right;'>Sub Total:</th>
												<th style='text-align: right;'>Rp. ".number_format($sub_panjar, 0, ".", ".")."</th>
												<th style='text-align: right;'>Rp. ".number_format($sub_sisa, 0, ".", ".")."</th>
                                            </tr>";

                           }

                           else{
                               echo "
                                        <tr>
                                            <td colspan='11'>
                                                <i style='color: red; text-style: italic;'>Tidak ada data</i>
                                            </td>
                                        </tr>
                                    ";
                           }

                           echo "
                                    </tbody>
                                    </table>
                                ";
                        }
                        else{

                        }
                    ?>

                </div>
             </div> 
 </div>