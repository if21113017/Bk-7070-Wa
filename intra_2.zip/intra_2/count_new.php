<?php
	date_default_timezone_set("Asia/Bangkok");
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	
	$tgl  = date("Y-m-d");
	
	$sql  = "SELECT id FROM _tbl_tiket WHERE sts_notif='0' LIMIT 1";
	$rs   = mysql_query($sql);	
	$ada  = mysql_num_rows($rs);	
	if($ada > 0){
		$r = mysql_fetch_array($rs);
		$update = "UPDATE _tbl_tiket SET sts_notif='1' WHERE id='$r[id]'";
		mysql_query($update);
	}
	else{
		//echo '{"result":false}';
	}
?>