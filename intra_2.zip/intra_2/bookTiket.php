<?php
		require_once __DIR__."/Class/ConfigApp.php";
		$apps = new ConfigApp();
		date_default_timezone_set("Asia/Bangkok");
		$jam_sekarang = date("H:i:s");
		$tgl_sekarang = date('d/m/Y');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>WelcomeApp</title>

<style type="text/css">	 
		table{
			border: 0px solid red;
			padding: 0px;
		}
		td{
			border: 0px solid red;
			padding: 2px;
			text-align: left;
		}		
	</style>
	<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
</head>

<body>
	<div class="row">
            <!--Default Tabs-->
            <div class="col-sm-12">
              <div class="panel panel-default">                
                <div class="tab-container">
                  <ul class="nav nav-tabs nav-tabs-danger">					
                    <li <?php if($_GET['non_ac_biasa']=="active") {echo "class='active'"; }else{ echo "";} ?>><a href="#home" data-toggle="tab">NON AC BIASA (44)</a></li>
                    <li <?php if($_GET['eko_toilet_41']=="active") {echo "class='active'"; }else{ echo "";} ?>><a href="#eko_toilet_41" data-toggle="tab">EKONOMI TOILET (41)</a></li>
					<li <?php if($_GET['ac_toilet_41']=="active") {echo "class='active'"; }else{ echo "";} ?>><a href="#ac_toilet_41" data-toggle="tab">AC TOILET (41)</a></li>
					<li <?php if($_GET['ac_toilet_32']=="active") {echo "class='active'"; }else{ echo "";} ?>><a href="#ac_toilet_32" data-toggle="tab">AC TOILET (32)</a></li>
					<li <?php if($_GET['ac_se_21']=="active") {echo "class='active'"; }else{ echo "";} ?>><a href="#ac_se_21" data-toggle="tab">AC SE 2-1 (18)</a></li>
                  </ul>
                  <div class="tab-content">
					
                    <div id="home" class="tab-pane <?php if($_GET['non_ac_biasa']=="active") {echo "active"; }else{ echo "";} ?> cont">						
						<?php include_once __DIR__."/non_ac_biasaBook.php"; ?> <!-- Status OK -->
                    </div>
                    <div id="eko_toilet_41" class="tab-pane <?php if($_GET['eko_toilet_41']=="active") {echo "active"; }else{ echo "";} ?> cont">
						<?php include_once __DIR__."/ekonomi_toilet_41Book.php"; ?> <!-- Status OK -->
                    </div>                 
					<div id="ac_toilet_41" class="tab-pane <?php if($_GET['ac_toilet_41']=="active") {echo "active"; }else{ echo "";} ?> cont">
						<?php include_once __DIR__."/ac_toilet_41Book.php"; ?>
                    </div>
					<div id="ac_toilet_32" class="tab-pane <?php if($_GET['ac_toilet_32']=="active") {echo "active"; }else{ echo "";} ?> cont">
						<?php include_once __DIR__."/ac_toilet_32Book.php"; ?>
                    </div>
					<div id="ac_se_21" class="tab-pane <?php if($_GET['ac_se_21']=="active") {echo "active"; }else{ echo "";} ?> cont">
						<?php include_once __DIR__."/ac_se_18Book.php"; ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
	</div>    
   
</body>
</html>
