<?php
	session_start();
	date_default_timezone_set("Asia/Bangkok");
	require_once "Class/ConfigApp.php";
    require_once "Class/fungsi_indotgl.php";
	$apps = new ConfigApp();    
	
	if($_GET['menu'] == "false"){
		$bidang = "style='margin-top: 12px;'";
	}
	else{
		$bidang = "";
	}
?> 
<div class="col-sm-12" <?php echo $bidang; ?>>
    <div class='panel panel-border-color panel-border-color-warning panel-contrast'>
        <div class='panel-heading panel-heading-contrast'>LAPORAN KEUANGAN ALL
        </div>
		<div class='panel-body'>	
            <form name="pil_busFrm" id="pil_busFrm" method="POST" action="?mod=lap_keu_all&act=tampil&menu=false">
				<table class="table table-striped">
					<tr>
                        <th style="vertical-align: middle; width: 100px;">Dari Tanggal</th>
                        <th style="width: 190px;">									
                            <input type="text" class="form-control input-xs" name="dari_tgl" id="dari_tgl" required style="width: 190px;" value="<?php echo $_POST[dari_tgl]; ?>" />                                    
                        </th>
                        <th style="width: 10px; vertical-align: middle;">
                            S/D
                        </th>
                        <th>
                            <input type="text" class="form-control input-xs" name="sm_tgl" id="sm_tgl" required style="width: 190px;" value="<?php echo $_POST[sm_tgl]; ?>" />
                        </th>
                    </tr>					
                    <tr>						
                        <td colspan="3">
							<div class="btn-group">
								<a href="?mod=lap_keu_all" class="btn btn-default"><i class="icon mdi mdi-arrow-back"></i> Kembali</a>
								<button class="btn btn-primary" type="submit" name="tampil">Tampilkan </button>
                                    <?php
                                        if($_GET['act']=="tampil"){
                                            echo "
                                                    <button type='button' id='cetak' class='btn btn-success'><i class='icon icon-left mdi mdi-print'></i> Cetak</button>
                                                 ";
                                        }
                                    ?>
                            </div>
                        </td>
                    </tr>
				</table>
			</form>
			
			<?php
				if(isset($_POST['tampil'])){
					$dari = $_POST['dari_tgl'];
					$sd	  = $_POST['sm_tgl'];
					
					
					echo "
							<div class='row'>
								<div class='col-sm-6'>
									<h4 style='margin-top: -10px;'>Data Penumpang</h4>
									<hr class='style15' />
									<table class='table table-striped'>
                                        <thead>
                                            <tr style='border-top: 2px solid #CCC; background-color: #F2F2F2;'>
                                                <th style='width: 6px;'>T.Duduk</th>
                                                <th>Nama Penumpang</th>                                                
												<th>Tujuan</th>
												<th>Tgl Berangkat</th>
												<th>Tipe Bus</th>
                                                <th style='width: 80px;'>Ongkos</th>												
                                            </tr>
                                        </thead>
                                        <tbody>";
											$sql_tiket   = "SELECT * FROM _tbl_tiket WHERE date_modify BETWEEN '".$dari."' AND '".$sd."' ORDER BY date_modify, no_bangku ASC";
											$h_tiket     = mysql_query($sql_tiket);
											$ada_tiket   = mysql_num_rows($h_tiket);
											if($ada_tiket > 0){
												$no = 0;
												while($t = mysql_fetch_array($h_tiket)){
													$no++;
													$get_jadwal = mysql_fetch_array(mysql_query("SELECT kd_bus, tgl_berangkat, jam_berangkat FROM _tbl_jadwal WHERE id='$t[kd_jadwal]'"));
													$tgl_mov = explode("-",$get_jadwal['tgl_berangkat']);
													$tgl_tkt = $tgl_mov[2];
													$bln_tkt = $tgl_mov[1];
													$thn_tkt = $tgl_mov[0];
													$gb_tkt  = $tgl_tkt."-".$bln_tkt."-".$thn_tkt;
													$get_tipe  = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$get_jadwal[kd_bus]'"));													
													echo "
														<tr style='font-size: 11px;'>
															<td style='text-align: center;'><b>$t[no_bangku]</b></td>
															<td>$t[nm_penumpang]</td>
															<td>$t[dari]<br />$t[tujuan]</td>
															<td>$gb_tkt<br />$get_jadwal[jam_berangkat] WIB</td>
															<td>$get_tipe[nm_class]</td>
															<td>Rp. ".number_format($t['harga_tiket'], 0, ".", ".")."</td>
														</tr>
												     ";
													$grand_tiket += $t['harga_tiket'];
												}
											}
											else{
												echo "
													<tr>
														<td colspan='5'>
															<i style='color: red; text-style: italic;'>Tidak ada data</i>
														</td>
													</tr>
											     ";
											}
										echo "
										</tbody>
										<tr>
											<th colspan='6' style='text-align:right'>Jumlah Penumpang: $no Orang</th>											
										</tr>
										<tr>
											<th colspan='6' style='text-align:right'>Grand Total: Rp. ".number_format($grand_tiket, 0, ".", ".")."</th>											
										</tr>
									</table>
								</div>
								
								<div class='col-sm-6'>
									<h4 style='margin-top: -10px;'>Data Booking Tiket</h4>
									<hr class='style15' />
									<table class='table table-striped'>
                                        <thead>
                                            <tr style='border-top: 2px solid #CCC; background-color: #F2F2F2;'>                                                
                                                <th style='width: 12%;'>T. Duduk</th>
                                                <th>Nama Penumpang</th>                                                
												<th>Tujuan</th>
												<th>Tgl Berangkat</th>
												<th>Tipe Bus</th>";
												/**
												echo "
												<th style='width: 13%; text-align: right;'>Ongkos</th>";**/
												echo "
												<th style='width: 17%; text-align: right;'>Panjar</th>
												<th style='width: 15%; text-align: right;'>Sisa</th>
                                            </tr>
                                        </thead>
                                        <tbody>";
										$sql_booking = "SELECT * FROM _tbl_booking WHERE tgl_booking BETWEEN '".$dari."' AND '".$sd."'";											
										$h_booking   = mysql_query($sql_booking);
										$ada_booking = mysql_num_rows($h_booking);
										if($ada_booking > 0){
											$num = 0;
											while($b = mysql_fetch_array($h_booking)){
												$get_class  = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$b[tipe_bus]'"));
												$num++;
												$tgl_mov1 = explode("-",$b['tgl_booking']);
												$tgl_tkt1 = $tgl_mov1[2];
												$bln_tkt1 = $tgl_mov1[1];
												$thn_tkt1 = $tgl_mov1[0];
												$gb_tkt1  = $tgl_tkt1."-".$bln_tkt1."-".$thn_tkt1;
												echo "
														<tr style='font-size: 11px;'>
															<th style='text-align: center;'>$b[no_bangku]</th>
															<td>$b[nm_penumpang]</td>
															<td>$b[dari]<br />$b[tujuan]</td>
															<td>$gb_tkt1<br />$b[jam_booking] WIB</td>
															<td>$get_class[nm_class]</td>";
															/**
															echo "
															<td>Rp. ".number_format($b[harga_tiket], 0, ".", ".")."</td>";
															**/
															echo "
															<td style='text-align: right'>Rp. ".number_format($b[panjar], 0, ".", ".")."</td>
															<td style='text-align: right'>Rp. ".number_format($b[sisa], 0, ".", ".")."</td>
														</tr>
													 ";
												$tot_panjar += $b['panjar'];
												$tot_sisa   += $b['sisa'];
											}
										}
										else{
											echo "
													<tr>
														<td colspan='7'>
															<i style='color: red; text-style: italic;'>Tidak ada data</i>
														</td>
													</tr>
											     ";
										}
										echo "
										</tbody>
										<tr>
											<th colspan='5' style='text-align:right'>Grand Total:</th>											
											<th>Rp. ".number_format($tot_panjar, 0, ".", ".")."</th>
											<th>Rp. ".number_format($tot_sisa, 0, ".", ".")."</th>
										</tr>
										<tr>
											<th colspan='7' style='text-align:right'>Jumlah Penumpang: $num Orang</th>											
										</tr>
										
									</table>
								</div>
							</div>
					     ";
				}
				else{
				}
			?>
		</div>
	</div>
</div>
<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#cetak").click(function(){
			window.open('<?php echo $apps->setHost("printLapKeuAll.php"); ?>?tgl_awal='+ $("#dari_tgl").val() +'&tgl_akhir='+ $("#sm_tgl").val(),'CetakSuratJalan', 'width=1280, height=600');
		});
	})
</script>
		
		
		
		
		
			
 
 
 