<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	
	$id = $_GET['id'];

    $sql  = "DELETE FROM _tbl_booking WHERE kd_booking='$id'";
	$sql2 = "DELETE FROM _tbm_tempkursi_booking WHERE kd_booking='$id'";
    $h   = mysql_query($sql);
	$h2   = mysql_query($sql2);

    if($h == true){
    ?>
        <script type="text/javascript">
            alert("Data booking berhasil dihapus");
            window.location.href="apps.php?mod=bookPanjar"
        </script>
    <?php
    }
    else{
    ?>
        <script type="text/javascript">
            alert("Data booking gagal dihapus");
            window.location.href="apps.php?mod=bookPanjar"
        </script>
    <?php
    }