<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
?>
					  <div class="row">
						  <div class="col-md-3">
							  <div class="card ">
								<div class="card-content">
										<?php
												/**										 
												* Cek apakah ada jadwal sekarang
												**/
												//$tgl_now = date("Y-m-d");
												$tgl_now   = $_POST['txttgl'];
												$nomor_get = $_GET['nomor'];
												if($nomor_get == ""){
													$nomor_plat_get = $_POST['txtnomor'];
												}
												else{
													$nomor_plat_get = $_GET['nomor'];
												}												
												$sql = "SELECT * FROM _tbl_jadwal WHERE tgl_berangkat='".$tgl_now."' AND status='0' AND kd_bus='EKONOMI' AND no_plat='".$nomor_get."' AND is_booking='1' ORDER BY id DESC";
												//echo $sql;
												$h   = mysql_query($sql);												
												$ada = mysql_num_rows($h);
												if($ada > 0){
														$r   = mysql_fetch_array($h);
														?>
															<script type="text/javascript">
																	$(document).ready(function(){																		
																		$("#tbl_Simpan").attr("disabled", true);
																		$("#frmEkonomi :input").attr("disabled", true);
																		$("#cetakSJ").attr("disabled", false);
																		$("#tiketMulti").attr("disabled", false);

																		$("#cetakSJ").click(function(){																						
																			window.open('<?php echo $apps->setHost("printSJ.php"); ?>?id='+<?php echo $r['id']; ?>,'CetakSuratJalan', 'width=1080, height=800');																			
																			window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
																		});
																	})
															</script>
														<?php
														
														$no_plat 	 = $r['no_plat'];
														$nm_supir 	 = $r['nm_supir'];
														$j_berangkat = $r['jam_berangkat'];
														$berangkat   = explode("-", $r['tgl_berangkat']);
														$thn         = $berangkat[0];
														$bln         = $berangkat[1];
														$tglnya      = $berangkat[2];
														$t_berangkat = $tglnya."/".$bln."/".$thn;
														$dari        = $r['dari'];
														$tujuan      = $r['tujuan'];
														$bisa_isi_tiket = "md-trigger";
												}
												else{
														?>
															<script type="text/javascript">
																	$(document).ready(function(){
																		$("#cetakSJ").attr("disabled", true);
																		$("#tiketMulti").attr("disabled", true);
																		$("#tbl_Simpan").attr("disabled", false);
																		$(".belum_ada_jadwal").click(function(){
																			alert("Belum ada jadwal!\nSilahkan isi Nomor Plat dan Nama Supir Bus terlebih dahulu");
																		});
																		$("#txtnmsupir").focus();
																	})
															</script>
														<?php
															$no_plat 	 = "";
															$nm_supir 	 = "";
															$j_berangkat = $jam_sekarang;
															$t_berangkat = $tgl_sekarang;
															$dari        = "";
															$tujuan      = "";
															$bisa_isi_tiket = "belum_ada_jadwal";
												}
												
												
										?>
									  <table id="tg-VbtHW" style="width: 220px;">										  
										  <tr>
											<th colspan="2"><center></center></th>
											<th rowspan="12"></th>
											<th colspan="2">
												<center>
													<img src="assets/img/supir.png" style="width: 30px; padding-bottom: 7px;" />
												</center>
											</th>
										  </tr>										  
										  <tr>
											<th colspan="2" style="text-align: center;">KERNET</th>
											<th  colspan="2" style="text-align: center;">SUPIR</th>
										  </tr>
										  <tr>											
											<td>
												<center>
												<?php
													$no_bangku_1 = $apps->cekKursi("1");													
													if($no_bangku_1 == "ADA"){
												?>
													<div data-modal="md-stickyUp" class="kursi_berisi">1</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">1</div>
												<?php
													}
												?>													
												</center>
												<form name="frmKursi1" id="frmKursi1" method="post" action="#">
													<div id="md-stickyUp" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="1">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
												<?php
													$no_bangku_2 = $apps->cekKursi("2");													
													if($no_bangku_2 == "ADA"){
												?>
													<div data-modal="md-stickyUp2" class="kursi_berisi">2</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp2" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">2</div>
												<?php
													}
												?>
													
												</center>
												<form name="frmKursi2" id="frmKursi2" method="post" action="#">
													<div id="md-stickyUp2" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="2">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" type="number" value="<?php echo $r['harga_tiket']; ?>" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
											<center>
												<?php
													$no_bangku_3 = $apps->cekKursi("3");													
													if($no_bangku_3 == "ADA"){
												?>
													<div data-modal="md-stickyUp3" class="kursi_berisi">3</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp3" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">3</div>
												<?php
													}
												?>
											</center>
											<form name="frmKursi3" id="frmKursi3" method="post" action="#">
													<div id="md-stickyUp3" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="3">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
											<center>
												<?php
													$no_bangku_4 = $apps->cekKursi("4");													
													if($no_bangku_4 == "ADA"){
												?>
													<div data-modal="md-stickyUp4a" class="kursi_berisi">4</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp4a" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">4</div>
												<?php		
													}
												?>
												
											</center>
											<form name="frmKursi4a" id="frmKursi4a" method="post" action="#">
													<div id="md-stickyUp4a" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly value="4">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
											<center>
													<?php
														$no_bangku_5 = $apps->cekKursi("5");
														if($no_bangku_5 == "ADA"){
													?>
														<div data-modal="md-stickyUp5" class="kursi_berisi">5</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp5" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">5</div>
													<?php
														}
													?>
												
											</center>
											<form name="frmKursi5" id="frmKursi5" method="post" action="#">
													<div id="md-stickyUp5" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="5">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_6 = $apps->cekKursi("6");
														if($no_bangku_6 == "ADA"){
													?>
														<div data-modal="md-stickyUp6" class="kursi_berisi">6</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp6" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">6</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi6" id="frmKursi6" method="post" action="#">
													<div id="md-stickyUp6" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="6">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_7 = $apps->cekKursi("7");
														if($no_bangku_7 == "ADA"){
													?>
														<div data-modal="md-stickyUp7" class="kursi_berisi">7</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp7" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">7</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi7" id="frmKursi7" method="post" action="#">
													<div id="md-stickyUp7" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="7">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_8 = $apps->cekKursi("8");
														if($no_bangku_8 == "ADA"){
													?>
														<div data-modal="md-stickyUp8" class="kursi_berisi">8</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp8" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">8</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi8" id="frmKursi8" method="post" action="#">
													<div id="md-stickyUp8" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="8">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_9 = $apps->cekKursi("9");
														if($no_bangku_9 == "ADA"){
													?>
														<div data-modal="md-stickyUp9" class="kursi_berisi">9</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp9" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">9</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi9" id="frmKursi9" method="post" action="#">
													<div id="md-stickyUp9" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="9">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_10 = $apps->cekKursi("10");
														if($no_bangku_10 == "ADA"){
													?>
														<div data-modal="md-stickyUp10" class="kursi_berisi">10</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp10" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">10</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi10" id="frmKursi10" method="post" action="#">
													<div id="md-stickyUp10" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="10">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_11 = $apps->cekKursi("11");
														if($no_bangku_11 == "ADA"){
													?>
														<div data-modal="md-stickyUp11" class="kursi_berisi">11</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp11" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">11</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi11" id="frmKursi11" method="post" action="#">
													<div id="md-stickyUp11" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="11">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_12 = $apps->cekKursi("12");
														if($no_bangku_12 == "ADA"){
													?>
														<div data-modal="md-stickyUp12" class="kursi_berisi">12</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp12" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">12</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi12" id="frmKursi12" method="post" action="#">
													<div id="md-stickyUp12" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="12">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form></td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_13 = $apps->cekKursi("13");
														if($no_bangku_13 == "ADA"){
													?>
														<div data-modal="md-stickyUp13" class="kursi_berisi">13</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp13" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">13</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi13" id="frmKursi13" method="post" action="#">
													<div id="md-stickyUp13" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="13">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_14 = $apps->cekKursi("14");
														if($no_bangku_14 == "ADA"){
													?>
														<div data-modal="md-stickyUp14" class="kursi_berisi">14</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp14" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">14</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi14" id="frmKursi14" method="post" action="#">
													<div id="md-stickyUp14" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="14">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_15 = $apps->cekKursi("15");
														if($no_bangku_15 == "ADA"){
													?>
														<div data-modal="md-stickyUp15" class="kursi_berisi">15</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp15" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">15</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi15" id="frmKursi15" method="post" action="#">
													<div id="md-stickyUp15" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="15">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>

											<td>
												<center>
													<?php
														$no_bangku_16 = $apps->cekKursi("16");
														if($no_bangku_16 == "ADA"){
													?>
														<div data-modal="md-stickyUp16" class="kursi_berisi">16</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp16" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">16</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi16" id="frmKursi16" method="post" action="#">
													<div id="md-stickyUp16" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="16">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_17 = $apps->cekKursi("17");
														if($no_bangku_17 == "ADA"){
													?>
														<div data-modal="md-stickyUp17" class="kursi_berisi">17</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp17" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">17</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi17" id="frmKursi17" method="post" action="#">
													<div id="md-stickyUp17" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="17">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_18 = $apps->cekKursi("18");													
														if($no_bangku_18 == "ADA"){
													?>
														<div data-modal="md-stickyUp18" class="kursi_berisi">18</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp18" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">18</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi18" id="frmKursi18" method="post" action="#">
													<div id="md-stickyUp18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="18">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_19 = $apps->cekKursi("19");													
														if($no_bangku_19 == "ADA"){
													?>
														<div data-modal="md-stickyUp19" class="kursi_berisi">19</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp19" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">19</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi19" id="frmKursi19" method="post" action="#">
													<div id="md-stickyUp19" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="19">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_20 = $apps->cekKursi("20");													
														if($no_bangku_20 == "ADA"){
													?>
														<div data-modal="md-stickyUp20" class="kursi_berisi">20</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp20" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">20</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi20" id="frmKursi20" method="post" action="#">
													<div id="md-stickyUp20" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="20">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_21 = $apps->cekKursi("21");													
														if($no_bangku_21 == "ADA"){
													?>
														<div data-modal="md-stickyUp21" class="kursi_berisi">21</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp21" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">21</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi21" id="frmKursi21" method="post" action="#">
													<div id="md-stickyUp21" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="21">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_22 = $apps->cekKursi("22");													
														if($no_bangku_22 == "ADA"){
													?>
														<div data-modal="md-stickyUp22" class="kursi_berisi">22</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp22" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">22</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi22" id="frmKursi22" method="post" action="#">
													<div id="md-stickyUp22" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="22">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_23 = $apps->cekKursi("23");													
														if($no_bangku_23 == "ADA"){
													?>
														<div data-modal="md-stickyUp23" class="kursi_berisi">23</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp23" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">23</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi23" id="frmKursi23" method="post" action="#">
													<div id="md-stickyUp23" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="23">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_24 = $apps->cekKursi("24");													
														if($no_bangku_24 == "ADA"){
													?>
														<div data-modal="md-stickyUp24" class="kursi_berisi">24</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp24" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">24</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi24" id="frmKursi24" method="post" action="#">
													<div id="md-stickyUp24" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="24">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_25 = $apps->cekKursi("25");													
														if($no_bangku_25 == "ADA"){
													?>
													<div data-modal="md-stickyUp25" class="kursi_berisi">25</div>
													<?php
														}
														else{
													?>
													<div data-modal="md-stickyUp25" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">25</div>	
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi1" id="frmKursi25" method="post" action="#">
													<div id="md-stickyUp25" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="25">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_26 = $apps->cekKursi("26");													
														if($no_bangku_26 == "ADA"){
													?>
														<div data-modal="md-stickyUp26" class="kursi_berisi">26</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp26" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">26</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi26" id="frmKursi26" method="post" action="#">
													<div id="md-stickyUp26" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="26">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_27 = $apps->cekKursi("27");													
														if($no_bangku_27 == "ADA"){
													?>
														<div data-modal="md-stickyUp27" class="kursi_berisi">27</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp27" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">27</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi27" id="frmKursi27" method="post" action="#">
													<div id="md-stickyUp27" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="27">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_28 = $apps->cekKursi("28");													
														if($no_bangku_28 == "ADA"){
													?>
														<div data-modal="md-stickyUp28" class="kursi_berisi">28</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp28" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">28</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi28" id="frmKursi28" method="post" action="#">
													<div id="md-stickyUp28" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="28">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_29 = $apps->cekKursi("29");													
														if($no_bangku_29 == "ADA"){
													?>
														<div data-modal="md-stickyUp29" class="kursi_berisi">29</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp29" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">29</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi29" id="frmKursi29" method="post" action="#">
													<div id="md-stickyUp29" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="29">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_30 = $apps->cekKursi("30");													
														if($no_bangku_30 == "ADA"){
													?>
														<div data-modal="md-stickyUp30" class="kursi_berisi">30</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp30" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">30</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi30" id="frmKursi30" method="post" action="#">
													<div id="md-stickyUp30" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="30">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_31 = $apps->cekKursi("31");													
														if($no_bangku_31 == "ADA"){
													?>
														<div data-modal="md-stickyUp31" class="kursi_berisi">31</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp31" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">31</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi31" id="frmKursi31" method="post" action="#">
													<div id="md-stickyUp31" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="31">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form></td>
											<td>
												<center>
													<?php
														$no_bangku_32 = $apps->cekKursi("32");													
														if($no_bangku_32 == "ADA"){
													?>
														<div data-modal="md-stickyUp32" class="kursi_berisi">32</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp32" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">32</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi32" id="frmKursi32" method="post" action="#">
													<div id="md-stickyUp32" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="32">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_33 = $apps->cekKursi("33");													
														if($no_bangku_33 == "ADA"){
													?>
														<div data-modal="md-stickyUp33" class="kursi_berisi">33</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp33" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">33</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi33" id="frmKursi33" method="post" action="#">
													<div id="md-stickyUp33" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="33">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_34 = $apps->cekKursi("34");													
														if($no_bangku_34 == "ADA"){
													?>
														<div data-modal="md-stickyUp34" class="kursi_berisi">34</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp34" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">34</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi34" id="frmKursi34" method="post" action="#">
													<div id="md-stickyUp34" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="34">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_35 = $apps->cekKursi("35");													
														if($no_bangku_35 == "ADA"){
													?>
														<div data-modal="md-stickyUp35" class="kursi_berisi">35</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp35" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">35</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi35" id="frmKursi35" method="post" action="#">
													<div id="md-stickyUp35" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="35">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_36 = $apps->cekKursi("36");													
														if($no_bangku_36 == "ADA"){
													?>
														<div data-modal="md-stickyUp36" class="kursi_berisi">36</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp36" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">36</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi36" id="frmKursi36" method="post" action="#">
													<div id="md-stickyUp36" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="36">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_37 = $apps->cekKursi("37");													
														if($no_bangku_37 == "ADA"){
													?>
														<div data-modal="md-stickyUp37" class="kursi_berisi">37</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp37" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">37</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi37" id="frmKursi37" method="post" action="#">
													<div id="md-stickyUp37" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="37">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_38 = $apps->cekKursi("38");													
														if($no_bangku_38 == "ADA"){
													?>
														<div data-modal="md-stickyUp38" class="kursi_berisi">38</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp38" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">38</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi38" id="frmKursi38" method="post" action="#">
													<div id="md-stickyUp38" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="38">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_39 = $apps->cekKursi("39");													
														if($no_bangku_39 == "ADA"){
													?>
														<div data-modal="md-stickyUp39" class="kursi_berisi">39</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp39" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">39</div>
													<?php		
														}
													?>
													
												</center>
											<form name="frmKursi39" id="frmKursi39" method="post" action="#">
													<div id="md-stickyUp39" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="39">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_40 = $apps->cekKursi("40");													
														if($no_bangku_40 == "ADA"){
													?>
														<div data-modal="md-stickyUp40" class="kursi_berisi">40</div>	
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp40" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">40</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi40" id="frmKursi40" method="post" action="#">
													<div id="md-stickyUp40" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="40">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>
										  <tr>											
											<td>
												<center>
													<?php
														$no_bangku_41 = $apps->cekKursi("41");													
														if($no_bangku_41 == "ADA"){
													?>
														<div data-modal="md-stickyUp41" class="kursi_berisi">41</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp41" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">41</div>
													<?php															
														}
													?>
													
												</center>
											<form name="frmKursi41" id="frmKursi41" method="post" action="#">
													<div id="md-stickyUp41" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="41">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_42 = $apps->cekKursi("42");													
														if($no_bangku_42 == "ADA"){
													?>
														<div data-modal="md-stickyUp42" class="kursi_berisi">42</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp42" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">42</div>
													<?php
														}
													?>
												</center>
											<form name="frmKursi42" id="frmKursi42" method="post" action="#">
													<div id="md-stickyUp42" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="42">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td style="width: 30px;">&nbsp;</td>
											<td>
											<center>
												<?php
													$no_bangku_43 = $apps->cekKursi("43");													
													if($no_bangku_43 == "ADA"){
												?>
													<div data-modal="md-stickyUp43" class="kursi_berisi">43</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp43" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">43</div>
												<?php		
													}
												?>
												
											</center>
											<form name="frmKursi43" id="frmKursi43" method="post" action="#">
													<div id="md-stickyUp43" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="43">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_44 = $apps->cekKursi("44");													
														if($no_bangku_44 == "ADA"){
													?>
														<div data-modal="md-stickyUp44" class="kursi_berisi">44</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp44" class="kursi_kosongbook <?php echo $bisa_isi_tiket; ?>">44</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi44" id="frmKursi44" method="post" action="#">
													<div id="md-stickyUp44" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="44">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>
										  <tr>
											<td colspan="5" style="text-align: center;"><div class="box_belakang">&nbsp;</div></td>
										  </tr>
									</table>
								</div>
							  </div>
						 </div>
						 
						 <!-- Display Record -->
						 
						 <div class="col-md-9">
							  <div class="card ">
								<div class="card-content">								
									<form action="#" method="POST" name="frmEkonomi" id="frmEkonomi">	
										<table style="width: 100%; border-bottom: 2px solid #CCC; margin-bottom: 6px;">
											<tr>
													<td style="width: 50%;">
														<table>
															<tr>
																<td style="width: 21%;">Nomor Plat</td>
																<td style="width: 25%;">
																	<select style="width: 160px; text-transform: uppercase;" name="txtplat" id="txtplat">
																		<option value=''>- Pilih Bus -</option>
																		<?php
																			$bus = "SELECT no_plat, nm_bus, nm_supir FROM _tbl_bus WHERE jum_kursi='44' ORDER BY no_plat ASC";
																			$hb  = mysql_query($bus);
																			while($rb = mysql_fetch_array($hb)){
																				if($rb['no_plat'] == $no_plat){
																					echo "
																						<option value='$rb[no_plat]-$rb[nm_supir]' selected>$rb[no_plat]</option>
																					";
																				}
																				else{
																					echo "
																						<option value='$rb[no_plat]-$rb[nm_supir]'>$rb[no_plat]</option>
																					";
																				}
																				
																			}
																		?>
																	</select>
																	<!-- <input type="text" class="form-control input-xs" style="width: 160px; text-transform: uppercase;" required name="txtplat" id="txtplat" value="<?php echo $no_plat; ?>" /> -->
																</td>
															</tr>
															<tr>
																<td>Nama Supir</td>
																<td>
																	<input type="hidden" class="form-control input-xs" name="tmp_jum_kursi" value="44" />		
																	<input type="text" class="form-control input-xs" style="width: 240px" required name="txtnmsupir" id="txtnmsupir" value="<?php echo $nm_supir; ?>" readonly />
																	<input type="hidden" class="form-control input-xs" style="width: 240px" required name="txtnomor" id="txtnomor" readonly />
																</td>
															</tr>
															<tr>
																<td>Tgl Berangkat</td>
																<td>
																	<input type="date" class="form-control input-xs" style="width: 160px;" name="txttgl" required value="<?php echo $t_berangkat; ?>">
																</td>
															</tr>
															<tr>
																<td>Jam Berangkat</td>
																<td>
																	<select style="width: 160px; text-transform: uppercase;" required name="txtjam" id="txtjam">
																		<?php
																			$qjam  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
																			$hjam  = mysql_query($qjam);
																			while($rjam = mysql_fetch_array($hjam)){
																				if($rjam['jam'] == $j_berangkat){
																					echo "
																							<option value='$rjam[jam]' selected>$rjam[jam] WIB</option>
																				 		 ";
																				}
																				else{
																					echo "
																							<option value='$rjam[jam]'>$rjam[jam] WIB</option>
																						";
																				}
																				
																			}
																		?>
																	</select>
																	<!--<input type="text" class="form-control input-xs" style="width: 160px;" name="txtjam" required  value="<?php echo $j_berangkat; ?>" />-->
																</td>
															</tr>
														</table>
													</td>
													<td style="vertical-align: top; width: 50%;">
														<table>															
															<tr>
																<td style="width: 4%;">Tujuan</td>
																<td style="width: 46%;">																	
																	<select name="txttujuan" id="txttujuan" style="width: 100%;">
																		<?php
																			$tuj = "SELECT * FROM _tbl_harga_tiket WHERE class_bus='NON AC BIASA' ORDER BY tujuan ASC";
																			$ht  = mysql_query($tuj);
																			while($x = mysql_fetch_array($ht)){
																				if($r['id_tujuan'] == $x['id']){
																					echo "
																						<option value='$x[id]' selected>$x[tujuan]</option>
																					 ";
																				}
																				else{
																					echo "
																						<option value='$x[id]'>$x[tujuan]</option>
																					 ";
																				}
																				
																			}
																		?>																		
																	</select>
																</td>
															</tr>															
															<tr>
																<td style="width: 15%;">&nbsp;</td>
																<td>
																	
																		<button class="btn btn-primary btn-block hover" type="submit" id="tbl_Simpan">
																			<i class="icon icon-left mdi mdi-check-all" id="ic_simpan"></i> <span id="txt_Simpan">SIMPAN</span>
																		</button>
																		<!--
																		<button class="btn btn-success hover" type="button" id="cetakSJ">
																			<i class="icon icon-left mdi mdi-print"></i> CETAK SURAT JALAN
																		</button>																		
																		-->
																	
																	<hr style="margin-bottom: 8px; margin-top: 8px;"/>
																	<button data-modal="md-stickyUpMulti" class="md-trigger btn btn-danger btn-block hover" type="button" id="tiketMulti">
																			<i class="icon icon-left mdi mdi-edit"></i> BELI TIKET BANYAK PENUMPANG
																	</button>																	
																</td>
															</tr>
														</table>
													</td>
											</tr>											
										</table>
									 </form>									 
									 <table id="table1" class="table table-striped table-hover" style="border-top: 2px solid #CCC; width: 100%; background-color: #F8F8F8;">
										<thead>
										  <tr>
											<th style="width:12%; text-align: center">No. Bangku</th>
											<th style="width:30%;">Nama Penumpang</th>
											<th style="width:20%;">Alamat</th>
											<th style="width:15%;">No.Hp</th>											
											<th style="width:5%;"></th>
										  </tr>
										</thead>
                    					<tbody style="width: 100%;">
                    	<?php
												$query = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='".$r['id']."'";
												
												$hasil = mysql_query($query);												
												while($row = mysql_fetch_array($hasil)){															
															echo "
																		<tr>
																			<td><b><center>".$row[no_bangku]."</center></b></td>
																			<td class='user-avatar'>".$row[nm_penumpang]."
																			</td>
																			<td>".$row[alamat]."</td>
																			<td>".$row[no_hp]."</td>
																			<td class='actions'>
																				<a href='delPenumpang.php?id=$row[id]&kursi=$row[no_bangku]&jadwal_code=$row[kd_jadwal]&view=non_ac_biasa&nomor=".$_GET['nomor']."&plut_num_eko_41=".$_GET['plut_num_eko_41']."&plut_num_ac_41=".$_GET['plut_num_ac_41']."&plut_num_ac_32=".$_GET['plut_num_ac_32']."&plut_num_se_18=".$_GET['plut_num_se_18']."' onClick=\"return confirm('Yakinkan anda untuk menghapus penumpang dengan nama: $row[nm_penumpang] ?')\" class='icon'><i class='mdi mdi-delete'></i></a>
																			</td>
																		</tr>
																	 ";
												}
										  ?>
										</tbody>
									  </table>
								</div>
							  </div>
						 </div>
					</div>
												<form name="frmMultiKursi" id="frmMultiKursi" method="POST" action="#">
																		<div id="md-stickyUpMulti" class="modal-container modal-effect-7">
																			<div class="modal-content">
																				
																				<div class="modal-body">
																					<table id="penumpang_append" class="info" width="100%">
																						<tr id="buat_nama">
																							<td style="width: 22%;">
																								Pilih Kursi
																							</td>
																							<td style="padding-left: 5px; " colspan="2">
																								<select name="pil_kursi" id="pil_kursi" multiple>
																									<?php																										
																										$tmp_kursi = "SELECT kursi_num FROM _tbm_tempkursi WHERE sts_kursi='0' AND id_jadwal='$r[id]' AND no_plat='$r[no_plat]' AND tgl_berangkat='$r[tgl_berangkat]'";
																										$h_tmp 	   = mysql_query($tmp_kursi);
																										while($r_kursi = mysql_fetch_array($h_tmp)){
																											echo "<option vapue='$r_kursi[kursi_num]'>$r_kursi[kursi_num]</option>";
																										}
																									?>
																								</select>	
																								<input type="hidden" name="tmp_kursi" id="tmp_kursi" />
																								<input type="hidden" name="txt_tujuanhideMulti" value="<?php echo $r['tujuan']; ?>" />
																								<input type="hidden" name="txt_darinhideMulti" value="<?php echo $r['dari']; ?>" />
																								<input type="hidden" name="txt_idhideMulti" id="txt_idhideMulti" value="<?php echo $r['id']; ?>" />																								
																							</td>
																						</tr>																						
																						<tr>
																							<td>
																								Alamat
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtAlamatMulti" class="form-control input-sm"></textarea>
																							</td>
																						</tr>
																						<tr>
																							<td>
																								Nomor. HP
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<input name="txtNoHpMulti" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																							</td>				
																						</tr>
																						<tr>
																							<td>
																								Total Ongkos
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																							<div class="input-group"><span class="input-group-addon">Rp</span>
																								<input type="hidden" name="hiddenOngkos" id="hiddenOngkos" value="<?php echo $r['harga_tiket']; ?>" />
																								<input name="txtOngkosMulti" id="txtOngkosMulti" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" class="form-control input-sm" readonly />
																							</td>				
																						</tr>
																						<tr>
																							<td>
																								Keterangan
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtket" class="form-control input-sm"></textarea>
																								<input type="hidden" name="hargaNormal" value="<?php echo $r['harga_tiket']; ?>" />
																							</td>				
																						</tr>
																					</table>
																				</div>
																				<div class="modal-footer">
																					<div class="btn-group btn-space">        	
																						<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																						<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="modal-overlay"></div>
																	</form>
<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){			
			$("#pil_kursi").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Kursi tidak ada!",
				width: "100%"
			});				
			$("#pil_kursi").chosen().change(function(){	
				
				if($("#pil_kursi").val() == ""){
					$(markup).remove();				
				}
				else{										
					arrData  = new Array($("#pil_kursi").chosen().val());	
					var valData  = arrData[0];
					arrKursi = valData.pop();
					var jum_pen = arrData[0].length
					if(jum_pen == 0){
						var hit_penumpang = 1;
					}{
						var hit_penumpang = 1 + jum_pen;
					}
					var getOngkos   = $("#hiddenOngkos").val();
					var ongkosMulti = hit_penumpang * parseInt(getOngkos);
					$("#txtOngkosMulti").val(ongkosMulti);								
					$("#tmp_kursi").val($("#pil_kursi").chosen().val());
					var markup = "<tr><td style='vertical-align: middle;'>Nama Penumpang </td><td style='padding-left: 5px; width: 250px;'><input name='txtNamaPenumpang" + arrKursi +"' id='txtNamaPenumpang"+ arrKursi +"' type='text' class='form-control input-xs' required></td><td style='vertical-align: bottom;'><div class='input-group'><span class='input-group-addon input-xs'>Rp</span><input name='txtOPMulti_"+ arrKursi +"' id='txtOPMulti_"+ arrKursi +"' style='width: 100px;' value='<?php echo $r['harga_tiket']; ?>' type='number' class='form-control input-xs' required></div></td></tr>";
					$(markup).insertAfter("#buat_nama");	
					
					//localStorage.setItem("Ongkos_"+ arrKursi, getOngkos);
					
					/**----------------------------------
					 * Hapus Data dari localStorage
					 * localStorage.removeItem(key);
					 **----------------------------------**/
					 
					/**-------------------------------------
					 * Mengambil data localStorage
					 * localStorage.getItem('key');
					 **----------------------------------**/
					 
					 var jumData = localStorage.length
					 //console.log(arrKursi);
					 //console.log("Jumlah Data:" + jumData);
					 
					 for(y=0; y<=jumData; y++){
						
					 }
				}				
			});
			
			$("#btnSaveMulti").click(function(){
				saveMultiKursi();
			});

			$("#frmMultiKursi").submit(function(e) {			
				saveMultiKursi();
				e.preventDefault();			
			});	

			function saveMultiKursi(){
				if($("#pil_kursi").chosen().val()==""){
					alert("Pilih Kursi Terlebih dahulu");
				}
				else{
					var str = $("#frmMultiKursi").serialize();
					$.ajax({
						type: "POST",
						url: "saveMulti.php",
						data: str,
						success: function(msgNew){																		
							window.open('<?php echo $apps->setHost("printTiketMulti.php"); ?>?id='+ $("#txt_idhideMulti").val() +'&no_kursi='+ $("#tmp_kursi").val(),'PrintTiket', 'width=700, height=340');						
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
							//console.log(msgNew);
										
						}
					})
				}				
			}

			$("#txtplat").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Nomor plat tidak ada!",
				width: "100%"
			});
			$("#txttujuan").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Tujuan tidak ada!",
				width: "100%"
			});
			$("#txtplat").change(function(){
				var nama_supir = $("#txtplat option:selected").val();				
				var has_nama   = nama_supir.split("-");
				$("#txtnmsupir").val(has_nama[1]);
				$("#txtnomor").val(has_nama[0]);
				//console.log(has_nama);
			});
			/**
			 * Fungsi Simpan Tiket [Nomor Bangku] Untuk PATAS/EKONOMI
			 * 
			 **/

			 // Kursi No. 1
      		$("#frmKursi1").submit(function(e) {			
				saveEkonomi_01();
				e.preventDefault();			
			});	

			function saveEkonomi_01(){
				var str = $("#frmKursi1").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){											
						var obj = JSON.parse(msg);
						console.log(obj);						
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.location.reload();
					}
				})
			}

			 // Kursi No. 2
      		$("#frmKursi2").submit(function(e) {			
				saveEkonomi_02();
				e.preventDefault();			
			});	

			function saveEkonomi_02(){
				var str = $("#frmKursi2").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);						
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
					}
				})
			}


			 // Kursi No. 3
      		$("#frmKursi3").submit(function(e) {			
				saveEkonomi_03();
				e.preventDefault();			
			});	

			function saveEkonomi_03(){
				var str = $("#frmKursi3").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
						
					}
				})
			}


			 // Kursi No. 4
      		$("#frmKursi4a").submit(function(e) {			
				saveEkonomi_04a();
				e.preventDefault();			
			});	

			function saveEkonomi_04a(){
				var str = $("#frmKursi4a").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 5
      		$("#frmKursi5").submit(function(e) {			
				saveEkonomi_05();
				e.preventDefault();			
			});	

			function saveEkonomi_05(){
				var str = $("#frmKursi5").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 6
      		$("#frmKursi6").submit(function(e) {			
				saveEkonomi_06();
				e.preventDefault();			
			});	

			function saveEkonomi_06(){
				var str = $("#frmKursi6").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 7
      		$("#frmKursi7").submit(function(e) {			
				saveEkonomi_07();
				e.preventDefault();			
			});	

			function saveEkonomi_07(){
				var str = $("#frmKursi7").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 8
      		$("#frmKursi8").submit(function(e) {			
				saveEkonomi_08();
				e.preventDefault();			
			});	

			function saveEkonomi_08(){
				var str = $("#frmKursi8").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 9
      		$("#frmKursi9").submit(function(e) {			
				saveEkonomi_09();
				e.preventDefault();			
			});	

			function saveEkonomi_09(){
				var str = $("#frmKursi9").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No.10
      		$("#frmKursi10").submit(function(e) {			
				saveEkonomi_10();
				e.preventDefault();			
			});	

			function saveEkonomi_10(){
				var str = $("#frmKursi10").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 11
      		$("#frmKursi11").submit(function(e) {			
				saveEkonomi_11();
				e.preventDefault();			
			});	

			function saveEkonomi_11(){
				var str = $("#frmKursi11").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 12
      		$("#frmKursi12").submit(function(e) {			
				saveEkonomi_12();
				e.preventDefault();			
			});	

			function saveEkonomi_12(){
				var str = $("#frmKursi12").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			
			 // Kursi No. 13
      		$("#frmKursi13").submit(function(e) {			
				saveEkonomi_13();
				e.preventDefault();			
			});	

			function saveEkonomi_13(){
				var str = $("#frmKursi13").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 14
      		$("#frmKursi14").submit(function(e) {			
				saveEkonomi_14();
				e.preventDefault();			
			});	

			function saveEkonomi_14(){
				var str = $("#frmKursi14").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);				
						//window.location.reload();			
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 15
      		$("#frmKursi15").submit(function(e) {			
				saveEkonomi_15();
				e.preventDefault();			
			});	

			function saveEkonomi_15(){
				var str = $("#frmKursi15").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 16
      		$("#frmKursi16").submit(function(e) {			
				saveEkonomi_16();
				e.preventDefault();			
			});	

			function saveEkonomi_16(){
				var str = $("#frmKursi16").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);			
						//window.location.reload();				
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 17
      		$("#frmKursi17").submit(function(e) {			
				saveEkonomi_17();
				e.preventDefault();			
			});	

			function saveEkonomi_17(){
				var str = $("#frmKursi17").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 18
      		$("#frmKursi18").submit(function(e) {			
				saveEkonomi_18();
				e.preventDefault();			
			});	

			function saveEkonomi_18(){
				var str = $("#frmKursi18").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 19
      		$("#frmKursi19").submit(function(e) {			
				saveEkonomi_19();
				e.preventDefault();			
			});	

			function saveEkonomi_19(){
				var str = $("#frmKursi19").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 20
      		$("#frmKursi20").submit(function(e) {			
				saveEkonomi_20();
				e.preventDefault();			
			});	

			function saveEkonomi_20(){
				var str = $("#frmKursi20").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 21
      		$("#frmKursi21").submit(function(e) {			
				saveEkonomi_21();
				e.preventDefault();			
			});	

			function saveEkonomi_21(){
				var str = $("#frmKursi21").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);				
						//window.location.reload();			
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 22
      		$("#frmKursi22").submit(function(e) {			
				saveEkonomi_22();
				e.preventDefault();			
			});	

			function saveEkonomi_22(){
				var str = $("#frmKursi22").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 23
      		$("#frmKursi23").submit(function(e) {			
				saveEkonomi_23();
				e.preventDefault();			
			});	

			function saveEkonomi_23(){
				var str = $("#frmKursi23").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 24
      		$("#frmKursi24").submit(function(e) {			
				saveEkonomi_24();
				e.preventDefault();			
			});	

			function saveEkonomi_24(){
				var str = $("#frmKursi24").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 25
      		$("#frmKursi25").submit(function(e) {			
				saveEkonomi_25();
				e.preventDefault();			
			});	

			function saveEkonomi_25(){
				var str = $("#frmKursi25").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 26
      		$("#frmKursi26").submit(function(e) {			
				saveEkonomi_26();
				e.preventDefault();			
			});	

			function saveEkonomi_26(){
				var str = $("#frmKursi26").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 27
      		$("#frmKursi27").submit(function(e) {			
				saveEkonomi_27();
				e.preventDefault();			
			});	

			function saveEkonomi_27(){
				var str = $("#frmKursi27").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 28
      		$("#frmKursi28").submit(function(e) {			
				saveEkonomi_28();
				e.preventDefault();			
			});	

			function saveEkonomi_28(){
				var str = $("#frmKursi28").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 29
      		$("#frmKursi29").submit(function(e) {			
				saveEkonomi_29();
				e.preventDefault();			
			});	

			function saveEkonomi_29(){
				var str = $("#frmKursi29").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 30
      		$("#frmKursi30").submit(function(e) {			
				saveEkonomi_30();
				e.preventDefault();			
			});	

			function saveEkonomi_30(){
				var str = $("#frmKursi30").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 31
      		$("#frmKursi31").submit(function(e) {			
				saveEkonomi_31();
				e.preventDefault();			
			});	

			function saveEkonomi_31(){
				var str = $("#frmKursi31").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 32
      		$("#frmKursi32").submit(function(e) {			
				saveEkonomi_32();
				e.preventDefault();			
			});	

			function saveEkonomi_32(){
				var str = $("#frmKursi32").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 33
      		$("#frmKursi33").submit(function(e) {
				saveEkonomi_33();
				e.preventDefault();			
			});	
			
			function saveEkonomi_33(){
				var str = $("#frmKursi33").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);			
						//window.location.reload();				
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 34
      		$("#frmKursi34").submit(function(e) {			
				saveEkonomi_34();
				e.preventDefault();			
			});	

			function saveEkonomi_34(){
				var str = $("#frmKursi34").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 35
      		$("#frmKursi35").submit(function(e) {			
				saveEkonomi_35();
				e.preventDefault();			
			});	

			function saveEkonomi_35(){
				var str = $("#frmKursi35").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 36
      		$("#frmKursi36").submit(function(e) {			
				saveEkonomi_36();
				e.preventDefault();			
			});	

			function saveEkonomi_36(){
				var str = $("#frmKursi36").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 37
      		$("#frmKursi37").submit(function(e) {			
				saveEkonomi_37();
				e.preventDefault();			
			});	

			function saveEkonomi_37(){
				var str = $("#frmKursi37").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 38
      		$("#frmKursi38").submit(function(e) {			
				saveEkonomi_38();
				e.preventDefault();			
			});	

			function saveEkonomi_38(){
				var str = $("#frmKursi38").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 39
      		$("#frmKursi39").submit(function(e) {			
				saveEkonomi_39();
				e.preventDefault();			
			});	

			function saveEkonomi_39(){
				var str = $("#frmKursi39").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 40
      		$("#frmKursi40").submit(function(e) {			
				saveEkonomi_40();
				e.preventDefault();			
			});	

			function saveEkonomi_40(){
				var str = $("#frmKursi40").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 41
      		$("#frmKursi41").submit(function(e) {			
				saveEkonomi_41();
				e.preventDefault();			
			});	

			function saveEkonomi_41(){
				var str = $("#frmKursi41").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 42
      		$("#frmKursi42").submit(function(e) {			
				saveEkonomi_42();
				e.preventDefault();			
			});	

			function saveEkonomi_42(){
				var str = $("#frmKursi42").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 43
      		$("#frmKursi43").submit(function(e) {			
				saveEkonomi_43();
				e.preventDefault();			
			});	

			function saveEkonomi_43(){
				var str = $("#frmKursi43").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 44
      		$("#frmKursi44").submit(function(e) {			
				saveEkonomi_44();
				e.preventDefault();			
			});	

			function saveEkonomi_44(){
				var str = $("#frmKursi44").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}

			 // Kursi No. 45
      		$("#frmKursi45").submit(function(e) {			
				saveEkonomi_45();
				e.preventDefault();			
			});	

			function saveEkonomi_45(){
				var str = $("#frmKursi45").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 46
      		$("#frmKursi46").submit(function(e) {			
				saveEkonomi_46();
				e.preventDefault();			
			});	

			function saveEkonomi_46(){
				var str = $("#frmKursi46").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=700, height=340');	
					}
				})
			}


			 // Kursi No. 48
      		$("#frmKursi48").submit(function(e) {			
				saveEkonomi_48();
				e.preventDefault();			
			});	

			function saveEkonomi_48(){
				var str = $("#frmKursi48").serialize();
				$.ajax({
					type: "POST",
					url: "saveNonAC.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();	
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?non_ac_biasa=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=650, height=340');																	
						if(msg == "OK"){
							setTimeout("menyimpan()", 800);								
						}
						else{

						}
					}
				})
			}
		
			/**
			 * Fungsi Simpan Nomor Plat, Nama Supir dan Tujuan
			 *  
			 **/ 
			$("#frmEkonomi").submit(function(e) {
				if($("#txtplat").val() == ""){
					alert("Pilih Bus terlebih dahulu!!");
					return false;
				}
				else{
					var conf = confirm('Yakin untuk menyimpan data keberangkatan ?');
					if(conf == true){
						saveKeberangkatan();
						e.preventDefault();			
					}
					else{
						$("#txtnmsupir").focus();
						return false;
					}
				}
				
			});	
			
			
			function saveKeberangkatan(){				
				var str = $("#frmEkonomi").serialize();
				$.ajax({
					type: "POST",
					url: "saveKeberangkatanBook.php",
					data: str,
					success: function(msg){	
						console.log(msg);					
						if(msg == "OK"){
							setTimeout("savingData()", 800);											
						}
						else{

						}
					}
				})
			}
	})
			function displayMsg(){
					$.extend($.gritter.options, { position: 'bottom-right' });
					$.gritter.add({
							title: "<i class='icon mdi mdi-info'></i> Informasi",
							text: "Data berhasil disimpan",
							class_name: 'color success',
							sticky: true
					});
					return false;					
			}
			function savingData(){
					$("#ic_simapn").hide();
					$("#txt_Simpan").text("SIMPAN...");					
					disableAllLagi();
			}
			function disableAllLagi(){
					$("#frmEkonomi :input").attr("disabled", true);
					$("#cetakSJ").attr("disabled", false);
					setTimeout("kembaliLagi()", 800);
			}
			
			function kembaliLagi(){
				//alert($("#txtnomor").val());
				$("#ic_simapn").show();
				$("#txt_Simpan").text("SIMPAN");
				window.location.href="apps.php?non_ac_biasa=active&nomor="+ $("#txtnomor").val() + "&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
			}
			function kembali(){
					$("#ic_simapn").show();
					$("#txt_Simpan").text("SIMPAN");
					//window.location.href="apps.php?ekonomi=active&nomor=" + $("#txtnomor").val();
			}
</script>