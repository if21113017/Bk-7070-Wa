<?php
session_start();
require_once "Class/ConfigApp.php";
require_once "Class/fungsi_indotgl.php";
$apps = new ConfigApp();
date_default_timezone_set("Asia/Bangkok");
?> 
<div class='col-sm-12'>
    <div class='panel panel-border-color panel-border-color-primary panel-contrast'>
        <div class='panel-heading panel-heading-contrast'>LAPORAN BULANAN                
        </div>
        <div class='panel-body'>	
            <form name="pil_busFrm" id="pil_busFrm" method="POST" action="?mod=lap_bulanan&act=tampil">
                <table class="table">
                    <tr>
                        <th style="width: 120px; vertical-align: middle;">Pilih Bus</th>
                        <td colspan="2">
                            <select name="pil_bus" id="pil_bus" class="form-control input-sm" style="width: 190px;">
                                <option>- Pilih Plat Bus -</option>
                                <?php
                                $sekarang = date("Y-m-d");
                                $sql = "SELECT DISTINCT * FROM _tbl_jadwal GROUP BY no_plat";
                                $sql2 = "SELECT  * FROM _tbl_jadwal";
                                $var1 = mysql_query($sql2);
                                $a = 0;
                                while ($r = mysql_fetch_array($var1)) {
                                    $b[$a] = $r['no_plat'];
                                    $c[$a] = $r['id'];
                                    $a++;
                                }$h = mysql_query($sql);
                                $a = 0;
                                while ($r = mysql_fetch_array($h)) {
                                    $getVal = $r['no_plat'] . "#" . $r['id'];
                                    if ($a == 0) {

                                        echo "<option value='*#*'>Semua Bus</option>";
                                    }
                                    if ($_POST['pil_bus'] == $getVal) {
                                        echo "
                                                        <option value='$r[no_plat]#$r[id]' selected>$r[no_plat]</option>
                                                    ";
                                    } else {
                                        echo "
                                                        <option value='$r[no_plat]#$r[id]'>$r[no_plat]</option>
                                                    ";
                                    }
                                    $a++;
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th style="vertical-align: middle;">Tanggal</th>
                        <td style="width: 190px;">									
                            <input type="text" class="form-control input-xs" name="dari_tgl" id="dari_tgl" required style="width: 190px;" value="<?php echo $_POST[dari_tgl]; ?>" />                                    
                        </td>
                        <td style="width: 10px;">
                            S/D
                        </td>
                        <td>
                            <input type="text" class="form-control input-xs" name="sm_tgl" id="sm_tgl" required style="width: 190px;" value="<?php echo $_POST[sm_tgl]; ?>" />
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td colspan="2">
                            <div class="btn-group">
                                <button class="btn btn-primary" type="submit" name="tampil">Tampilkan </button>
                                <?php
                                if ($_GET['act'] == "tampil") {
                                    echo "
                                                    <button type='button' id='cetak' class='btn btn-success'><i class='icon icon-left mdi mdi-print'></i> Cetak</button>
                                                 ";
                                }
                                ?>
                            </div>
                        </td>
                    </tr>

                </table>
            </form>


            <?php
            if (isset($_POST['tampil'])) {
                $kode = explode("#", $_POST['pil_bus']);
                $nomor = $kode[0];
                $id = $kode[1];
                if ($nomor == "*") {
                    $query = "SELECT * FROM _tbl_tiket WHERE date_modify BETWEEN '$_POST[dari_tgl]' AND '$_POST[sm_tgl]' ORDER BY no_bangku ASC";
                } else {
                    $query = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='$id' AND date_modify BETWEEN '$_POST[dari_tgl]' AND '$_POST[sm_tgl]' ORDER BY no_bangku ASC";
                }
                $hasil = mysql_query($query);
                $ada = mysql_num_rows($hasil);
                echo "
                                <input type='hidden' id='getID' value='$id' />
                                <input type='hidden' id='gettgl' value='" . $_POST['dari_tgl'] . "' />
								<input type='hidden' id='getbln' value='" . $_POST['sm_tgl'] . "' />
                                <input type='hidden' id='getplat' value='$nomor' />
                                ";
                ?>
                <script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
                <script type="text/javascript">
                    $(document).ready(function () {
                        $("#cetak").click(function () {
                            var new_id = $("#getID").val();
                            var newTgl = $("#gettgl").val();
                            var newBln = $("#getbln").val();
                            var newPlat = $("#getplat").val();
                            window.open('<?php echo $apps->setHost("printLapBulanan.php"); ?>?id=' + new_id + '&tgla=' + newTgl + '&tglb=' + newBln + '&platid=' + newPlat, 'CetakSuratJalan', 'width=1080, height=800');
                        });
                    })

                </script>
                <?php
                echo "
                                    <table class='table table-striped'>
                                        <thead>
                                            <tr style='border-top: 2px solid #CCC;'>
                                                <th>No.</th>
                                                <th>No Plat</th>
                                                <th>Tanggal</th>
                                                <th>No Bangku</th>
                                                <th>Nama Penumpang</th>
                                                <th>Alamat</th>
                                                <th>Tujuan</th>
                                                <th>Jumlah Uang</th>
                                                <th>Penjual</th>   
                                            </tr>
                                        </thead>
                                        <tbody>
                                ";
                if ($ada > 0) {
                    $no = 0;
                    while ($row = mysql_fetch_array($hasil)) {
                        $a = 0;
                        foreach ($c as $value) {
                            if ($row[kd_jadwal] == $value) {
                                $row[kd_jadwal] = $b[$a];
                            }

                            $a++;
                        }
                        $no++;
                        echo "  
                                            <tr>
                                                <td style='width: 20px;'>$no.</td>
                                                <td>$row[kd_jadwal]</td>    
                                                <td>$row[date_modify]</td>    
                                                <td>$row[no_bangku]</td>
                                                <td>$row[nm_penumpang]</td>
                                                <td>$row[alamat]</td>
                                                <td>$row[tujuan]</td>    
                                                <td>Rp. ".number_format($row[harga_tiket], 0, ".", ".")."</td>
                                                <td>$row[user_modify]</td>
                                            </tr>
                                         ";
                        $sub_total += $row[harga_tiket];
                    }
                    echo "  
                                            <tr>
                                                <th colspan='5' style='text-align: right;'>Sub Total:</th>
                                                <th>Rp. " . number_format($sub_total, 0, ".", ".") . "</th>
                                            </tr>";
                } else {
                    echo "
                                        <tr>
                                            <td colspan='6'>
                                                <i style='color: red; text-style: italic;'>Tidak ada data</i>
                                            </td>
                                        </tr>
                                    ";
                }

                echo "
                                    </tbody>
                                    </table>
                                ";
            } else {
                
            }
            ?>

        </div>
    </div> 
</div>