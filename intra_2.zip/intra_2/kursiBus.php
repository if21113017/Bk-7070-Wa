<?php
	$kursi = $_POST['getKursi'];
	echo "
			<select class='form-control input-sm' required name='pil_kursi' id='pil_kursi' multiple>							
				";
				for($i=1; $i <= $kursi; $i++){
					echo "<option value='$i'>$i</option>";
				}
			echo "
			</select>			
	     ";
?>
<script type="text/javascript">
      $(document).ready(function(){
		$("#pil_kursi").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Kursi tidak ada!",
          width: "500"
        });

		$("#pil_kursi").chosen().change(function(){
			arrData_se_18  = new Array($("#pil_kursi").chosen().val());	
			var valData_se_18  = arrData_se_18[0];
			arrKursi_se_18 = valData_se_18.pop();						
			var markup_se_18 = "<tr><th style='vertical-align: middle;'>Nama Penumpang </th><td><input name='txtNamaPenumpang_" + arrKursi_se_18 +"' id='txtNamaPenumpang_"+ arrKursi_se_18 +"' type='text' class='form-control input-xs' required style='width: 500px;'></td></tr>";
			$(markup_se_18).insertAfter("#atas_nama");	
			//console.log($("#pil_kursi").chosen().val());
			console.log(arrKursi_se_18);
		});

	  })
</script>