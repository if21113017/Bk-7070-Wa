  <style type="text/css">	 
	  table{
		  border: 0px solid red;
		  padding: 0px;
	  }
	  td{
		  border: 0px solid red;
		  padding: 2px;
		  text-align: left;
		  
	  }
	  .kursi_kosong{
		  padding: 10px;
		  width: 40px;
		  height: 40px;
		  border: 1px solid #CCC;
		  border-radius: 3px;		  
		  background-color: #F7F7F7;
		  color: #000;
		  font-family: Tahoma;
		  font-size: 13px;		
		  font-weight: bold;
		  text-align: center;
		  vertical-align: middle;		 
		  cursor: pointer;		  
	  }
	  .body_mobil{
		  border: 1px solid #E9E9E9;
		  border-radius: 4px;
		  width: 290px;
		  padding: 10px;
		  background-color: #FFFFFF;
	  }
	  .supir{
		  padding: 14px;
		  width: 14px;
		  height: 14px;
		  border: 0px solid #CCC;
		  background-image: url(img/supir.png);
		  background-position: center;
		  background-repeat: no-repeat;
		  background-size: 35px;
		  text-align: center;			
	  }
	  

  </style>
  <div class="row">
	  <div class="col s3">
		  <div class="card ">
			<div class="card-content">
				  <table id="tg-VbtHW" style="width: 275px;">
					  <tr>
						<th colspan="2"><center>KERNET</center></th>
						<th rowspan="12"></th>
						<th colspan="2"><center><img src="img/supir.png" style="width: 40px;"/></center></th>
					  </tr>		  
					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">1</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">2</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">3</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">4</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">5</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">6</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">7</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">8</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">9</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">10</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">11</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">12</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">13</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">14</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">15</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">16</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">17</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">18</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">19</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">20</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">21</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">22</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">23</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">24</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">25</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">26</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">27</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">28</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">30</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">31</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">32</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">33</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">34</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">35</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">36</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">37</div></center></td>
					  </tr>

					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">38</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">39</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">40</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">41</div></center></td>
					  </tr>
					  <tr>
						<td colspan="2"></td>
						<td><center><div class="kursi_kosong light-green accent-4">42</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">43</div></center></td>
					  </tr>
					  <tr>
						<td><center><div class="kursi_kosong light-green accent-4">44</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">45</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">46</div></center></td>
						<td><center><div class="kursi_kosong light-green accent-4">47</div></center></td>
						<td>
							<center>
								<a href="#modal1" class="kursi_kosong light-green accent-4 modal-trigger">48</a>
							</center>
						</td>
					  </tr>
				</table>
			</div>
		  </div>
	 </div>
	 <div class="col s9">
		  <div class="card ">
			<div class="card-content">
				<table style="width: 220px;">
					<tr>
						<td>No. Plat</td><td>: </td>
					</tr>
					<tr>
						<td>Nama Supir</td><td>: </td>
					</tr>
					<tr>
						<td>Tanggal Berangkat</td><td>: </td>
					</tr>
					<tr>
						<td>Jam Berangkat</td><td>: </td>
					</tr>
				</table>
				
				<table class="responsive-table bordered">				  
					<tr>
						<th>Nomor Bangku</th>
						<th>Nama Penumpang</th>
					</tr>		 

				  
				</table>
			</div>
		  </div>
	 </div>
</div>
<div id="modal1" class="modal modal-fixed-footer">
    <div class="modal-content">
        <h4>Modal Header</h4>
        <p>A bunch of text</p>
    </div></center>
    <div class="modal-footer">
        <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Agree</a>
    </div></center>
</div></center>