<?php
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();
    $id  = $_GET['id'];
    $sql = "DELETE FROM _tbl_jam WHERE id='$id'";
    $res = mysql_query($sql);
    if($res == true){
        ?>
            <script type="text/javascript">
                window.location.href="apps.php?mod=dataJam&msg=sukses"
            </script>
        <?php        
    }
    else{        
        ?>
            <script type="text/javascript">
                window.location.href="apps.php?mod=dataJam&msg=error"
            </script>
        <?php
    }
?>