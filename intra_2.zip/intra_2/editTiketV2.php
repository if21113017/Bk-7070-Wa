<?php
    session_start();
    error_reporting(0);
	  date_default_timezone_set("Asia/Jakarta");
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();
    $id   = $_POST['idEdit'];
    $jam  = $_POST['piljam'];
    $tgl  = $_POST['txtTgl'];
    $tujuanTmp = explode("#", $_POST['tuj_book']);
    $idTujuan  = $tujuanTmp[0];

    $pisah  = explode(" - ", $tujuanTmp[1]);
    $dari   = $pisah[0];
    $ke     = $pisah[1];

    $tipeBus   = $_POST['class_bus'];
    $pil_bus   = explode("#", $_POST['pil_bus_']);
    $plat      = $pil_bus[0];
    $NMsupir     = $pil_bus[1];
    if($NMsupir == ""){
      $supir = $_POST['txtsupir'];
    }
    else{
      $supir = $pil_bus[1];
    }
    $ongkos    = $_POST['txtongkos_tmp'];

    $modif_date = date("Y-m-d h:m:s");
    $user      = $_SESSION['namauser'];

    $getJumKursi = mysql_fetch_array(mysql_query("SELECT jum_kursi FROM _tbl_bus WHERE tipe_bus='$tipeBus'"));
    $sql = "
            UPDATE
              _tbl_jadwal
            SET
              kd_bus='$tipeBus',
              no_plat='$plat',
              nm_supir='$supir',
              jam_berangkat='$jam',
              tgl_berangkat='$tgl',
              harga_tiket='$ongkos',
              dari='$dari',
              tujuan='$ke',
              modify_by='$user',
              modify_date='$modif_date'
            WHERE
              id='$id'
            ";
        mysql_query($sql);

        $update_kursi = "UPDATE _tbm_tempkursi SET no_plat='$plat', tgl_berangkat='$tgl', jam_berangkat='$jam' WHERE id_jadwal='$id'";
        mysql_query($update_kursi);
        $res = array(
            'response' => 'OK',
            'query'    => $sql,
            'code'     => 200
        );
        echo json_encode($res);
?>
