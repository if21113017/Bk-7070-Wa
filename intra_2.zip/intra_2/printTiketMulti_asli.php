<!DOCTYPE html>
<html>
<head>
    <title>Cetak Tiket</title>
    <link rel="stylesheet" href="assets/css/invTiket.css" />
</head>
<body onLoad="window.print();">
<?php
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    require_once __DIR__."/Class/ClassIndoTgl.php";
    $id_tiket = $_GET['id'];
    $no_kursi = $_GET['no_kursi'];

    $get_jadwal = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_jadwal WHERE id='$id_tiket'"));
	$kursi      = str_replace(",", "','", "'".$no_kursi."'");	
    $tiket      = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_tiket WHERE kd_jadwal='$id_tiket' AND no_bangku IN ($kursi)"));	
	
	$get_nama   = "SELECT nm_penumpang, harga_tiket FROM _tbl_tiket WHERE kd_jadwal='$id_tiket' AND no_bangku IN ($kursi)";		
	$h          = mysql_query($get_nama);
	
	$tipe_class = $get_jadwal['kd_bus'];
	if($tipe_class == "non_ac_biasa"){
		$kelas = "EKONOMI";
	}
	elseif($tipe_class == "non_ac_toilet"){
		$kelas = "EKONOMI TOILET";
	}
	else{
		$kelas = "AC TOILET";
	}
    echo "<div class='box_tiket'>
            <table>
                <tr>
                    <td class='td_atas' style='vertical-align: bottom;'>
						<div class='info_tiket'>T I K E T</div>
						<span class='tgl_info'>".hariIndo($get_jadwal['tgl_berangkat']).", ".tgl_indo($get_jadwal['tgl_berangkat'])."</span>
                    </td>
					<td style='text-align: center; width: 315px; vertical-align: middle;'>
						<div class='pt_class'>
							PT. INTRA
						</div>
						<div class='ket_class'>
							ANGKUTAN BUS UMUM
						</div>
						<div class='jln_class'>
							Jl. Sisingamangara No. 194. Telp: 24701 - Pematang Siantar
						</div>
					</td>
                </tr>
            </table>
            <div class='tgl_atas'></div>
            <div class='box_isi'>  
            <table>
                <tr>
                    <td class='td_left' style='vertical-align: top;'>Nama</td>
                    <td class='td_center' style='vertical-align: top;'>: 
						 <ul style='margin-top: -14px; margin-left: -16px; margin-bottom: 0px; font-family: 'Roboto', Arial, sans-serif; font-size: 12px;'>";
							while($r = mysql_fetch_array($h)){
								echo "<li>". $r['nm_penumpang']."</li>";
								$tot_tiket += $r['harga_tiket'];
							}
							echo "
						</ul>
					</td>
                    <td rowspan='8' class='td_right'>
                        <div class='info'>No. Kursi</div>
                        <div class='no_kursiMulti'>
                            $no_kursi
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class='td_left'>Alamat</td>
                    <td class='td_center'>: $tiket[alamat]</td>
                </tr>
                <tr>
                    <td class='td_left'>No. HP</td>
                    <td class='td_center'>: $tiket[no_hp]</td>
                </tr>
                <tr>
                    <td class='td_left'>Dari</td>
                    <td class='td_center'>: $tiket[dari] - $tiket[tujuan]</td>
                </tr>
				<tr>
                    <td class='td_left'>Kelas Bus</td>
                    <td class='td_center'>: &nbsp;&nbsp;$kelas</td>
                </tr>
				";
				/**
				echo "
                <tr>
                    <td class='td_left'>No. Plat</td>
                    <td class='td_center'>: $get_jadwal[no_plat]</td>
                </tr>";**/
				echo "
                <tr>
                    <td class='td_left'>Jam</td>
                    <td class='td_center'>: $get_jadwal[jam_berangkat] WIB</td>
                </tr>
                <tr>
                    <td class='td_left'>Ongkos</td>
                    <td class='td_center'>: Rp.".number_format($tot_tiket, 2, ",", ".")."-</td>
                </tr>
            </table>
            </div>
            <div class='info_thanks'>
                Terima Kasih, Semoga anda selamat sampai tujuan.
            </div>
        </div>
         ";
?>
</body>
</html>