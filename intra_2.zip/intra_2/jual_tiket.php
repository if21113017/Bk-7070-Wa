<div class="col-md-12" style="margin-top: 10px;">
 <div class="panel panel-border-color panel-border-color-primary panel-contrast">
    <div class="panel-heading panel-heading-contrast">
		<b>PILIH JAM KEBERANGKATAN</b>
		<div class="btn-group pull-right" style="margin-top: -10px; margin-right: 24px;">
			<button onClick="window.location.href='apps.php?view=home'" class="btn btn-danger hover"><i class="glyphicon glyphicon-arrow-left"></i>&nbsp; KEMBALI KE HOME</button>
			<button type="button" class="btn btn-info hover" onClick="window.location.reload();"><i class="icon mdi mdi-refresh"></i> REFRESH</button>
		</div>
	</div>
	
    <div class="panel-body">
		<div role="alert" class="alert alert-success alert-icon alert-icon-border alert-dismissible">
			<div class="icon"><span class="mdi mdi-info-outline"></span></div>
            <div class="message" style="font-size: 16px;">
				<button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="mdi mdi-close"></span></button>
				<?php echo strtoupper("<strong>Info!</strong> Silahkan pilih <b>Jam Keberangkatan</b> terlebih dahulu sebelum melakukan penjualan tiket."); ?>
			</div>
        </div>
        <?php
            require_once __DIR__."/Class/ConfigApp.php";
            $apps = new ConfigApp();

            $sql = "SELECT id, jam FROM _tbl_jam ORDER BY jam ASC";
            $h   = mysql_query($sql);
            
			/**
			if($r_uri['uri'] != ""){
			    $uri_get = $r_uri['uri'];
			}
			else{
			    $uri_get = "?mod=welcomeApp&view=non_ac_biasa&non_ac_biasa=active&menu=false";
			}
					
			$cek_status = "SELECT status FROM _tbl_jadwal WHERE status='0'";
			$h_status   = mysql_query($cek_status);
			$ada_status = mysql_num_rows($h_status);					
			if($ada_status > 0){
			}
			else{
			    $query = "UPDATE _tbl_uri_temp SET uri='' WHERE id='1'";
				mysql_query($query);
			}
			**/
            while($r = mysql_fetch_array($h)){
				$cek_uri = "SELECT * FROM _tbl_uri_temp WHERE id='$r[id]'";
				$h_uri   = mysql_query($cek_uri);
				$r_uri   = mysql_fetch_array($h_uri);
				$uri_get = $r_uri['uri'];
				if($uri_get == ""){
					$setURI = "?mod=welcomeApp&view=non_ac_biasa&non_ac_biasa=active&menu=false&jam_sel=$r[jam]&id=$r[id]";
				}
				else{
					$setURI = $r_uri['uri'];
				}
                echo "
                    <div class='newcard newcard-1' onClick=\"window.location.href='$setURI'\">
                        <i class='icon mdi mdi-time' style='font-size: 22px;'></i>
                        <p>".$r['jam']."</p>
                    </div>
                    ";
            }
        ?>
    </div>
 </div>
 </div>
</div