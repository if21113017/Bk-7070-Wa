<?php
	echo "
		  <div style='margin-left: -10px;' role='alert' class='alert alert-primary alert-icon alert-icon-border alert-dismissible'>
				<div class='icon'><span class='mdi mdi-info-outline'></span></div>
				<div class='message'>
					<button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>
					<strong>Info!</strong> Selamat datang (<b>".$_SESSION['namauser']."</b>) dihalaman Administrator Bus Ticketing System. <br />Silahkan klik tombol warna biru <b>JUAL TIKET</b> untuk melakukan penjualan tiket ke penumpang.<br />
					<b class='label label-danger' style='border-radius: 2px 0px 0px 2px;'><span aria-hidden='true' class='mdi mdi-info-outline'></span> Tips</b><span style='border-radius: 0px 2px 2px 0px;' class='label label-success'><i>Silahkan ganti password anda secara berkala untuk keamanan sistem</i>.</span>
					
				</div>
			</div>
		  

		  
		  <div class='row'>
			<div class='col-md-6' style='margin-left: -10px;'>
				<div class='panel panel-border-color panel-border-color-primary panel-contrast'>
					<div class='panel-heading panel-heading-contrast'>MENU CEPAT
                </div>
                <div class='panel-body'>
					<center>
					<a href='?mod=booking' class='tombol' style='margin-left: 0px;'>BOOKING TIKET</a>
					<a href='?mod=bookPanjar&menu=false' class='tombol'>DATA BOOKING PANJAR</a>
					</center>
				</div>
			</div>
		  </div>
		  <div class='row'>
			<div class='col-md-6' style='margin-left: -10px;'>
				<div class='panel panel-border-color panel-border-color-danger panel-contrast'>
					<div class='panel-heading panel-heading-contrast'>MENU LAPORAN
                </div>
                <div class='panel-body'>
					<center>
					<a href='?mod=lap_harian' class='btn btn-xl btn-primary btn-hover'><i class='icon mdi mdi-chart'></i> LAPORAN HARIAN</a>
					<a href='?mod=lap_bulanan' class='btn btn-xl btn-success'><i class='icon mdi mdi-calendar'></i> LAPORAN BULANAN</a>	<br />			
					<a href='?mod=lap_booking' class='btn btn-xl btn-warning' style='margin-top: 8px;'><i class='icon mdi mdi-bus'></i> LAPORAN BOOKING TIKET</a>
					<a href='?mod=lap_keu_all' class='btn btn-xl btn-danger' style='margin-top: 8px;'><i class='icon mdi mdi-bus'></i> LAPORAN KEUANGAN ALL</a>
					</center>
				</div>
			</div>
		  </div>
		  
		 ";
