<?php
	error_reporting(0);
	session_start();
	require_once __DIR__."/Class/RouteApp.php";

    $app = new RouteApp();
	if(empty($_SESSION['namauser']) || empty($_SESSION['token'])){
		$app->redirectPage("attempt");
	}
	else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="assets/img/logo.png">
    <title>Bus Ticketing System | Administrator</title>
    <link rel="stylesheet" type="text/css" href="assets/lib/perfect-scrollbar/css/perfect-scrollbar.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/lib/material-design-icons/css/material-design-iconic-font.min.css"/>
	  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="assets/lib/jquery.vectormap/jquery-jvectormap-1.2.2.css"/>
    <link rel="stylesheet" type="text/css" href="assets/lib/jqvmap/jqvmap.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/lib/datetimepicker/css/bootstrap-datetimepicker.min.css"/>
    <link rel="stylesheet" href="assets/css/style.css" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="assets/lib/jquery.gritter/css/jquery.gritter.css"/>
    <link rel="stylesheet" type="text/css" href="chosen/chosen.css">


  </head>
  <body>
    <div class="be-wrapper be-color-header be-fixed-sidebar">
      <nav class="navbar navbar-default navbar-fixed-top be-top-header">
        <div class="container-fluid">
          <div class="navbar-header">
          	<!--<a href="index.html" class="navbar-brand"></a> Logo disini -->
          </div>

          <div class="be-right-navbar">
			<ul class="nav navbar-nav navbar-right be-user-nav">
              <li class="dropdown"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="dropdown-toggle"><img src="assets/img/blank.jpg" alt="Avatar"><span class="user-name"><?php echo $_SESSION['namauser']; ?></span></a>
                <ul role="menu" class="dropdown-menu">
                  <li>
                    <div class="user-info">
                      <div class="user-name"><?php echo $_SESSION['namauser']; ?></div>
                    </div>
                  </li>
                  <li><a href="?mod=cPass"><span class="icon mdi mdi-key"></span> Ganti Password</a></li>
                  <li><a href="#" data-modal="msgKeluar" class="md-trigger"><span class="icon mdi mdi-power"></span> Keluar</a></li>
				  <li><a href="http://www.busintra.com/chat" target="_blank"><span class="icon mdi mdi-chat"></span> CHATING</a></li>
                </ul>
              </li>
            </ul>

            <div class="page-title">
            	<img src="assets/img/logo.png" hspace="0" vspace="5" style="width: 35px;"/>
            	<span>Bus Ticketing System</span>
            </div>

          </div>
        </div>
      </nav>
	  <?php
	     if($_GET['menu'] == "false"){
			  $app->setContent();
		 }
		 else{
	  ?>
      <div class="be-left-sidebar">
        <div class="left-sidebar-wrapper"><a href="#" class="left-sidebar-toggle">Dashboard</a>
          <div class="left-sidebar-spacer">
            <div class="left-sidebar-scroll">
              <div class="left-sidebar-content">
                <ul class="sidebar-elements">
                  <li <?php if($_GET['view']=="home"){ echo "class='active'"; } else{ echo ""; } ?>><a href="apps.php?view=home" style="text-transform: uppercase;"><i class="icon mdi mdi-home"></i><span>Home</span></a></li>
                  <li <?php if($_GET['mod']=="hTiket"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=hTiket" style="text-transform: uppercase;"><i class="icon mdi mdi-money-box"></i><span>Harga Tiket</span></a></li>
                  <li <?php if($_GET['mod']=="dataBus"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=dataBus" style="text-transform: uppercase;"><i class="icon mdi mdi-bus"></i><span>Data Bus</span></a></li>
                  <li <?php if($_GET['mod']=="dataJam"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=dataJam" style="text-transform: uppercase;"><i class="icon mdi mdi-time-restore"></i><span>Jam Keberangkatan</span></a></li>
				  <!--<li <?php if($_GET['mod']=="booking"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=booking" style="text-transform: uppercase;"><i class="icon mdi mdi-book-image"></i><span>Booking Tiket</span></a></li>-->
				  <?php
					 if($_SESSION['level'] == "3"){
					   //
				   }
				   else{
				  ?>
                  <li class="parent">
					 <a href="#"><i class="icon mdi mdi-assignment-check"></i><span style="text-transform: uppercase;">Laporan</span></a>
						<ul class="sub-menu">
							<li <?php if($_GET['mod']=="lap_harian1"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=lap_harian" style="text-transform: uppercase;"><i class="icon mdi mdi-calendar"></i> <span>Harian</span></a></li>
                                                        <li <?php if($_GET['mod']=="lap_bulanan"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=lap_bulanan" style="text-transform: uppercase;"><i class="icon mdi mdi-calendar-note"></i> <span>Bulanan</span></a></li>
							<li <?php if($_GET['mod']=="lap_booking"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=lap_booking" style="text-transform: uppercase;"><i class="icon mdi mdi-calendar-note"></i> <span>Booking Tiket</span></a></li>
          				</ul>
                  </li>
				  <?php
				   }
				  ?>
				  <!-- <li <?php if($_GET['mod']=="surat_sj"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=surat_sj" style="text-transform: uppercase;"><i class="glyphicon glyphicon-envelope"></i> &nbsp;&nbsp;<span>Surat Jalan</span></a></li> -->
          <!--<li <?php if($_GET['mod']=="backup_db"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=backup_db" style="text-transform: uppercase;"><i class="icon mdi mdi-cloud-upload"></i><span>Backup Database</span></a></li>-->
					<!--<li class="divider"><hr /></li> -->
				  <?php
				   if($_SESSION['level'] == "3"){
					   //
				   }
				   else{
				   ?>
						<li <?php if($_GET['mod']=="ManUser"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=ManUser&menu=false" style="text-transform: uppercase;"><i class="glyphicon glyphicon-user"></i> &nbsp;<span>Manajemen Users</span></a></li>
				   <?php
					   }
				   ?>
				  <!--<li <?php if($_GET['mod']=="chat"){ echo "class='active'"; } else{ echo ""; } ?>><a href="http://www.busintra.com/chat" target="_blank" style="text-transform: uppercase;"><i class="icon mdi mdi-comment-more"></i><span>CHATING</span></a></li> -->
                  <li <?php if($_GET['mod']=="cPass"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=cPass" style="text-transform: uppercase;"><i class="icon mdi mdi-key"></i><span>Ganti Password</span></a></li>
				  <?php
				   if($_SESSION['level'] == "3"){
					   //
				   }
				   else{
				   ?>
				  <li <?php if($_GET['mod']=="history"){ echo "class='active'"; } else{ echo ""; } ?>><a href="?mod=history&menu=false" style="text-transform: uppercase;"><i class="icon mdi mdi-time"></i><span>History</span></a></li>
				  <?php
				   }
				  ?>
                  <li><a href="#" data-modal="msgKeluar" class="md-trigger" style="color: red; text-transform: uppercase;"><i class="icon mdi mdi-power"></i><span>Keluar</span></a></li>
                  <li class="divider"></li>
                </ul>
				  <?php
					$cek_uri = "SELECT * FROM _tbl_uri_temp";
					$h_uri   = mysql_query($cek_uri);
					$r_uri   = mysql_fetch_array($h_uri);
					if($r_uri['uri'] != ""){
						$uri_get = $r_uri['uri'];
					}
					else{
						$uri_get = "?mod=welcomeApp&view=non_ac_biasa&non_ac_biasa=active&menu=false";
					}

					$cek_status = "SELECT status FROM _tbl_jadwal WHERE status='0'";
					$h_status   = mysql_query($cek_status);
					$ada_status = mysql_num_rows($h_status);
					if($ada_status > 0){
					}
					else{
						$query = "UPDATE _tbl_uri_temp SET uri='' WHERE id='1'";
						mysql_query($query);
					}

				  ?>
                  <!--<a href="<?php echo $uri_get; ?>" class="button" style="margin-top: 0px;">JUAL TIKET</a>-->
				  				<!--<a href="?mod=jual_tiket&menu=false" class="button" style="margin-top: 0px;">JUAL TIKET</a>-->
									<a href="?mod=jualTiketV2&menu=false" class="button" style="margin-top: 0px;">JUAL TIKET</a>
              </div>
            </div>
          </div>
        </div>
      </div>

	  <div class="be-content">
			<div class="main-content container-fluid">
				<?php  $app->setContent(); ?>
			</div>
	  </div>
      <?php
        }
	  ?>


    </div>

    <script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="assets/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="assets/js/main.js" type="text/javascript"></script>
    <script src="assets/lib/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="assets/lib/jquery.niftymodals/dist/jquery.niftymodals.js" type="text/javascript"></script>
    <script src="assets/js/app-dashboard.js" type="text/javascript"></script>
    <script src="assets/lib/jquery.gritter/js/jquery.gritter.js" type="text/javascript"></script>
    <script src="assets/js/app-ui-notifications.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/js/jquery.dataTables.js" type="text/javascript"></script>
    <script src="assets/lib/datatables/js/dataTables.bootstrap.js" type="text/javascript"></script>
    <script src="assets/lib/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
    <script src="chosen/chosen.jquery.js" type="text/javascript"></script>
    <script src="assets/lib/datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/datepicker.css" />
	<script type="text/javascript" src="assets/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
		$('#pil_tgl').datepicker({
				format: 'yyyy-mm-dd'
		});
		$('#tgl').datepicker({
				format: 'yyyy-mm-dd'
		});
		$('#dari_tgl').datepicker({
				format: 'yyyy-mm-dd'
		});
		$('#sm_tgl').datepicker({
				format: 'yyyy-mm-dd'
		});
		$("#out").click(function(){
			var conf_out = confirm("Yakinkah anda untuk keluar dari aplikasi ?");
			if(conf_out == true){
				window.location.href="Auth/oSign_Out.php";
			}
			else{
				return false;
			}
		});

		$("#new_out").click(function(){
			//var conf_out = confirm("Yakinkah anda untuk keluar dari aplikasi ?");
			//if(conf_out == true){
				window.location.href="Auth/oSign_Out.php";
			//}
			//else{
			//	return false;
			//}
		});

        $("#table1").dataTable();
        $("#table2AC").dataTable();
        $("#table2AC41").dataTable();
        $("#table2AC32").dataTable();
        $("#table2AC21_A").dataTable();
		$("#table2AC25_A").dataTable();
		$("#table2AC36").dataTable();
        var html = jQuery('html');
        $.fn.niftyModal('setDefaults',{
            overlaySelector: '.modal-overlay',
            closeSelector: '.modal-close',
            classAddAfterOpen: 'modal-show',
        });
        App.init();
        App.dashboard();

        $("#class_bus").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Kursi tidak ada!",
          width: "300"
        });
        $("#pil_bus").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Kursi tidak ada!",
          width: "200"
        });

		$("#pil_jam").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
          width: "200"
        });

		$("#pil_kursi").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
		  heigt: "200",
          width: "100%"
        });

		/**
        $("#txtjam").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
          width: "140"
        });
		**/

		/**
		$("#txtjam_eko41").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
          width: "160"
        });
		**/

		/**
		$("#txtjam_eko_toilet41").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
          width: "160"
        });
		**/

		/**
		$("#txtjam_ac_toilet32").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
          width: "160"
        });

		$("#txtjam_se_18").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
          width: "160"
        });
		**/

		$("#tuj_book").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Jam Keberangkatan tidak ada!",
          width: "650"
        });
		/**
		$("#txttujuanManual").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, Data tidak ada!",
          width: "500"
        });
		**/

      });


    </script>

	<div id="msgKeluar" class="modal-container colored-header colored-header-danger modal-effect-12">
		<div class="modal-content" style="border-radius: 5px;">
			<div class="modal-header" style="padding: 10px;">
			<a href="#" data-dismiss="modal" aria-hidden="true" class="close modal-close"><span class="mdi mdi-close"></span></a>
			<h3 class="modal-title">Keluar Dari Aplikasi</h3>
			</div>
			<div class="modal-body">
					<p>
						Yakinkah anda untuk keluar dari aplikasi ?
					</p>
					<hr class="style15" />
					<div class="btn-group pull-right" style="margin-bottom: 15px;">
						<button type="button" id="new_out" class="btn btn-danger hover"><i class="icon icon-left mdi mdi-power-off"></i> KELUAR</button>
						<button data-dismiss="modal" type="button" class="modal-close btn btn-default hover"><i class="icon icon-left mdi mdi-refresh"></i> BATAL</button>
				</div>
			</div>
		</div>
	</div>
	<div class="modal-overlay"></div>

  </body>
</html>
<?php
	}
?>
