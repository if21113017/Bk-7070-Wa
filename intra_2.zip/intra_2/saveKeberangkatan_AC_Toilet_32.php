<?php
	session_start();
	date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();
    $plat          = strtoupper($_POST['txtplat_AC32']);
    $supir         = $_POST['txtnmsupir_ac32'];
    $tgl_berangkat = explode("/", $_POST['txttgl_AC_32']);
    $tahun         = $tgl_berangkat[2];
    $bulan         = $tgl_berangkat[1];
    $tgl           = $tgl_berangkat[0];
    $concat_tgl    = $tahun."-".$bulan."-".$tgl;
    //$jam_berangkat = $_POST['txtjam_ac_toilet32'];    
    $jam_berangkat = $_POST['jam_update_32']; 
    $tujuan_temp   = $_POST['txttujuan_ac_toilet32'];
	$date_modif     = date("Y-m-d");
	$nomor         = explode("-", $plat);
	$time_stamp    = date("Y-m-d h:m:s");
    $tmp_jum_kursi = $_POST['tmp_jum_kursi_ac32'];
	
	//$cek_ada  = "SELECT * FROM _tbl_jadwal WHERE kd_bus='ac_toilet_22_32' AND no_plat='".strtoupper($_POST['no_plut_update_32'])."' AND jam_berangkat='".$_POST['jam_update_32']."' AND tgl_berangkat='$concat_tgl' AND id_tujuan='".$_POST['tujuan_update_32']."'";	
	$cek_ada  = "SELECT * FROM _tbl_jadwal WHERE id='".$_POST['id_update_ac_32']."'";
	$hasil    = mysql_query($cek_ada);
	$ada      = mysql_num_rows($hasil);
	$r        = mysql_fetch_array($hasil);
	
	$nomor_plat	     = str_replace(" ", "%20", $_GET['nomor']);
	$plut_num_ac_41	 = str_replace(" ", "%20", $_GET['plut_num_ac_41']);
	$plut_num_eko_41 = str_replace(" ", "%20", $_GET['plut_num_eko_41']);
	$plut_num_ac_36  = str_replace(" ", "%20", $_GET['plut_num_ac_36']);
	$plut_num_ac_32  = str_replace(" ", "%20", $nomor[0]);
	$plut_num_ac_25  = str_replace(" ", "%20", $_GET['plut_num_ac_25']);
	$plut_num_ac_23	 = str_replace(" ", "%20", $_GET['plut_num_ac_23']);
	$jam_sel		 = $_GET['jam_sel'];
	
	$id_url = $_POST['id_url'];
	$id     = $_GET['id'];
	if($id_url == ""){
		$url_id_save = $id;
	}
	else{
		$url_id_save = $id_url;
	}		
	
	$uriSave = $apps->getHost()."apps.php?mod=welcomeApp&view=ac_toilet_32&ac_toilet_32=active&menu=false&nomor=".$nomor_plat."&plut_num_ac_41=".$plut_num_ac_41."&plut_num_eko_41=".$plut_num_eko_41."&plut_num_ac_36=".$plut_num_ac_36."&plut_num_ac_32=".$plut_num_ac_32."&plut_num_ac_25=".$plut_num_ac_25."&plut_num_ac_23=".$plut_num_ac_23."&jam_sel=".$jam_sel."&id=".$id;
	
	if($ada > 0){
		$up = "UPDATE _tbl_jadwal SET no_plat='".strtoupper($nomor[0])."', nm_supir='".strtoupper($supir)."' WHERE id='$r[id]'";
		mysql_query($up);
		$up_temp = "UPDATE _tbm_tempkursi SET no_plat='".strtoupper($nomor[0])."' WHERE id_jadwal='$r[id]'";
		mysql_query($up_temp);
		mysql_query("UPDATE _tbl_uri_temp SET uri=\"".$uriSave."\" WHERE id='".$url_id_save."'");
		echo "OK";
	}
	else{
		$from_to       = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_harga_tiket WHERE id='$tujuan_temp'"));
		$pecah_from_to = explode("-", $from_to['tujuan']);
		$dari          = strtoupper($pecah_from_to[0]);
		$tujuan        = strtoupper($pecah_from_to[1]);
		$data_new = array(
					'id_tujuan'     => $from_to['id'],
					'kd_bus'        => "ac_toilet_22_32",
					'no_plat'       => strtoupper($nomor[0]),
					'nm_supir'      => strtoupper($supir),
					'jam_berangkat' => $jam_berangkat,
					'tgl_berangkat' => $concat_tgl,
					'dari'          => $dari,
					'tujuan'        => $tujuan,
					'harga_tiket'   => $from_to['harga'],
					'status'        => '0'
				);

		$sql   = $apps->insertData('_tbl_jadwal', $data_new);    
		$id_tm = mysql_insert_id();
		mysql_query("INSERT INTO _tbl_log SET logs='Input jadwal keberangkatan tujuan: $dari - $tujuan, Jam: $jam_berangkat, Nama supir: $supir, No. Plat: ".strtoupper($nomor[0]).", Kelas Bus: AC Toilet 32', time_stamp='".$time_stamp."', user='$_SESSION[namauser]'");
		for($x=1; $x<=$tmp_jum_kursi; $x++){
			$tmp_data = "INSERT INTO 
							_tbm_tempkursi 
						 SET 
							id_jadwal='$id_tm',
							no_plat='".strtoupper($nomor[0])."', 
							kursi_num='".$x."', 
							tgl_berangkat='".$concat_tgl."',
							jam_berangkat='$jam_berangkat',
							sts_kursi='0'";
		   mysql_query($tmp_data);
		}
		
		$cek  = "SELECT * FROM _tbl_booking WHERE tgl_booking='$concat_tgl' AND jam_booking='$jam_berangkat' AND tipe_bus='ac_toilet_22_32' AND sts_ongkos='Lunas'";
		$hcek = mysql_query($cek);
		$ada  = mysql_num_rows($hcek);
		if($ada > 0){
			while($rows = mysql_fetch_array($hcek)){
				$kode        = $rows['kd_booking'];	
				$saveToTiket = "INSERT INTO 
									_tbl_tiket 
								SET
									kd_bus='$rows[tipe_bus]',
									kd_jadwal='$id_tm',
									no_bangku='$rows[no_bangku]',
									nm_penumpang='$rows[nm_penumpang]',
									alamat='$rows[alamat]',
									no_hp='$rows[no_hp]',
									dari='$rows[dari]',
									tujuan='$rows[tujuan]',
									harga_tiket='$rows[harga_tiket]',
									user_modify='$_SESSION[namauser]',
									date_modify='$date_modif'";
				
				$delFromBook  = "DELETE FROM _tbl_booking WHERE kd_booking='$kode'";
				$delFromTemp  = "DELETE FROM _tbm_tempkursi_booking WHERE kd_booking='$kode'";
				$tmp_kursi    = "UPDATE _tbm_tempkursi SET sts_kursi='1' WHERE id_jadwal='$id_tm' AND kursi_num='$rows[no_bangku]'";	
				mysql_query($saveToTiket);
				mysql_query($delFromBook);
				mysql_query($delFromTemp);
				mysql_query($tmp_kursi);
				//echo $delFromBook;
			}
		}
		else{
			
		}
		
		mysql_query("UPDATE _tbl_uri_temp SET uri=\"".$uriSave."\" WHERE id='".$url_id_save."'");
		echo "OK";
	}
