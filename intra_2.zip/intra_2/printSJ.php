<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Cetak Surat Jalan</title>
        <link rel="stylesheet" href="assets/css/invTiket.css" />
        <style type="text/css">
            @import url('https://fonts.googleapis.com/css?family=Open+Sans');
            body{
                font-family: 'Roboto', Arial, sans-serif;
            }
            .box_tiket2{
                padding: 0px;
                border: 0px solid #000;
                margin: 3px;
            }
            h3{
                text-align: center;
                text-decoration: underline;
                margin-bottom: 0px;
            }
            .tabel_atas{
                margin-top: 10px;
                font-size: 10pt;
                border-bottom: 0px solid #000;
                margin-right: 0px;
                margin-bottom: -8px;
            }
            .table_atas td{
                font-size: 10pt;
            }
            .tabel_bawah{

                border-width: 0px;
                border-style: solid;
                border-color: #333;
                border-collapse: collapse;
                width:100%;
            }
            .tabel_bawah td{
                font-size: 8.5pt;
                padding: 0.2em;
                vertical-align: top;
                border-width: 1px;
                border-style: solid;
                border-color: #333;
                border-collapse: collapse;
                width:auto;
            }
            .tabel_bawah th{
                color: #000;
                font-size: 10pt;
                text-transform: uppercase;
                text-align: left;
                padding: 0.2em;
                border-width: 1px;
                border-bottom: 1px solid #000;
                border-style: solid;
                border-color: #333;
                border-collapse: collapse;
                background-color: #FFF;
            }
            .kepala_sj{
                text-align: center;
                padding: 5px;
                border-bottom: 3px double #000;
            }
            .nm_cv{
                font-weight: bold;
                font-size: 19px;
            }
            .cv_desc{
                font-weight: bold;
                font-size: 12pt;
            }
            .cv_jalan{
                font-size: 10px;
            }
            /**
            p{
                    width:1px;
                    word-wrap: break-word;
            }
            **/
            .table_komisi{
                border: 0px solid #000;
            }
            .table_komisi td{
                border: 0px solid #000;
                padding: 0.2em;
                border-collapse: collapse;
            }
        </style>
    </head>
    <body onLoad="window.print();">
        <div class="box_tiket2">
            <div class="kepala_sj">
                <div class="nm_cv">PT. INTRA</div>
                <div class="cv_desc">ANGKUTAN BUS UMUM</div>
                <div class="cv_jalan">Kantor Pusat: Jl. Sisingamangara No. 194. Telp: 24701 Fax: 430240</div>
                <div class="cv_kota">Pematang Siantar</div>
            </div>

            <?php
            error_reporting(0);
            date_default_timezone_set("Asia/Jakarta");
            require_once __DIR__ . "/Class/ConfigApp.php";

            $adm_kantor = str_replace(".", "", $_GET['admktr']);
            $adm_tiket = str_replace(".", "", $_GET['admtkt']);

            $id_tiket = $_GET['id'];
            //CEK DATABASE
            $query1 = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='" . $id_tiket . "' AND is_multi='Y'";
            $hasil1 = mysql_query($query1);
            $hasil2 = mysql_query($query1);
            $a = 0;
            while ($row2 = mysql_fetch_array($hasil2)) {
                $arr1[$a] = $row2['id'];
                $arr2[$a] = $row2['no_bangku'];
                $a++;
            }
            while ($row1 = mysql_fetch_array($hasil1)) {
                $exp = explode(",", $row1['no_bangku_multi']);
                $id1 = 0;
                $id2 = 0;
                for ($x = 0; $x < $a; $x++) {
                    if ($exp[0] == $arr2[$x]) {
                        $id1 = 1;
                    } else if ($exp[1] == $arr2[$x]) {
                        $id2 = 1;
                    }
                }
                if ($id1 == 0 or $id2 == 0) {
                    $hasil3 = mysql_query("UPDATE _tbl_tiket SET is_multi = 'T', no_bangku_multi='' WHERE id='" . $row1['id'] . "'");
                }
            }
            
            
            
            if ($_GET['no_save'] == "true") {
                $sql = "SELECT * FROM _tbl_jadwal WHERE id='$id_tiket' ORDER BY id DESC";
            } else {
                $sql = "SELECT * FROM _tbl_jadwal WHERE id='$id_tiket' AND status='0' ORDER BY no_kursi ASC";
            }
            $h = mysql_query($sql);
            $r = mysql_fetch_array($h);
            $no_plat = $r['no_plat'];
            $nm_supir = $r['nm_supir'];
            $j_berangkat = $r['jam_berangkat'];
            $berangkat = explode("-", $r['tgl_berangkat']);
            $thn = $berangkat[0];
            $bln = $berangkat[1];
            $tglnya = $berangkat[2];
            $t_berangkat = $tglnya . "/" . $bln . "/" . $thn;
            $dari = $r['dari'];
            $tujuan = $r['tujuan'];
            echo "
                <table class='tabel_atas'>
                    <tr>
                        <td style='padding-left: 10px; width: 60px;'></td>
						<td></td>
						<td rowspan='4' style='width: 200px;'>&nbsp;</td>
						<td style='padding-left: 10px; width: 90px;'>NAMA SUPIR</td>
						<td>: $nm_supir</td>
                    </tr>
                    <tr>
                        <td style='padding-left: 10px;'>B K</td>
						<td>: $no_plat</td>

						<td style='padding-left: 10px;'>TANGGAL</td>
						<td>: $t_berangkat</td>
                    </tr>

					<tr>
                        <td style='padding-left: 10px;'>TRIP</td>
						<td>: </td>

						<td style='padding-left: 10px;'>DARI</td>
						<td>: $dari</td>
                    </tr>

					<tr>
                        <td style='padding-left: 10px;'>JAM</td>
						<td>: $j_berangkat WIB</td>

						<td style='padding-left: 10px;'>KE</td>
						<td>: $tujuan</td>
                    </tr>

                </table>
				<h3>SURAT JALAN</h3>
                <table class='tabel_bawah'>
                    <thead>
                        <tr>
                            <th style='width: 70px; text-align: center;'>BANGKU</th>
                            <th style='width: 160px;'>NAMA</th>
                            <th style='width: 130px;'>DARI</th>
                            <th style='width: 190px;'>TUJUAN</th>
                            <th style='width: 18px; text-align: center;'>ORG</th>
                            <th style='width: 90px; text-align: right;'>ONGKOS</th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
            $query = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='" . $r['id'] . "' GROUP BY nm_penumpang, no_bangku_multi ORDER BY no_bangku ASC";
            $hasil = mysql_query($query);
            $no = 0;
            $jum_penumpang = mysql_fetch_array(mysql_query("SELECT COUNT(nm_penumpang) AS JUMLAH_PENUMPANG FROM _tbl_tiket WHERE kd_jadwal='" . $r['id'] . "'"));
            while ($row = mysql_fetch_array($hasil)) {
                $no++;
                if ($row['is_multi'] == "Y") {
                    $sql_last = "SELECT harga_temp, harga_multi_temp FROM _tbl_temp_ongkos WHERE kd_jadwal='" . $r['id'] . "' AND no_bangku='$row[no_bangku]'";
                    $h_sql_last = mysql_query($sql_last);
                    $r_last = mysql_fetch_array($h_sql_last);
                    $no_bangku_penumpang = $row['no_bangku_multi'];

                    $nomor = explode(',', $row['no_bangku_multi']);
                    $jum_kursi = count($nomor);
                    $jum_kursi_kur = count($nomor) - 1;
                    if ($row['ongkos_multi'] == "" || $row['ongkos_multi'] == 0) {
                        $ongkos_tiket = $jum_kursi * $row['harga_tiket']; //= $jum_kursi * $row['harga_tiket'];
                    } else {
                        $ongkos_tiket = $jum_kursi_kur * $r_last['harga_multi_temp'] + $r_last['harga_temp']; //= $jum_kursi * $row['harga_tiket'];
                    }
                    $j_p = $jum_kursi;
                } else {
                    $no_bangku_penumpang = $row['no_bangku'];
                    $ongkos_tiket = $row['harga_tiket'];
                    $j_p = "1";
                }
                
                echo "
						<tr>
                                                    <td><center>" . $no_bangku_penumpang . "</center></td>
                                                    <td class='user-avatar'>" . $row['nm_penumpang'] . "</td>
                                                    <td>$dari</td>
                                                    <td>" . $row[tujuan] . "</td>
                                                    <td style='text-align: center;'>$j_p</td>
                                                    <td style='text-align: right;'>Rp. " . number_format($ongkos_tiket, 0, ",", ".") . "</td>
						</tr>
						";
                //$total += $row['harga_tiket'];
                $total += $ongkos_tiket;
            }



            $admktr = $_GET['admktr'];
            $admtkt = $_GET['admtkt'];


            $jum = mysql_fetch_array(mysql_query("SELECT COUNT(nm_penumpang) AS JUM FROM _tbl_tiket WHERE kd_jadwal='" . $r['id'] . "'"));
            $pisah_ktr = explode(",", $admktr);
            $h_ktr = $pisah_ktr[0];

            $pisah_titik_ktr = explode(".", $h_ktr);
            $hasil_ktr = $pisah_titik_ktr[0] . $pisah_titik_ktr[1];

            $pisah_tkt = explode(",", $admtkt);
            $h_tkt = $pisah_tkt[0];

            $pisah_titik_tkt = explode(".", $h_tkt);
            $hasil_tkt = $pisah_titik_tkt[0] . $pisah_titik_tkt[1];




            echo "</tbody>
			      <tr>
                    <th colspan='4' style='text-align: right; border-left: 1px solid #000;'>Jumlah Penumpang</th>
                    <th style='width: 100px; border-right: 1px solid #000;' colspan='1'>&nbsp; &nbsp; &nbsp; &nbsp;$jum_penumpang[JUMLAH_PENUMPANG] Orang</th>
                    <th colspan='2' style='text-align: right; border-left: 1px solid #000;'>Rp. " . number_format($total, 0, ".", ".") ."</th>   
                  </tr>";
            $sqlPaket = "SELECT * FROM _tbl_paket WHERE kd_jadwal='$r[id]'";
            $resPaket = mysql_query($sqlPaket);
            $cekPaket = mysql_num_rows($resPaket);
            if ($cekPaket > 0) {
                echo "
						<tr>
						    <td colspan='6'>
								PAKET/BARANG
							</td>
						</tr>
				     ";
                $noPcs = 0;
                while ($rPaket = mysql_fetch_array($resPaket)) {
                    $noPcs++;
                    echo "<tr>
								<td colspan='4'>- $rPaket[nm_barang]</td>
								<td>1 $rPaket[satuan]</td>
								<td style='text-align: right;'>Rp. " . number_format($rPaket['biaya'], 0, ".", ".") . "</td>
						      </tr>
						      ";
                    $totalPaket += $rPaket['biaya'];
                }


                $newTotal = $total + $totalPaket;
                //$komisi   = 10 * $total/100;
                $newkomisi = 10 * $newTotal / 100;
                //$grandTotal = $komisi + $hasil_ktr + $hasil_tkt;
                $grandTotal = $newkomisi + $hasil_ktr + $hasil_tkt;
                $finalTotal = $newTotal - $grandTotal;

                echo "
							<tr>
								<td colspan='4' style='text-align: right; border-left: 1px solid #000;'><b>JUMLAH PAKET</b></td>
								<td ><b> $noPcs Item</b></td>
								<td style='text-align: right;'><b>Rp. " . number_format($totalPaket, 0, ".", ".") . "</b></td>
							</tr>
					     ";
            } else {
                $newTotal = $total + $totalPaket;
                //$komisi   = 10 * $total/100;
                $newkomisi = 10 * $newTotal / 100;
                //$grandTotal = $komisi + $hasil_ktr + $hasil_tkt;
                $grandTotal = $newkomisi + $hasil_ktr + $hasil_tkt;
                $finalTotal = $newTotal - $grandTotal;
            }
            if ($cekPaket > 0){
                echo "<tr>
                    <th colspan='4' style='text-align: right; border-left: 1px solid #000;'>Jumlah Total</th>
                    <th colspan='3' style='text-align: right; border-left: 1px solid #000;'>Rp. " . number_format($newTotal, 0, ".", ".") ."</th>
                </tr>";
            }
            echo "
                
				  <tr>
            <th colspan='4' style='width: 70%; text-align: right; border-left: 0px solid #000;'>&nbsp;</th>
            <th style='width: 30%; border-right: 0px solid red;' colspan='5'>
  						<table class='table_komisi'>
  							<tr>
  								<td style='width: 20px;'>KOMISI</td><td style='text-align: right;'>: Rp. " . number_format($newkomisi, 0, ".", ".") . "</td>
  							</tr>
  							<tr>
  								<td>AD/KTR</td><td style='text-align: right;'>: Rp. $h_ktr</td>
  							</tr>
  							<tr>
  								<td>TIKET</td><td style='text-align: right;'>: Rp. $h_tkt</td>
  							</tr>
  							<tr>
  								<td>JUMLAH</td><td style='text-align: right;'>: <span style='text-align: right;'>Rp. " . number_format($grandTotal, 0, ".", ".") . "</span></td>
  							</tr>
  						</table>
					   </th>
          </tr>
				  <tr>
                    <th colspan='4' style='text-align: right; border-left: 0px solid #000;'>Jumlah Bersih</th>
                    <th style='width: 100px; border-right: 0px solid #000; text-align: right;' colspan='4'>Rp. " . number_format($finalTotal, 0, ",", ".") . "</th>
                  </tr>
                </table>
                <table class='table_komisi' style='width: 100%; text-align: center; margin-top: 40px;'>
					<tr>
						<td style='width: 32%; font-size: 12pt;'>
						 Yang menerima,
						 <br />
						 <br />
						 <br />
						 (________________________)
						</td>
						<td style='width: 32%; font-size: 12pt;'>
						 Yang menyerahkan,
						 <br />
						 <br />
						 <br />
						 (________________________)
						</td>
						<td style='width: 32%; font-size: 12pt;'>
						 Disetujui,
						 <br />
						 <br />
						 <br />
						 (________________________)
						</td>
					</tr>
				</table>
				<p style='font-family: Lucida Calligraphy; text-align: center; font-size: 12pt;'>
					\"Utamakan Keselamatan\"
				</p>
             ";
            if ($_GET['no_save'] == "true") {
                mysql_query("INSERT INTO _tbl_hissj SET kd_jadwal='$r[id]', tgl='$r[tgl_berangkat]', user='$_SESSION[user_id]', adm_kantor='" . $adm_kantor . "', adm_tiket='" . $adm_tiket . "'");
                mysql_query("UPDATE _tbl_jadwal SET status='0', isCetakSJ='1' WHERE id='$id_tiket'");
            } else {
                
            }
            ?>
        </div>
    </body>
</html>
