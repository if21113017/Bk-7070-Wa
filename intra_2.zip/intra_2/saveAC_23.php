<?php
    session_start();
    error_reporting(0);
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();

    $id_jadwal      = $_POST['txt_idhide'];
    $no_bangku      = $_POST['txtNoKursi'];
    $nm_penumpang   = strtoupper($_POST['txtNamaPenumpang']);
    $alamat         = strtoupper($_POST['txtAlamat']);
    $no_hp          = $_POST['txtNoHp'];
    $harga_tiket    = $_POST['txtOngkos'];
    $date_modif     = date("Y-m-d");

	$txttujuanManual = $_POST['txttujuanManual_AC_23'];

	$pisah_temp      = explode(" - ", $txttujuanManual);
	$tujuan_temp     = $pisah_temp[1];
	$dari_temp       = $pisah_temp[0];

	$pisah_tujuan    = explode("#", $tujuan_temp);
	$tujuan_manual   = $pisah_tujuan[0];
	$time_stamp      = date("Y-m-d h:m:s");
	if($txttujuanManual == "0"){
		$PTujuan = $_POST['txt_tujuanhide'];
		$dari_p   = $_POST['txt_darinhide'];
	}
	else{
		$PTujuan = $tujuan_manual;
		$dari_p   = $dari_temp;
	}

    $data = array(
        'kd_jadwal'     => $id_jadwal,
        'no_bangku'     => $no_bangku,
        'nm_penumpang'  => $nm_penumpang,
        'alamat'        => $alamat,
        'no_hp'         => $no_hp,
		'dari'			=> $dari_p,
		'tujuan'		=> $PTujuan,
        'harga_tiket'   => $harga_tiket,
        'user_modify'   => '',
        'date_modify'   => $date_modif
    );


    $apps->insertData('_tbl_tiket', $data);
    $response = json_encode($data);

	$nomor_plat	     = str_replace(" ", "%20", $_GET['nomor']);
	$plut_num_ac_41	 = str_replace(" ", "%20", $_GET['plut_num_ac_41']);
	$plut_num_eko_41 = str_replace(" ", "%20", $_GET['plut_num_eko_41']);
	$plut_num_ac_36  = str_replace(" ", "%20", $_GET['plut_num_ac_36']);
	$plut_num_ac_32  = str_replace(" ", "%20", $_GET['plut_num_ac_32']);
	$plut_num_ac_25  = str_replace(" ", "%20", $_GET['plut_num_ac_25']);
	$plut_num_ac_23	 = str_replace(" ", "%20", $_GET['plut_num_ac_23']);

	$uriSave = $apps->getHost()."apps.php?mod=welcomeApp&view=ac_toilet_23&ac_toilet_23=active&menu=false&nomor=".$nomor_plat."&plut_num_ac_41=".$plut_num_ac_41."&plut_num_eko_41=".$plut_num_eko_41."&plut_num_ac_36=".$plut_num_ac_36."&plut_num_ac_32=".$plut_num_ac_32."&plut_num_ac_25=".$plut_num_ac_25."&plut_num_ac_23=".$plut_num_ac_23;

	mysql_query("INSERT INTO _tbl_log SET logs='Jual Tiket Tujuan: $dari_p - $PTujuan, Nama Penumpang: $nm_penumpang, Nomor Kursi: $no_bangku', time_stamp='".$time_stamp."', user='$_SESSION[namauser]'");
	$tmp_kursi = "UPDATE _tbm_tempkursi SET sts_kursi='1' WHERE id_jadwal='$id_jadwal' AND kursi_num='$no_bangku'";
    mysql_query($tmp_kursi);
	mysql_query("UPDATE _tbl_uri_temp SET uri=\"".$uriSave."\" WHERE id='1'");
    echo $response;
