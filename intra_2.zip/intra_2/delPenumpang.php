<?php
    error_reporting(0);
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();

    $id_tiket  = $_GET['id_tiket'];
	$no_bangku = $_GET['kursi'];
	$id_jadwal = $_GET['jadwal_code'];
	$view      = $_GET['view'];

	$jam_sel = $_GET['jam_sel'];
	$id      = $_GET['id'];

    $sql = "DELETE FROM _tbl_tiket WHERE id='$id_tiket'";
    $h   = mysql_query($sql);

	$tmp_kursi = "UPDATE _tbm_tempkursi SET sts_kursi='0' WHERE id_jadwal='$id_jadwal' AND kursi_num='$no_bangku'";
    mysql_query($tmp_kursi);

	?>
	<script type="text/javascript">
        //alert("Data penumpang dihapus");
            window.location.href="apps.php?mod=<?php echo $_GET['mod']; ?>&id=<?php echo $id_jadwal; ?>&menu=false"
    </script>
	<?php
	/**
    if($h == true){
    ?>
        <script type="text/javascript">
            alert("Data penumpang dihapus");
            window.location.href="apps.php"
        </script>
    <?php
    }
    else{
    ?>
        <script type="text/javascript">
            alert("Data penumpang gagal dihapus");
            window.location.href="apps.php"
        </script>
    <?php
    }**/
