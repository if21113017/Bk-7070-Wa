<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	
	$del = "DELETE FROM _tbl_paket  WHERE id='$_GET[idPaket]'";
	mysql_query($del);
?>
<script type="text/javascript">
	window.history.back();
</script>