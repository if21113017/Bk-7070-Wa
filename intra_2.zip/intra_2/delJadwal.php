<?php
    error_reporting(0);
	require_once "Class/ConfigApp.php";
    $apps = new ConfigApp();
    
    $id = $_GET['id'];

    $sql = "DELETE FROM _tbl_jadwal WHERE id='$id'";
    $tmp = "DELETE FROM _tbm_tempkursi WHERE id_jadwal='$id'";
    $tkt = "DELETE FROM _tbl_tiket WHERE kd_jadwal='$id'";

    mysql_query($sql);
    mysql_query($tmp);
    mysql_query($tkt);

    header("location:apps.php?mod=jualTiketV2&menu=false#");
?>