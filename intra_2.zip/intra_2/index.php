<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	$apps->redirectPage("index"); //Welcome Page
        
?>