var App = (function () {
  'use strict';

  App.formElements = function( ){    
    $(".select2").select2({
      width: '100%'
    });
    
    $(".tags").select2({
      width: '100%'
    });

    $("#txtplat").select2({
      width: '100%'
    });

    $("#txttujuan").select2({});

  };

  return App;
})(App || {});
