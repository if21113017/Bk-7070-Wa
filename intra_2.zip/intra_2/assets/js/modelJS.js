/**
function Ajax_Resync() {
	var
		$http,
		$self = arguments.callee;

		if (window.XMLHttpRequest) {
			$http = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				$http = new ActiveXObject('Msxml2.XMLHTTP');
			} catch(e) {
				$http = new ActiveXObject('Microsoft.XMLHTTP');
			}
		}

		if ($http) {
			$http.onreadystatechange = function(){
				if (/4|^complete$/.test($http.readyState)) {
					document.getElementById('baru_masuk').innerHTML = $http.responseText;
					var dataMasuk = $http.responseText;
					console.log(dataMasuk);
					//setTimeout(function(){$self();}, 800);
				}
		};
		$http.open('GET', 'count_new.php' + '?' + new Date().getTime(), true);
		$http.send(null);		
		}
}
**/