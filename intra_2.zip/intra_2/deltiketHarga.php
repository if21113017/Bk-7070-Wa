<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();

    $id = $_GET['id'];

    $sql = "DELETE FROM _tbl_harga_tiket WHERE id='$id'";
    $h   = mysql_query($sql);

    if($h == true){
    ?>
        <script type="text/javascript">
            alert("Data berhasil dihapus");
            window.location.href="apps.php?mod=hTiket"
        </script>
    <?php
    }
    else{
    ?>
        <script type="text/javascript">
            alert("Data gagal dihapus");
            window.location.href="apps.php?mod=hTiket"
        </script>
    <?php
    }