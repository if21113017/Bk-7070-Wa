<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan Harian</title>
    <link rel="stylesheet" href="assets/css/invTiket.css" />
    <style type="text/css">
        body{
            font-family: 'Roboto', Arial, sans-serif;
           
        }
        .box_tiket2{
            padding: 0px;
            border: 2px solid #000;   
        }
        h3{
            text-align: center;
            text-decoration: underline;
        }
        .tabel_atas{            
            font-size: 14px;            
            border-bottom: 0px solid #000;            
            margin-right: 0px;
            margin-bottom: 5px;
        }
        .table_atas td{
            font-size: 14px;
        }
        .tabel_bawah{ 
            font-size: 8pt;
            border-width: 0px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;            
            width:100%;
        }
        .tabel_bawah td{ 
            padding: 0.5em;
            vertical-align: top;
            border-width: 1px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            width:auto;
        }
         .tabel_bawah th{ 
            color: #000;
            font-size: 12px;
            text-transform: uppercase;
            text-align: left;
            padding: 0.5em;
            border-width: 1px;
            border-bottom: 2px solid #000;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            background-color: #FFF;
        }
        
    </style>
</head>
<body onLoad="window.print();">
    <div class="box_tiket2">
        <h3>LAPORAN HARIAN</h3>
    <?php
        error_reporting(0);
        date_default_timezone_set("Asia/Bangkok");
        require_once __DIR__."/Class/ConfigApp.php";
        require_once "Class/fungsi_indotgl.php";
        $id_tiket = $_GET['id'];
        $sql = "SELECT * FROM _tbl_jadwal WHERE id='$id_tiket' ORDER BY id DESC";
		$h   = mysql_query($sql);
        $r   = mysql_fetch_array($h);

        $no_plat	 = $r['no_plat'];
		
        echo "
                <table class='tabel_atas'>
                    <tr>
                        <td style='padding-left: 10px; width: 90px;'>Nomor Plat</td><td>: $no_plat</td>
                    </tr>                   
                    <tr>
                        <td style='padding-left: 10px;'>Tanggal</td><td>: ".tgl_indo($_GET['tgl'])."</td>
                    </tr>                    
                </table>

                <table class='tabel_bawah'>
                    <thead>
                        <tr>
                            <th style='width: 80px; text-align: center;'>No. Bangku</th>
                            <th style='width: 200px;'>Nama Penumpang</th>
                            <th style='width: 200px;'>Alamat</th>
                            <th style='width: 100px;'>No. HP</th>
                            <th style='width: 150px;'>Jumlah Uang (Rp)</th>
							<th style='width: 300px;'>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
                $query = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='".$r['id']."' AND date_modify='".$_GET['tgl']."' ORDER BY no_bangku ASC";                
				$hasil = mysql_query($query);												
				while($row = mysql_fetch_array($hasil)){
                    echo "
						<tr>
						    <td><center>".$row[no_bangku]."</center></td>
							<td class='user-avatar'>".$row[nm_penumpang]."</td>
							<td>".$row[alamat]."</td>
							<td>".$row[no_hp]."</td>
                            <td>".number_format($row[harga_tiket], 0, ".", ".")."</td>
							<td><i>$row[remark]</i></td>
						</tr>
						";
                        $sub_total += $row[harga_tiket];
                }
                
            echo "</tbody>
                </table>
                <table class='tabel_bawah'>
                    <tr>						
                        <th colspan='4' style='width: 580px; text-align: right;'>Sub Total</th>
                        <th colspan='2' style='width: 425px; text-align: left; border-left: 0px solid #000'>Rp. ".number_format($sub_total, 0, ".", ".")."</th>						
                    </tr>
                </table>
             ";
        //mysql_query("INSERT INTO _tbl_hissj SET kd_jadwal='$r[id]', tgl='$t_berangkat', user='$_SESSION[user_id]'");
        //mysql_query("UPDATE _tbl_jadwal SET status='1' WHERE id='$id_tiket'");
?>
</div>
</body>
</html>