<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan Keuangan ALL</title>
    <link rel="stylesheet" href="assets/css/invTiket.css" />
    <style type="text/css">
		/*
		@page { 
			size: F4 Portrait;			
			margin: 2mm 2mm 2mm 2mm;  
		} */
        body{
            font-family: 'Roboto', Arial, sans-serif;
           
        }
        .box_tiket2{
            padding: 0px;
            border: 0px solid #000;   
			margin-top: -5px;
        }
        h3{
            text-align: center;
            text-decoration: underline;
        }
        .tabel_atas{            
            font-size: 14px;            
            border-bottom: 0px solid #000;            
            margin-right: 0px;
            margin-bottom: 5px;
        }
        .table_atas td{
            font-size: 14px;
        }
        .tabel_bawah{ 
            font-size: 8pt;
            border-width: 0px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;            
            width:100%;
        }
        .tabel_bawah td{ 
            padding: 0.5em;
            vertical-align: top;
            border-width: 1px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            width:auto;
        }
         .tabel_bawah th{ 
            color: #000;
            font-size: 11px;
            text-transform: uppercase;
            text-align: left;
            padding: 0.5em;
            border-width: 1px;
            border-bottom: 2px solid #000;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            background-color: #FFF;
        }
        
    </style>
</head>
<body onLoad="window.print();">
    <div class="box_tiket2">
        <h3 style="margin-bottom: 0px;">LAPORAN KEUANGAN</h3>
    <?php
        error_reporting(0);
        date_default_timezone_set("Asia/Bangkok");
        require_once __DIR__."/Class/ConfigApp.php";
        require_once "Class/fungsi_indotgl.php";
		
		$dari  = $_GET['tgl_awal'];
		$sd    = $_GET['tgl_akhir'];
		
        		
        echo "
                <table class='tabel_atas'>                    
                    <tr>
                        <td style='padding-left: 10px; width: 20px;'>Tanggal</td><td>: ".tgl_indo($dari)." s/d ".tgl_indo($sd)."</td>
                    </tr>                    
                </table>
				<table>
					<tr>
						<td style='vertical-align: top;'>
							<table class='tabel_bawah'>
                                        <thead>
                                            <tr style='border-top: 2px solid #000; font-size: 11px'>
                                                <th style='width: 6px;'>T.Duduk</th>
                                                <th>Nama</th>                                                
												<th>Tujuan</th>
												<th>Tgl Berangkat</th>
												<th style='width: 150px;'>Tipe Bus</th>
                                                <th style='width: 80px;'>Ongkos</th>												
                                            </tr>
                                        </thead>
                                        <tbody>";
											$sql_tiket   = "SELECT * FROM _tbl_tiket WHERE date_modify BETWEEN '".$dari."' AND '".$sd."' ORDER BY date_modify, no_bangku ASC";
											$h_tiket     = mysql_query($sql_tiket);
											$ada_tiket   = mysql_num_rows($h_tiket);
											if($ada_tiket > 0){
												$no = 0;
												while($t = mysql_fetch_array($h_tiket)){
													$no++;
													$get_jadwal = mysql_fetch_array(mysql_query("SELECT kd_bus, tgl_berangkat, jam_berangkat FROM _tbl_jadwal WHERE id='$t[kd_jadwal]'"));
													$tgl_mov = explode("-",$get_jadwal['tgl_berangkat']);
													$tgl_tkt = $tgl_mov[2];
													$bln_tkt = $tgl_mov[1];
													$thn_tkt = $tgl_mov[0];
													$gb_tkt  = $tgl_tkt."-".$bln_tkt."-".$thn_tkt;
													$get_tipe  = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$get_jadwal[kd_bus]'"));													
													echo "
														<tr style='font-size: 10px;'>
															<td style='text-align: center;'><b>$t[no_bangku]</b></td>
															<td>$t[nm_penumpang]</td>
															<td>$t[dari]<br />$t[tujuan]</td>
															<td>$gb_tkt<br />$get_jadwal[jam_berangkat] WIB</td>
															<td>$get_tipe[nm_class]</td>
															<td>Rp. ".number_format($t['harga_tiket'], 0, ".", ".")."</td>
														</tr>
												     ";
													$grand_tiket += $t['harga_tiket'];
												}
											}
											else{
												echo "
													<tr>
														<td colspan='5'>
															<i style='color: red; text-style: italic;'>Tidak ada data</i>
														</td>
													</tr>
											     ";
											}
										echo "
										</tbody>
										<tr>
											<th colspan='6' style='text-align:right'>Jumlah Penumpang: $no Orang</th>											
										</tr>
										<tr>
											<th colspan='6' style='text-align:right'>Grand Total: Rp. ".number_format($grand_tiket, 0, ".", ".")."</th>											
										</tr>
									</table>
						</td>
						<td style='vertical-align: top;'>
							<table class='tabel_bawah'>
                                        <thead>
                                            <tr style='border-top: 2px solid #000; font-size: 11px'>
                                                <th style='width: 10%;'>T.Duduk</th>
                                                <th>Nama</th>                                                
												<th>Tujuan</th>
												<th>Tgl Berangkat</th>
												<th>Tipe Bus</th>";
												/**
												echo "
												<th style='width: 13%; text-align: right;'>Ongkos</th>";**/
												echo "
												<th style='width: 15%; text-align: right;'>Panjar</th>
												<th style='width: 13%; text-align: right;'>Sisa</th>
                                            </tr>
                                        </thead>
                                        <tbody>";
										$sql_booking = "SELECT * FROM _tbl_booking WHERE tgl_booking BETWEEN '".$dari."' AND '".$sd."'";											
										$h_booking   = mysql_query($sql_booking);
										$ada_booking = mysql_num_rows($h_booking);
										if($ada_booking > 0){
											$num = 0;
											while($b = mysql_fetch_array($h_booking)){
												$get_class  = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$b[tipe_bus]'"));
												$num++;
												$tgl_mov1 = explode("-",$b['tgl_booking']);
												$tgl_tkt1 = $tgl_mov1[2];
												$bln_tkt1 = $tgl_mov1[1];
												$thn_tkt1 = $tgl_mov1[0];
												$gb_tkt1  = $tgl_tkt1."-".$bln_tkt1."-".$thn_tkt1;
												echo "
														<tr style='font-size: 10px;'>
															<th style='text-align: center;'>$b[no_bangku]</th>
															<td>$b[nm_penumpang]</td>
															<td>$b[dari]<br />$b[tujuan]</td>
															<td>$gb_tkt1<br />$b[jam_booking] WIB</td>
															<td>$get_class[nm_class]</td>";
															/**
															echo "
															<td>Rp. ".number_format($b[harga_tiket], 0, ".", ".")."</td>";
															**/
															echo "
															<td style='text-align: right'>Rp. ".number_format($b[panjar], 0, ".", ".")."</td>
															<td style='text-align: right'>Rp. ".number_format($b[sisa], 0, ".", ".")."</td>
														</tr>
													 ";
												$tot_panjar += $b['panjar'];
												$tot_sisa   += $b['sisa'];
											}
										}
										else{
											echo "
													<tr>
														<td colspan='7'>
															<i style='color: red; text-style: italic;'>Tidak ada data</i>
														</td>
													</tr>
											     ";
										}
										echo "
										</tbody>
										<tr>
											<th colspan='5' style='text-align:right'>Grand Total:</th>											
											<th>Rp. ".number_format($tot_panjar, 0, ".", ".")."</th>
											<th>Rp. ".number_format($tot_sisa, 0, ".", ".")."</th>
										</tr>
										<tr>
											<th colspan='7' style='text-align:right'>Jumlah Penumpang: $num Orang</th>											
										</tr>
										
									</table>
						</td>
					</tr>
				</table>";
                
        //mysql_query("INSERT INTO _tbl_hissj SET kd_jadwal='$r[id]', tgl='$t_berangkat', user='$_SESSION[user_id]'");
        //mysql_query("UPDATE _tbl_jadwal SET status='1' WHERE id='$id_tiket'");
?>
</div>
</body>
</html>