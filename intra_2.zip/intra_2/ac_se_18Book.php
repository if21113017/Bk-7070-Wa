<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
?>
<div class="row">
						  <div class="col-md-3">
							  <div class="card ">
								<div class="card-content">
										<?php
												/**										 
												* Cek apakah ada jadwal sekarang
												**/
												$tgl_nowSE_18 = date("Y-m-d");
												$plut_se_18  = $_GET['plut_num_se_18'];
												$sqlSE_18 = "SELECT * FROM _tbl_jadwal WHERE tgl_berangkat='".$tgl_nowSE_18."' AND status='0' AND kd_bus='AC' AND no_plat='".$plut_se_18."' ORDER BY id DESC";
												$hASE_18   = mysql_query($sqlSE_18);												
												$adaSE_18 = mysql_num_rows($hASE_18);
												if($adaSE_18 > 0){
														$rSE_18   = mysql_fetch_array($hASE_18);
														?>
															<script type="text/javascript">
																	$(document).ready(function(){																		
																				$("#tbl_Simpan_SE_18").attr("disabled", true);
																				$("#frmAC_SE_18 :input").attr("disabled", true);
																				$("#cetakSJ_SE_18").attr("disabled", false);
																				$("#tiketMulti_se_18").attr("disabled", false);

																				$("#cetakSJ_SE_18").click(function(){																							
																					window.open('<?php echo $apps->setHost(printSJ.php); ?>?id='+<?php echo $rSE_18['id']; ?>,'CetakSuratJalan', 'width=1080, height=800');
																					window.location.reload();																			
																				});
																	})
															</script>
														<?php
														
														$no_plat_SE_18 	 = $rSE_18['no_plat'];
														$nm_supir_SE_18 	= $rSE_18['nm_supir'];
														$j_berangkat_SE_18  = $rSE_18['jam_berangkat'];
														$berangkat_SE_18   = explode("-", $rSE_18['tgl_berangkat']);
														$thn_SE_18         = $berangkat_SE_18[0];
														$bln_SE_18          = $berangkat_SE_18[1];
														$tglnya_SE_18      = $berangkat_SE_18[2];
														$t_berangkat_SE_18 = $tglnya_SE_18."/".$bln_SE_18."/".$thn_SE_18;
														$dari_SE_18        = $rSE_18['dari'];
														$tujuan_SE_18      = $rSE_18['tujuan'];
														
														$bisa_isi_tiket_se_18 = "md-trigger";
												}
												else{
														?>
															<script type="text/javascript">
																	$(document).ready(function(){
																		$("#cetakSJ_SE_18").attr("disabled", true);
																		$("#tbl_Simpan_SE_18").attr("disabled", false);																		

																		$("#tiketMulti_se_18").attr("disabled", true);
																		
																		$(".belum_ada_jadwal_se_18").click(function(){
																			alert("Belum ada jadwal!\nSilahkan isi Nomor Plat dan Nama Supir Bus terlebih dahulu");
																		});
																	})
															</script>
														<?php
														$no_plat_SE_18 		 = "";
														$nm_supir_SE_18 	 = "";
														$j_berangkat_SE_18 = $jam_sekarang;
														$t_berangkat_SE_18 = $tgl_sekarang;
														$dari_SE_18        = "";
														$tujuan_SE_18      = "";
														
														$bisa_isi_tiket_se_18 = "belum_ada_jadwal_se_18";
												}
												
												
										?>
									  <table id="tg-VbtHW" style="width: 190px;">
										  <tr>
											<th colspan="2"><center></center></th>
											<th rowspan="7"></th>
											<th colspan="2">
												<center>
													<img src="assets/img/supir.png" style="width: 30px; padding-bottom: 7px;" />
												</center>
											</th>
										  </tr>										  
										  <tr>
											<th colspan="2" style="text-align: center;">KERNET</th>
											<th  colspan="2" style="text-align: center;">SUPIR</th>
										  </tr>		  
										  <tr>
											<td colspan="2">
												<center>
												<?php
													$no_bangku_1 = $apps->cekKursi_SE18("1");													
													if($no_bangku_1 == "ADA"){
												?>
													<div data-modal="md-stickyUp_SE_18" class="kursi_berisi">1</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">1</div>
												<?php
													}
												?>													
												</center>
												<form name="frmKursi1_SE_18" id="frmKursi1_SE_18" method="post" action="#">
													<div id="md-stickyUp_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="1">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>											
											<td>
												<center>
												<?php
													$no_bangku_2 = $apps->cekKursi_SE18("2");													
													if($no_bangku_2 == "ADA"){
												?>
													<div data-modal="md-stickyUp2_SE_18" class="kursi_berisi">2</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp2_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">2</div>
												<?php
													}
												?>
													
												</center>
												<form name="frmKursi2_SE_18" id="frmKursi2_SE_18" method="post" action="#">
													<div id="md-stickyUp2_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="2">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" type="number" value="<?php echo $rSE_18['harga_tiket']; ?>" class="form-control input-sm" readonly required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
											<center>
												<?php
													$no_bangku_3 = $apps->cekKursi_SE18("3");													
													if($no_bangku_3 == "ADA"){
												?>
													<div data-modal="md-stickyUp3_SE_18" class="kursi_berisi">3</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp3_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">3</div>
												<?php
													}
												?>
											</center>
											<form name="frmKursi3_SE_18" id="frmKursi3_SE_18" method="post" action="#">
													<div id="md-stickyUp3_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="3">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input readonly name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>											
										  </tr>
										  
										  <tr>
											<td colspan="2">
											<center>
												<?php
													$no_bangku_4 = $apps->cekKursi_SE18("4");													
													if($no_bangku_4 == "ADA"){
												?>
													<div data-modal="md-stickyUp4a_SE_18" class="kursi_berisi">4</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp4a_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">4</div>
												<?php		
													}
												?>
												
											</center>
											<form name="frmKursi4a_SE_18" id="frmKursi4a_SE_18" method="post" action="#">
													<div id="md-stickyUp4a_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly value="4">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											
											<td>
											<center>
													<?php
														$no_bangku_5 = $apps->cekKursi_SE18("5");
														if($no_bangku_5 == "ADA"){
													?>
														<div data-modal="md-stickyUp5_SE_18" class="kursi_berisi">5</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp5_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">5</div>
													<?php
														}
													?>
												
											</center>
											<form name="frmKursi5_SE_18" id="frmKursi5_SE_18" method="post" action="#">
													<div id="md-stickyUp5_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="5">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_6 = $apps->cekKursi_SE18("6");
														if($no_bangku_6 == "ADA"){
													?>
														<div data-modal="md-stickyUp6_SE_18" class="kursi_berisi">6</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp6_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">6</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi6_SE_18" id="frmKursi6_SE_18" method="post" action="#">
													<div id="md-stickyUp6_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="6">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											
										  </tr>

										  <tr>
											<td colspan="2">
												<center>
													<?php
														$no_bangku_7 = $apps->cekKursi_SE18("7");
														if($no_bangku_7 == "ADA"){
													?>
														<div data-modal="md-stickyUp7_SE_18" class="kursi_berisi">7</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp7_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">7</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi7_SE_18" id="frmKursi7_SE_18" method="post" action="#">
													<div id="md-stickyUp7_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="7">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>											
											<td>
												<center>
													<?php
														$no_bangku_8 = $apps->cekKursi_SE18("8");
														if($no_bangku_8 == "ADA"){
													?>
														<div data-modal="md-stickyUp8_SE_18" class="kursi_berisi">8</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp8_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">8</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi8_SE_18" id="frmKursi8_SE_18" method="post" action="#">
													<div id="md-stickyUp8_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="8">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_9 = $apps->cekKursi_SE18("9");
														if($no_bangku_9 == "ADA"){
													?>
														<div data-modal="md-stickyUp9_SE_18" class="kursi_berisi">9</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp9_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">9</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi9_SE_18" id="frmKursi9_SE_18" method="post" action="#">
													<div id="md-stickyUp9_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="9">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>											
										  </tr>

										  <tr>
											<td colspan="2">
												<center>
													<?php
														$no_bangku_10 = $apps->cekKursi_SE18("10");
														if($no_bangku_10 == "ADA"){
													?>
														<div data-modal="md-stickyUp10_SE_18" class="kursi_berisi">10</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp10_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">10</div>
													<?php
														}
													?>

													
												</center>
											<form name="frmKursi10_SE_18" id="frmKursi10_SE_18" method="post" action="#">
													<div id="md-stickyUp10_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="10">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											
											<td>
												<center>
													<?php
														$no_bangku_11 = $apps->cekKursi_SE18("11");
														if($no_bangku_11 == "ADA"){
													?>
														<div data-modal="md-stickyUp11_SE_18" class="kursi_berisi">11</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp11_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">11</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi11_SE_18" id="frmKursi11_SE_18" method="post" action="#">
													<div id="md-stickyUp11_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="11">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_12 = $apps->cekKursi_SE18("12");
														if($no_bangku_12 == "ADA"){
													?>
														<div data-modal="md-stickyUp12_SE_18" class="kursi_berisi">12</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp12_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">12</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi12_SE_18" id="frmKursi12_SE_18" method="post" action="#">
													<div id="md-stickyUp12_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="12">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											
										  </tr>

										  <tr>
											<td colspan="2">&nbsp;</td>
											
											<td>
												<center>
													<?php
														$no_bangku_13 = $apps->cekKursi_SE18("13");
														if($no_bangku_13 == "ADA"){
													?>
														<div data-modal="md-stickyUp13_SE_18" class="kursi_berisi">13</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp13_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">13</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi13_SE_18" id="frmKursi13_SE_18" method="post" action="#">
													<div id="md-stickyUp13_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="13">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_14 = $apps->cekKursi_SE18("14");
														if($no_bangku_14 == "ADA"){
													?>
														<div data-modal="md-stickyUp14_SE_18" class="kursi_berisi">14</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp14_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">14</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi14_SE_18" id="frmKursi14_SE_18" method="post" action="#">
													<div id="md-stickyUp14_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="14">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>											
										  </tr>
										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_15 = $apps->cekKursi_SE18("15");
														if($no_bangku_15 == "ADA"){
													?>
														<div data-modal="md-stickyUp15_SE_18" class="kursi_berisi">15</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp15_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">15</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi15_SE_18" id="frmKursi15_SE_18" method="post" action="#">
													<div id="md-stickyUp15_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="15">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>

											<td>
												<center>
													<?php
														$no_bangku_16 = $apps->cekKursi_SE18("16");
														if($no_bangku_16 == "ADA"){
													?>
														<div data-modal="md-stickyUp16_SE_18" class="kursi_berisi">16</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp16_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">16</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi16_SE_18" id="frmKursi16_SE_18" method="post" action="#">
													<div id="md-stickyUp16_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="16">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td style="width: 15px;">&nbsp;</td>
											<td>
												<center>
													<?php
														$no_bangku_17 = $apps->cekKursi_SE18("17");
														if($no_bangku_17 == "ADA"){
													?>
														<div data-modal="md-stickyUp17_SE_18" class="kursi_berisi">17</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp17_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">17</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi17_SE_18" id="frmKursi17_SE_18" method="post" action="#">
													<div id="md-stickyUp17_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="17">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_18 = $apps->cekKursi_SE18("18");													
														if($no_bangku_18 == "ADA"){
													?>
														<div data-modal="md-stickyUp18_SE_18" class="kursi_berisi">18</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp18_SE_18" class="kursi_kosongbook <?php echo $bisa_isi_tiket_se_18; ?>">18</div>
													<?php
														}
													?>
													
												</center>
											<form name="frmKursi18_SE_18" id="frmKursi18_SE_18" method="post" action="#">
													<div id="md-stickyUp18_SE_18" class="modal-container modal-effect-7">
														<div class="modal-content">
															
															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="18">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $rSE_18['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $rSE_18['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $rSE_18['id']; ?>" />
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm"></textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;">
																		</td>				
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" readonly class="form-control input-sm" required>
																		</td>				
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">        	
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											
										  </tr>
										  <tr>
											<td colspan="5" style="text-align: center;"><div class="box_belakang">&nbsp;</div></td>
										  </tr>
									</table>
								</div>
							  </div>
						 </div>
						 <div class="col-md-9">
							  <div class="card ">
								<div class="card-content">								
									<form action="#" method="POST" name="frmAC_SE_18" id="frmAC_SE_18">	
										<table style="width: 100%; border-bottom: 2px solid #CCC; margin-bottom: 6px;">
											<tr>
													<td style="width: 50%;">
														<table>
															<tr>
																<td style="width: 21%;">Nomor Plat</td>
																<td style="width: 25%;">
																	<select style="width: 160px; text-transform: uppercase;" name="txtplat_SE_18" id="txtplat_SE_18">
																		<option value=''>- Pilih Bus -</option>
																		<?php
																			$bus18 = "SELECT no_plat, nm_bus, nm_supir FROM _tbl_bus WHERE jum_kursi='18' ORDER BY no_plat ASC";
																			$hb18  = mysql_query($bus18);
																			while($rb18 = mysql_fetch_array($hb18)){
																				if($rb18['no_plat'] == $no_plat_SE_18){
																					echo "
																						<option value='$rb18[no_plat]-$rb18[nm_supir]' selected>$rb18[no_plat]</option>
																					";
																				}
																				else{
																					echo "
																						<option value='$rb18[no_plat]-$rb18[nm_supir]'>$rb18[no_plat]</option>
																					";
																				}
																				
																			}
																		?>
																	</select>																	
																</td>
															</tr>
															<tr>
																<td>Nama Supir</td>
																<td>
																	<input type="text" class="form-control input-xs" style="width: 240px" required name="txtnmsupir_SE_18" id="txtnmsupir_SE_18" value="<?php echo $nm_supir_SE_18; ?>" readonly />
																	<input type="hidden" class="form-control input-xs" name="tmp_jum_kursi_se_18" value="18" />		
																	<input type="hidden" class="form-control input-xs" style="width: 240px" required name="txtnomor_se_18" id="txtnomor_se_18" readonly />
																</td>
															</tr>
															<tr>
																<td>Tgl Berangkat</td>
																<td>
																	<input type="date" class="form-control input-xs" style="width: 160px;" name="txttgl_se_18"  value="<?php echo $t_berangkat_SE_18; ?>">
																</td>
															</tr>
															<tr>
																<td>Jam Berangkat</td>
																<td>
																	<select style="width: 160px; text-transform: uppercase;" required name="txtjam_se_18" id="txtjam_se_18">
																		<?php
																			$qjam18  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
																			$hjam18  = mysql_query($qjam18);
																			while($rjam18 = mysql_fetch_array($hjam18)){
																				if($rjam18['jam'] == $j_berangkat_SE_18){
																					echo "
																							<option value='$rjam18[jam]' selected>$rjam18[jam] WIB</option>
																				 		 ";
																				}
																				else{
																					echo "
																							<option value='$rjam18[jam]'>$rjam18[jam] WIB</option>
																						";
																				}
																				
																			}
																		?>
																	</select>
																	<!--
																	<input type="text" class="form-control input-xs" style="width: 160px;" name="txtjam" required  value="<?php echo $j_berangkat_SE_18; ?>" />
																	-->
																</td>
															</tr>
														</table>
													</td>
													<td style="vertical-align: top; width: 50%;">
														<table>															
															<tr>
																<td style="width: 4%;">Tujuan</td>
																<td style="width: 46%;">
																	<select class="form-control input-sm" required name="txttujuan_se_18" id="txttujuan_se_18" style="width: 100%;">
																		<?php
																			$tuj18 = "SELECT * FROM _tbl_harga_tiket WHERE class_bus='PATAS/AC' ORDER BY tujuan ASC";
																			$hASE_18t  = mysql_query($tuj);
																			while($x18 = mysql_fetch_array($hASE_18t)){
																				if($rSE_18['id_tujuan'] == $x18['id']){
																					echo "
																						<option value='$x18[id]' selected>$x18[tujuan]</option>
																					 ";
																				}
																				else{
																					echo "
																						<option value='$x18[id]'>$x18[tujuan]</option>
																					 ";
																				}
																				
																			}
																		?>																		
																	</select>																	
																</td>
															</tr>															
															<tr>
																<td style="width: 15%;">&nbsp;</td>
																<td>
																	<div class="btn-group">
																		<button class="btn btn-primary hover" type="submit" id="tbl_Simpan_SE_18">
																			<i class="icon icon-left mdi mdi-check-all" id="ic_simpan"></i> <span id="txt_Simpan">SIMPAN</span>
																		</button>																		
																		<button class="btn btn-success hover" type="button" id="cetakSJ_SE_18">
																			<i class="icon icon-left mdi mdi-print"></i> CETAK SURAT JALAN
																		</button>																		
																	</div>
																	<hr style="margin-bottom: 8px; margin-top: 8px;"/>
																	<button data-modal="md-stickyUpMulti_SE_18" class="md-trigger btn btn-danger btn-block hover" type="button" id="tiketMulti_se_18">
																			<i class="icon icon-left mdi mdi-edit"></i> BELI TIKET BANYAK PENUMPANG
																	</button>	
																</td>
															</tr>
														</table>
													</td>
											</tr>											
										</table>
									 </form>
									 <table id="table2AC18" class="table table-striped table-fw-widget" style="border-top: 2px solid #CCC; width: 100%; background-color: #F8F8F8;">
										<thead>
										  <tr>
											<th style="width:12%; text-align: center">No. Bangku</th>
											<th style="width:30%;">Nama Penumpang</th>
											<th style="width:20%;">Alamat</th>
											<th style="width:15%;">No.Hp</th>											
											<th style="width:5%;"></th>
										  </tr>
										</thead>
                    					<tbody style="width: 100%;">
                    	<?php
												$query_SE_18 = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='".$rSE_18['id']."'";
												$hASE_18asil = mysql_query($query_SE_18);												
												while($rSE_18ow = mysql_fetch_array($hASE_18asil)){															
															echo "
																		<tr>
																			<td><b><center>".$rSE_18ow[no_bangku]."</center></b></td>
																			<td class='user-avatar'>".$rSE_18ow[nm_penumpang]."
																			</td>
																			<td>".$rSE_18ow[alamat]."</td>
																			<td>".$rSE_18ow[no_hp]."</td>
																			<td class='actions'>
																				<a href='delPenumpang.php?id=$rSE_18ow[id]&kursi=$rSE_18ow[no_bangku]&jadwal_code=$rSE_18ow[kd_jadwal]&view=ac_se_21&nomor=".$_GET['nomor']."&plut_num_eko_41=".$_GET['plut_num_eko_41']."&plut_num_ac_41=".$_GET['plut_num_ac_41']."&plut_num_ac_32=".$_GET['plut_num_ac_32']."&plut_num_se_18=".$_GET['plut_num_se_18']."' onClick=\"return confirm('Yakinkan anda untuk menghapus penumpang dengan nama: $rSE_18ow[nm_penumpang] ?')\" class='icon'><i class='mdi mdi-delete'></i></a>
																			</td>
																		</tr>
																	 ";
												}
										  ?>
										</tbody>
									  </table>
								</div>
							  </div>
						 </div>
					</div>
					<form name="frmMultiKursi_se_18" id="frmMultiKursi_se_18" method="POST" action="#">
																		<div id="md-stickyUpMulti_SE_18" class="modal-container modal-effect-7">
																			<div class="modal-content">
																				
																				<div class="modal-body">
																					<table id="penumpang_append_se_18" class="info" width="100%">
																						<tr id="buat_nama_se_18">
																							<td style="width: 22%;">
																								Pilih Kursi
																							</td>
																							<td style="padding-left: 5px; " colspan="2">																								
																								<select name="pil_kursi_multi_se_18" id="pil_kursi_multi_se_18" multiple>
																									<?php																										
																										$tmp_kursi_se_18  = "SELECT kursi_num FROM _tbm_tempkursi WHERE sts_kursi='0' AND id_jadwal='$rSE_18[id]' AND no_plat='$rSE_18[no_plat]' AND tgl_berangkat='$rSE_18[tgl_berangkat]'";
																										$h_tmp_se_18 	   = mysql_query($tmp_kursi_se_18);
																										while($r_kursi_se_18 = mysql_fetch_array($h_tmp_se_18)){
																											echo "<option vapue='$r_kursi_se_18[kursi_num]'>$r_kursi_se_18[kursi_num]</option>";
																										}
																									?>
																								</select>	
																								<input type="hidden" name="tmp_kursi_se_18" id="tmp_kursi_se_18" />
																								<input type="hidden" name="txt_tujuanhideMulti_se_18" value="<?php echo $rSE_18['tujuan']; ?>" />
																								<input type="hidden" name="txt_darinhideMulti_se_18" value="<?php echo $rSE_18['dari']; ?>" />
																								<input type="hidden" name="txt_idhideMulti_se_18" id="txt_idhideMulti_se_18" value="<?php echo $rSE_18['id']; ?>" />																								
																							</td>
																						</tr>																						
																						<tr>
																							<td>
																								Alamat
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtAlamatMulti_se_18" class="form-control input-sm"></textarea>
																							</td>
																						</tr>
																						<tr>
																							<td>
																								Nomor. HP
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<input name="txtNoHpMulti_se_18" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12">
																							</td>				
																						</tr>
																						<tr>
																							<td>
																								Total Ongkos
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																							<div class="input-group"><span class="input-group-addon">Rp</span>
																								<input type="hidden" name="hiddenOngkos_se_18" id="hiddenOngkos_se_18" value="<?php echo $rSE_18['harga_tiket']; ?>" />
																								<input name="txtOngkosMulti_se_18" id="txtOngkosMulti_se_18" style="width: 200px;" value="<?php echo $rSE_18['harga_tiket']; ?>" type="number" class="form-control input-sm" readonly />
																							</td>				
																						</tr>
																						<tr>
																							<td>
																								Keterangan
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtket_se_18" class="form-control input-sm"></textarea>
																								<input type="hidden" name="hargaNormal_se_18" value="<?php echo $rSE_18['harga_tiket']; ?>" />
																							</td>				
																						</tr>
																					</table>
																				</div>
																				<div class="modal-footer">
																					<div class="btn-group btn-space">        	
																						<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																						<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-check-all"></i> Cetak Tiket</button>   
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="modal-overlay"></div>
																	</form>
 <script type="text/javascript">
		$(document).ready(function(){	
			
			$("#pil_kursi_multi_se_18").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Kursi tidak ada!",
				width: "100%"
			});				
			$("#pil_kursi_multi_se_18").chosen().change(function(){	
				
				if($("#pil_kursi_multi_se_18").val() == ""){
					$(markup_se_18).remove();				
				}
				else{										
					arrData_se_18  = new Array($("#pil_kursi_multi_se_18").chosen().val());	
					var valData_se_18  = arrData_se_18[0];
					arrKursi_se_18 = valData_se_18.pop();
					var jum_pen_se_18 = arrData_se_18[0].length
					if(jum_pen_se_18 == 0){
						var hit_penumpang_se_18 = 1;
					}{
						var hit_penumpang_se_18 = 1 + jum_pen_se_18;
					}
					var getOngkos_se_18   = $("#hiddenOngkos_se_18").val();
					var ongkosMulti_se_18 = hit_penumpang_se_18 * parseInt(getOngkos_se_18);
					$("#txtOngkosMulti_se_18").val(ongkosMulti_se_18);
					//console.log(ongkosMulti);				
					$("#tmp_kursi_se_18").val($("#pil_kursi_multi_se_18").chosen().val());
					var markup_se_18 = "<tr><td style='vertical-align: middle;'>Nama Penumpang </td><td style='padding-left: 5px; width: 250px;'><input name='txtNamaPenumpang_se_18_" + arrKursi_se_18 +"' id='txtNamaPenumpang_se_18_"+ arrKursi_se_18 +"' type='text' class='form-control input-xs' required></td><td style='vertical-align: bottom;'><div class='input-group'><span class='input-group-addon input-xs'>Rp</span><input name='txtOPMulti__se_18_"+ arrKursi_se_18 +"' id='txtOPMulti__se_18_"+ arrKursi_se_18 +"' style='width: 100px;' value='<?php echo $rSE_18['harga_tiket']; ?>' type='number' class='form-control input-xs' required></div></td></tr>";
					$(markup_se_18).insertAfter("#buat_nama_se_18");	
					
					
					
				}				
			});
			
			
			
			$("#frmMultiKursi_se_18").submit(function(e) {			
				saveMultiKursi_SE_18();
				e.preventDefault();			
			});	

			function saveMultiKursi_SE_18(){
				if($("#pil_kursi_multi_se_18").chosen().val()==""){
					alert("Pilih Kursi Terlebih dahulu");
				}
				else{
					var confMsg = confirm('Yakinkan anda untuk melakukan Cetak Tiket ?');
					if(confMsg == true){
						var str = $("#frmMultiKursi_se_18").serialize();
						$.ajax({
							type: "POST",
							url: "saveMulti_SE_18.php",
							data: str,
							success: function(msgNew){
								window.open('<?php echo $apps->setHost("printTiketMulti.php"); ?>?id='+ $("#txt_idhideMulti_se_18").val() +'&no_kursi='+ $("#tmp_kursi_se_18").val(),'PrintTiket', 'width=700, height=400');						
								window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";										
							}
						})
					}
					else{
						return false;
					}
				}				
			}
			
			$("#txtplat_SE_18").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Nomor plat tidak ada!",
				width: "240"
			});
			$("#txttujuan_se_18").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Tujuan tidak ada!",
				width: "100%"
			});
			$("#txtplat_SE_18").change(function(){
				var nama_supir = $("#txtplat_SE_18 option:selected").val();				
				var has_nama   = nama_supir.split("-");
				$("#txtnmsupir_SE_18").val(has_nama[1]);
				$("#txtnomor_se_18").val(has_nama[0]);
				//console.log(has_nama);
			});
			

			/** 
			 * BUS AC
			 * 
			 **/

			 // Kursi No. 1
      		$("#frmKursi1_SE_18").submit(function(e) {			
				saveAC_01();
				e.preventDefault();			
			});	

			function saveAC_01(){
				var str = $("#frmKursi1_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){											
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=600');						
					}
				})
			}

			 // Kursi No. 2
      		$("#frmKursi2_SE_18").submit(function(e) {			
				saveAC_02();
				e.preventDefault();			
			});	

			function saveAC_02(){
				var str = $("#frmKursi2_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 3
      		$("#frmKursi3_SE_18").submit(function(e) {			
				saveAC_03();
				e.preventDefault();			
			});	

			function saveAC_03(){
				var str = $("#frmKursi3_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 4
      		$("#frmKursi4a_SE_18").submit(function(e) {			
				saveAC_04a();
				e.preventDefault();			
			});	

			function saveAC_04a(){
				var str = $("#frmKursi4a_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 5
      		$("#frmKursi5_SE_18").submit(function(e) {			
				saveAC_05();
				e.preventDefault();			
			});	

			function saveAC_05(){
				var str = $("#frmKursi5_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 6
      		$("#frmKursi6_SE_18").submit(function(e) {			
				saveAC_06();
				e.preventDefault();			
			});	

			function saveAC_06(){
				var str = $("#frmKursi6_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 7
      		$("#frmKursi7_SE_18").submit(function(e) {			
				saveAC_07();
				e.preventDefault();			
			});	

			function saveAC_07(){
				var str = $("#frmKursi7_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 8
      		$("#frmKursi8_SE_18").submit(function(e) {			
				saveAC_08();
				e.preventDefault();			
			});	

			function saveAC_08(){
				var str = $("#frmKursi8_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 9
      		$("#frmKursi9_SE_18").submit(function(e) {			
				saveAC_09();
				e.preventDefault();			
			});	

			function saveAC_09(){
				var str = $("#frmKursi9_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No.10
      		$("#frmKursi10_SE_18").submit(function(e) {			
				saveAC_10();
				e.preventDefault();			
			});	

			function saveAC_10(){
				var str = $("#frmKursi10_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 11
      		$("#frmKursi11_SE_18").submit(function(e) {			
				saveAC_11();
				e.preventDefault();			
			});	

			function saveAC_11(){
				var str = $("#frmKursi11_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 12
      		$("#frmKursi12_SE_18").submit(function(e) {			
				saveAC_12();
				e.preventDefault();			
			});	

			function saveAC_12(){
				var str = $("#frmKursi12_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			
			 // Kursi No. 13
      		$("#frmKursi13_SE_18").submit(function(e) {			
				saveAC_13();
				e.preventDefault();			
			});	

			function saveAC_13(){
				var str = $("#frmKursi13_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 14
      		$("#frmKursi14_SE_18").submit(function(e) {			
				saveAC_14();
				e.preventDefault();			
			});	

			function saveAC_14(){
				var str = $("#frmKursi14_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);				
						//window.location.reload();			
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 15
      		$("#frmKursi15_SE_18").submit(function(e) {			
				saveAC_15();
				e.preventDefault();			
			});	

			function saveAC_15(){
				var str = $("#frmKursi15_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 16
      		$("#frmKursi16_SE_18").submit(function(e) {			
				saveAC_16();
				e.preventDefault();			
			});	

			function saveAC_16(){
				var str = $("#frmKursi16_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);			
						//window.location.reload();				
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 17
      		$("#frmKursi17_SE_18").submit(function(e) {			
				saveAC_17();
				e.preventDefault();			
			});	

			function saveAC_17(){
				var str = $("#frmKursi17_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 18
      		$("#frmKursi18_SE_18").submit(function(e) {			
				saveAC_18();
				e.preventDefault();			
			});	

			function saveAC_18(){
				var str = $("#frmKursi18_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 19
      		$("#frmKursi19_SE_18").submit(function(e) {			
				saveAC_19();
				e.preventDefault();			
			});	

			function saveAC_19(){
				var str = $("#frmKursi19_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 20
      		$("#frmKursi20_SE_18").submit(function(e) {			
				saveAC_20();
				e.preventDefault();			
			});	

			function saveAC_20(){
				var str = $("#frmKursi20_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 21
      		$("#frmKursi21_SE_18").submit(function(e) {			
				saveAC_21();
				e.preventDefault();			
			});	

			function saveAC_21(){
				var str = $("#frmKursi21_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);				
						//window.location.reload();			
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 22
      		$("#frmKursi22_SE_18").submit(function(e) {			
				saveAC_22();
				e.preventDefault();			
			});	

			function saveAC_22(){
				var str = $("#frmKursi22_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 23
      		$("#frmKursi23_SE_18").submit(function(e) {			
				saveAC_23();
				e.preventDefault();			
			});	

			function saveAC_23(){
				var str = $("#frmKursi23_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 24
      		$("#frmKursi24_SE_18").submit(function(e) {			
				saveAC_24();
				e.preventDefault();			
			});	

			function saveAC_24(){
				var str = $("#frmKursi24_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 25
      		$("#frmKursi25_SE_18").submit(function(e) {			
				saveAC_25();
				e.preventDefault();			
			});	

			function saveAC_25(){
				var str = $("#frmKursi25_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 26
      		$("#frmKursi26_SE_18").submit(function(e) {			
				saveAC_26();
				e.preventDefault();			
			});	

			function saveAC_26(){
				var str = $("#frmKursi26_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 27
      		$("#frmKursi27_SE_18").submit(function(e) {			
				saveAC_27();
				e.preventDefault();			
			});	

			function saveAC_27(){
				var str = $("#frmKursi27_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 28
      		$("#frmKursi28_SE_18").submit(function(e) {			
				saveAC_28();
				e.preventDefault();			
			});	

			function saveAC_28(){
				var str = $("#frmKursi28_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 29
      		$("#frmKursi29_SE_18").submit(function(e) {			
				saveAC_29();
				e.preventDefault();			
			});	

			function saveAC_29(){
				var str = $("#frmKursi29_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 30
      		$("#frmKursi30_SE_18").submit(function(e) {			
				saveAC_30();
				e.preventDefault();			
			});	

			function saveAC_30(){
				var str = $("#frmKursi30_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 31
      		$("#frmKursi31_SE_18").submit(function(e) {			
				saveAC_31();
				e.preventDefault();			
			});	

			function saveAC_31(){
				var str = $("#frmKursi31_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 32
      		$("#frmKursi32_SE_18").submit(function(e) {			
				saveAC_32();
				e.preventDefault();			
			});	

			function saveAC_32(){
				var str = $("#frmKursi32_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 33
      		$("#frmKursi33_SE_18").submit(function(e) {			
				saveAC_33();
				e.preventDefault();			
			});	

			function saveAC_33(){
				var str = $("#frmKursi33_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);			
						//window.location.reload();				
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 34
      		$("#frmKursi34_SE_18").submit(function(e) {			
				saveAC_34();
				e.preventDefault();			
			});	

			function saveAC_34(){
				var str = $("#frmKursi34_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 35
      		$("#frmKursi35_SE_18").submit(function(e) {			
				saveAC_35();
				e.preventDefault();			
			});	

			function saveAC_35(){
				var str = $("#frmKursi35_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 36
      		$("#frmKursi36_SE_18").submit(function(e) {			
				saveAC_36();
				e.preventDefault();			
			});	

			function saveAC_36(){
				var str = $("#frmKursi36_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 37
      		$("#frmKursi37_SE_18").submit(function(e) {			
				saveAC_37();
				e.preventDefault();			
			});	

			function saveAC_37(){
				var str = $("#frmKursi37_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 38
      		$("#frmKursi38_SE_18").submit(function(e) {			
				saveAC_38();
				e.preventDefault();			
			});	

			function saveAC_38(){
				var str = $("#frmKursi38_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 39
      		$("#frmKursi39_SE_18").submit(function(e) {			
				saveAC_39();
				e.preventDefault();			
			});	

			function saveAC_39(){
				var str = $("#frmKursi39_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 40
      		$("#frmKursi40_SE_18").submit(function(e) {			
				saveAC_40();
				e.preventDefault();			
			});	

			function saveAC_40(){
				var str = $("#frmKursi40_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 41
      		$("#frmKursi41_SE_18").submit(function(e) {			
				saveAC_41();
				e.preventDefault();			
			});	

			function saveAC_41(){
				var str = $("#frmKursi41_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 42
      		$("#frmKursi42_SE_18").submit(function(e) {			
				saveAC_42();
				e.preventDefault();			
			});	

			function saveAC_42(){
				var str = $("#frmKursi42_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 43
      		$("#frmKursi43_SE_18").submit(function(e) {			
				saveAC_43();
				e.preventDefault();			
			});	

			function saveAC_43(){
				var str = $("#frmKursi43_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 44
      		$("#frmKursi44_SE_18").submit(function(e) {			
				saveAC_44();
				e.preventDefault();			
			});	

			function saveAC_44(){
				var str = $("#frmKursi44_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();							
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}

			 // Kursi No. 45
      		$("#frmKursi45_SE_18").submit(function(e) {			
				saveAC_45();
				e.preventDefault();			
			});	

			function saveAC_45(){
				var str = $("#frmKursi45_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);	
						//window.location.reload();						
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 46
      		$("#frmKursi46_SE_18").submit(function(e) {			
				saveAC_46();
				e.preventDefault();			
			});	

			function saveAC_46(){
				var str = $("#frmKursi46_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);		
						//window.location.reload();					
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=800, height=600');	
					}
				})
			}


			 // Kursi No. 48
      		$("#frmKursi48_SE_18").submit(function(e) {			
				saveAC_48();
				e.preventDefault();			
			});	

			function saveAC_48(){
				var str = $("#frmKursi48_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "save_SE_18.php",
					data: str,
					success: function(msg){						
						var obj = JSON.parse(msg);
						console.log(obj);
						//window.location.reload();	
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?ac_se_21=active&nomor=<?php echo $_GET['nomor']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_se_18=<?php echo $_GET['plut_num_se_18']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=650, height=400');																	
						if(msg == "OK"){
								//setTimeout("menyimpan()", 800);
								
						}
						else{

						}
					}
				})
			}
		
			/**
			 * Fungsi Simpan Nomor Plat, Nama Supir dan Tujuan
			 *  
			 **/ 
			$("#frmAC_SE_18").submit(function(e) {			
				saveKeberangkatan_SE_18();
				e.preventDefault();			
			});	
			
			function saveKeberangkatan_SE_18(){
				var str = $("#frmAC_SE_18").serialize();
				$.ajax({
					type: "POST",
					url: "saveKeberangkatan_SE_18.php",
					data: str,
					success: function(msg){	
						console.log(msg);					
						if(msg == "OK"){
								setTimeout("menyimpan_SE_18()", 800);											
						}
						else{

						}
					}
				})
			}


			
		})
			function displayMsg(){
					$.extend($.gritter.options, { position: 'bottom-right' });
					$.gritter.add({
							title: "<i class='icon mdi mdi-info'></i> Informasi",
							text: "Data berhasil disimpan",
							class_name: 'color success',
							sticky: true
					});
					return false;					
			}
			function menyimpan(){
					$("#ic_simapn").hide();
					$("#txt_Simpan").text("SIMPAN...");
					setTimeout("displayMsg()", 1200);
					disableAll();
			}
			function disableAll(){
					$("#frmEkonomi :input").attr("disabled", true);
					$("#cetakSJ").attr("disabled", false);
					setTimeout("kembali()", 800);
			}

			function kembali(){
					$("#ic_simapn").show();
					$("#txt_Simpan").text("SIMPAN");
					window.location.href="apps.php?ekonomi=active";
			}



			/**
			 * Bagian AC
			 * 
			 **/ 

			 function displayMsg_SE_18(){
					$.extend($.gritter.options, { position: 'bottom-right' });
					$.gritter.add({
							title: "<i class='icon mdi mdi-info'></i> Informasi",
							text: "Data berhasil disimpan",
							class_name: 'color success',
							sticky: true
					});
					return false;					
			}
			function menyimpan_SE_18(){
					$("#ic_simapn_SE_18").hide();
					$("#txt_Simpan_SE_18").text("SIMPAN...");
					setTimeout("displayMsg_SE_18()", 1200);
					disableAll_SE_18();
			}
			function disableAll_SE_18(){
					$("#frmAC_SE_18 :input").attr("disabled", true);
					$("#cetakSJ_SE_18").attr("disabled", false);
					setTimeout("kembali_SE_18()", 800);
			}

			function kembali_SE_18(){
					$("#ic_simapn_SE_18").show();
					$("#txt_Simpan_SE_18").text("SIMPAN");
					window.location.href="apps.php?ac_se_21=active&plut_num_se_18=" + $("#txtnomor_se_18").val() + "&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&nomor=<?php echo $_GET['nomor']; ?>";
			}
	</script>