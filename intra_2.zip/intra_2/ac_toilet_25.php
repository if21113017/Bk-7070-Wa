<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<style type="text/css">
	table{
		border: 0px solid red;
		padding: 0px;
	}
	td{
		border: 0px solid red;
		padding: 2px;
		text-align: left;
	}
</style>
<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
?>
<div class="row">
						  <div class="col-md-3">
							  <div class="card ">
								<div class="card-content" style="padding-left:20px;">
									<?php
										$sql = "SELECT * FROM _tbl_jadwal WHERE id='$_GET[id]'";
										$id  = $_GET['id'];
										$res = mysql_query($sql);
										$isAda = mysql_num_rows($res);
										if($isAda > 0){
											$r   = mysql_fetch_array($res);
										}
										else{

										}
									?>
									  <table id="tg-VbtHW" style="width: 220px; margin-top: 20px;">
										  <tr>
											<th colspan="2"><center></center></th>
											<th rowspan="10"></th>
											<th colspan="2">
												<center>
													<img src="assets/img/supir.png" style="width: 30px; padding-bottom: 7px;" />
												</center>
											</th>
										  </tr>
										  <tr>
											<th colspan="2" style="text-align: center;">KERNET</th>
											<th  colspan="2" style="text-align: center;">SUPIR</th>
										  </tr>
										  <tr>
											<td>
												<center>
												<?php
													$no_bangku_ac_25_1 = $apps->cekKursi("1", $id);
													if($no_bangku_ac_25_1 == "ADA"){
												?>
													<div data-modal="md-stickyUp_AC25" class="kursi_berisi">1</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp_AC25" class="kursi_kosong md-trigger">1</div>
												<?php
													}
												?>
												</center>
												<form name="frmKursi1_AC25" id="frmKursi1_AC25" method="post" action="#">
													<div id="md-stickyUp_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="1">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25A form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25A form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
												<?php
													$no_bangku_ac_25_2 = $apps->cekKursi("2", $id);
													if($no_bangku_ac_25_2 == "ADA"){
												?>
													<div data-modal="md-stickyUp2_AC25" class="kursi_berisi">2</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp2_AC25" class="kursi_kosong md-trigger">2</div>
												<?php
													}
												?>

												</center>
												<form name="frmKursi2_AC25" id="frmKursi2_AC25" method="post" action="#">
													<div id="md-stickyUp2_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="2">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25B form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" type="number" value="<?php echo $r['harga_tiket']; ?>" class="Ongkos_AC_25B form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
											<center>
												<?php
													$no_bangku_ac_25_3 = $apps->cekKursi("3", $id);
													if($no_bangku_ac_25_3 == "ADA"){
												?>
													<div data-modal="md-stickyUp3_AC25" class="kursi_berisi">3</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp3_AC25" class="kursi_kosong md-trigger">3</div>
												<?php
													}
												?>
											</center>
											<form name="frmKursi3_AC25" id="frmKursi3_AC25" method="post" action="#">
													<div id="md-stickyUp3_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="3">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25C form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25C form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
											<center>
												<?php
													$no_bangku_ac_25_4 = $apps->cekKursi("4", $id);
													if($no_bangku_ac_25_4 == "ADA"){
												?>
													<div data-modal="md-stickyUp4a_AC25" class="kursi_berisi">4</div>
												<?php
													}
													else{
												?>
													<div data-modal="md-stickyUp4a_AC25" class="kursi_kosong md-trigger">4</div>
												<?php
													}
												?>

											</center>
											<form name="frmKursi4a_AC25" id="frmKursi4a_AC25" method="post" action="#">
													<div id="md-stickyUp4a_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly value="4">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25D form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25D form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
											<center>
													<?php
														$no_bangku_ac_25_5 = $apps->cekKursi("5", $id);
														if($no_bangku_ac_25_5 == "ADA"){
													?>
														<div data-modal="md-stickyUp5_AC25" class="kursi_berisi">5</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp5_AC25" class="kursi_kosong md-trigger">5</div>
													<?php
														}
													?>

											</center>
											<form name="frmKursi5_AC25" id="frmKursi5_AC25" method="post" action="#">
													<div id="md-stickyUp5_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="5">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25E form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25E form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_6 = $apps->cekKursi("6", $id);
														if($no_bangku_ac_25_6 == "ADA"){
													?>
														<div data-modal="md-stickyUp6_AC25" class="kursi_berisi">6</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp6_AC25" class="kursi_kosong md-trigger">6</div>
													<?php
														}
													?>


												</center>
											<form name="frmKursi6_AC25" id="frmKursi6_AC25" method="post" action="#">
													<div id="md-stickyUp6_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="6">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25F form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25F form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_7 = $apps->cekKursi("7", $id);
														if($no_bangku_ac_25_7 == "ADA"){
													?>
														<div data-modal="md-stickyUp7_AC25" class="kursi_berisi">7</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp7_AC25" class="kursi_kosong md-trigger">7</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi7_AC25" id="frmKursi7_AC25" method="post" action="#">
													<div id="md-stickyUp7_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="7">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25G form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25G form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_8 = $apps->cekKursi("8", $id);
														if($no_bangku_ac_25_8 == "ADA"){
													?>
														<div data-modal="md-stickyUp8_AC25" class="kursi_berisi">8</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp8_AC25" class="kursi_kosong md-trigger">8</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi8_AC25" id="frmKursi8_AC25" method="post" action="#">
													<div id="md-stickyUp8_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="8">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25H form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25H form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_9 = $apps->cekKursi("9", $id);
														if($no_bangku_ac_25_9 == "ADA"){
													?>
														<div data-modal="md-stickyUp9_AC25" class="kursi_berisi">9</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp9_AC25" class="kursi_kosong md-trigger">9</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi9_AC25" id="frmKursi9_AC25" method="post" action="#">
													<div id="md-stickyUp9_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="9">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25I form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25I form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_10 = $apps->cekKursi("10", $id);
														if($no_bangku_ac_25_10 == "ADA"){
													?>
														<div data-modal="md-stickyUp10_AC25" class="kursi_berisi">10</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp10_AC25" class="kursi_kosong md-trigger">10</div>
													<?php
														}
													?>


												</center>
											<form name="frmKursi10_AC25" id="frmKursi10_AC25" method="post" action="#">
													<div id="md-stickyUp10_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="10">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25J form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25J form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_11 = $apps->cekKursi("11", $id);
														if($no_bangku_ac_25_11 == "ADA"){
													?>
														<div data-modal="md-stickyUp11_AC25" class="kursi_berisi">11</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp11_AC25" class="kursi_kosong md-trigger">11</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi11_AC25" id="frmKursi11_AC25" method="post" action="#">
													<div id="md-stickyUp11_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="11">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25K form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25K form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_12 = $apps->cekKursi("12", $id);
														if($no_bangku_ac_25_12 == "ADA"){
													?>
														<div data-modal="md-stickyUp12_AC25" class="kursi_berisi">12</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp12_AC25" class="kursi_kosong md-trigger">12</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi12_AC25" id="frmKursi12_AC25" method="post" action="#">
													<div id="md-stickyUp12_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="12">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25L form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25L form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form></td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_13 = $apps->cekKursi("13", $id);
														if($no_bangku_ac_25_13 == "ADA"){
													?>
														<div data-modal="md-stickyUp13_AC25" class="kursi_berisi">13</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp13_AC25" class="kursi_kosong md-trigger">13</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi13_AC25" id="frmKursi13_AC25" method="post" action="#">
													<div id="md-stickyUp13_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="13">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25M form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25M form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_14 = $apps->cekKursi("14", $id);
														if($no_bangku_ac_25_14 == "ADA"){
													?>
														<div data-modal="md-stickyUp14_AC25" class="kursi_berisi">14</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp14_AC25" class="kursi_kosong md-trigger">14</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi14_AC25" id="frmKursi14_AC25" method="post" action="#">
													<div id="md-stickyUp14_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="14">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25N form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25N form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_15 = $apps->cekKursi("15", $id);
														if($no_bangku_ac_25_15 == "ADA"){
													?>
														<div data-modal="md-stickyUp15_AC25" class="kursi_berisi">15</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp15_AC25" class="kursi_kosong md-trigger">15</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi15_AC25" id="frmKursi15_AC25" method="post" action="#">
													<div id="md-stickyUp15_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="15">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25O form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25O form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>

											<td>
												<center>
													<?php
														$no_bangku_ac_25_16 = $apps->cekKursi("16", $id);
														if($no_bangku_ac_25_16 == "ADA"){
													?>
														<div data-modal="md-stickyUp16_AC25" class="kursi_berisi">16</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp16_AC25" class="kursi_kosong md-trigger">16</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi16_AC25" id="frmKursi16_AC25" method="post" action="#">
													<div id="md-stickyUp16_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="16">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25P form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25P form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_17 = $apps->cekKursi("17", $id);
														if($no_bangku_ac_25_17 == "ADA"){
													?>
														<div data-modal="md-stickyUp17_AC25" class="kursi_berisi">17</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp17_AC25" class="kursi_kosong md-trigger">17</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi17_AC25" id="frmKursi17_AC25" method="post" action="#">
													<div id="md-stickyUp17_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="17">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25Q form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25Q form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_18 = $apps->cekKursi("18", $id);
														if($no_bangku_ac_25_18 == "ADA"){
													?>
														<div data-modal="md-stickyUp18_AC25" class="kursi_berisi">18</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp18_AC25" class="kursi_kosong md-trigger">18</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi18_AC25" id="frmKursi18_AC25" method="post" action="#">
													<div id="md-stickyUp18_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="18">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25R form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25R form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_19 = $apps->cekKursi("19", $id);
														if($no_bangku_ac_25_19 == "ADA"){
													?>
														<div data-modal="md-stickyUp19_AC25" class="kursi_berisi">19</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp19_AC25" class="kursi_kosong md-trigger">19</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi19_AC25" id="frmKursi19_AC25" method="post" action="#">
													<div id="md-stickyUp19_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="19">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25S form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25S form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_20 = $apps->cekKursi("20", $id);
														if($no_bangku_ac_25_20 == "ADA"){
													?>
														<div data-modal="md-stickyUp20_AC25" class="kursi_berisi">20</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp20_AC25" class="kursi_kosong md-trigger">20</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi20_AC25" id="frmKursi20_AC25" method="post" action="#">
													<div id="md-stickyUp20_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="20">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25T form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25T form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_21 = $apps->cekKursi("21", $id);
														if($no_bangku_ac_25_21 == "ADA"){
													?>
														<div data-modal="md-stickyUp21_AC25" class="kursi_berisi">21</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp21_AC25" class="kursi_kosong md-trigger">21</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi21_AC25" id="frmKursi21_AC25" method="post" action="#">
													<div id="md-stickyUp21_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="21">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25U form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25U form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_22 = $apps->cekKursi("22", $id);
														if($no_bangku_ac_25_22 == "ADA"){
													?>
														<div data-modal="md-stickyUp22_AC25" class="kursi_berisi">22</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp22_AC25" class="kursi_kosong md-trigger">22</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi22_AC25" id="frmKursi22_AC25" method="post" action="#">
													<div id="md-stickyUp22_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="22">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25V form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25V form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_23 = $apps->cekKursi("23", $id);
														if($no_bangku_ac_25_23 == "ADA"){
													?>
														<div data-modal="md-stickyUp23_AC25" class="kursi_berisi">23</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp23_AC25" class="kursi_kosong md-trigger">23</div>
													<?php
														}
													?>

												</center>
												<form name="frmKursi23_AC25" id="frmKursi23_AC25" method="post" action="#">
													<div id="md-stickyUp23_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="23">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25W form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25W form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_24 = $apps->cekKursi("24", $id);
														if($no_bangku_ac_25_24 == "ADA"){
													?>
														<div data-modal="md-stickyUp24_AC25" class="kursi_berisi">24</div>
													<?php
														}
														else{
													?>
														<div data-modal="md-stickyUp24_AC25" class="kursi_kosong md-trigger">24</div>
													<?php
														}
													?>

												</center>
											<form name="frmKursi24_AC25" id="frmKursi24_AC25" method="post" action="#">
													<div id="md-stickyUp24_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="24">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25X form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25X form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
										  </tr>

										  <tr>
											<td>
												<center>
													<?php
														$no_bangku_ac_25_25 = $apps->cekKursi("25", $id);
														if($no_bangku_ac_25_25 == "ADA"){
													?>
													<div data-modal="md-stickyUp25_AC25" class="kursi_berisi">25</div>
													<?php
														}
														else{
													?>
													<div data-modal="md-stickyUp25_AC25" class="kursi_kosong md-trigger">25</div>
													<?php
														}
													?>

												</center>
												<form name="frmKursi25_AC25" id="frmKursi25_AC25" method="post" action="#">
													<div id="md-stickyUp25_AC25" class="modal-container modal-effect-7">
														<div class="modal-content">

															<div class="modal-body">
																<table class="info" width="100%">
																	<tr>
																		<td style="width: 22%;">
																			Nomor Kursi
																		</td>
																		<td style="padding-left: 5px; ">
																			<input name="txtNoKursi" type="text" class="form-control input-sm" style="width: 80px; font-weight: bold;" readonly required value="25">
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nama Penumpang
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNamaPenumpang" type="text" class="form-control input-xs" required>
																			<input type="hidden" name="txt_tujuanhide" value="<?php echo $r['tujuan']; ?>" />
																			<input type="hidden" name="txt_darinhide" value="<?php echo $r['dari']; ?>" />
																			<input type="hidden" name="txt_idhide" value="<?php echo $r['id']; ?>" />
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Alamat
																		</td>
																		<td style="padding-left: 5px;">
																			<textarea name="txtAlamat" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Nomor. HP
																		</td>
																		<td style="padding-left: 5px;">
																			<input name="txtNoHp" type="text" class="form-control input-xs" style="width: 243px;" value="0">
																		</td>
																	</tr>
																	<tr>
																		<td>Tujuan</td>
																		<td style="padding-left: 5px;">
																			<select name="txttujuanManual_AC_25" id="txttujuanManual_AC_25" style="width: 100%;" class="Manual_AC_25Y form-control input-xs">
																				<option value="0">- Pilih Tujuan -</option>
																				<?php
																					$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																					$htMan_AC_25  = mysql_query($tujMan_AC_25);
																					while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																							echo "
																								<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																							 ";
																					}
																				?>
																			</select>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			Ongkos
																		</td>
																		<td style="padding-left: 5px;">
																		<div class="input-group xs-mb-15"><span class="input-group-addon">Rp</span>
																			<input name="txtOngkos" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" readonly class="Ongkos_AC_25Y form-control input-sm" required>
																		</td>
																	</tr>
																</table>
															</div>
															<div class="modal-footer">
																<div class="btn-group btn-space">
																	<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																	<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																</div>
															</div>
														</div>
													</div>
													<div class="modal-overlay"></div>
												</form>
											</td>
											<td>

											</td>

											<th colspan="2" style="text-align: center;"><div class="box_toilet">TOILET<div></th>
										  </tr>
										  <tr>
											<td colspan="2"></td>

										  </tr>


										  <tr>

											<td>

											</td>
											<td>

											</td>

											<td style="width: 25px;">&nbsp;</td>
											<th colspan="2" style="text-align: center;"></th>
										  </tr>
										  <tr>
											<td colspan="5" style="text-align: center;"><div class="box_belakang">&nbsp;</div></td>
										  </tr>
									</table>
								</div>
							  </div>
						 </div>
						 <div class="col-md-9" style="background-color: #E9E9E9; padding: 10px; margin-left: -70px; margin-top: 50px;">
						 	  <?php echo $setInfo; ?>
							  <div class="card ">
								<div class="card-content">
									<div class="bg_box">
									<form action="#" method="POST" name="frmAC_Toilet_25" id="frmAC_Toilet_25">
										<table style="width: 100%;">
											<tr>
													<td style="width: 100%;">
														<div class="row">
															<div class="col-md-6">
																<table style="width: 100%;">
																<tr>
																	<th style="width: 23%; text-transform: uppercase;">
																		PLAT BUS
																		<input type="hidden" name="id_url" id="id_url" value="<?php echo $_GET['id']; ?>" />
																	</th>
																	<td>
																		: <?php echo $r['no_plat']; ?>
																	</td>
																</tr>
																<tr>
																	<th style="text-transform: uppercase;">Tgl Berangkat</b></th>
																	<td colspan="2">
																		: <?php echo $r['tgl_berangkat']; ?>
																	</td>
																</tr>
																<tr>
																	<th style="text-transform: uppercase;">Tujuan</th>
																	<td colspan="2">
																		: <?php echo $r['dari']." - ".$r['tujuan']; ?>
																	</td>
																</tr>
																</table>
															</div>
															<div class="col-md-6">
																<table style="width: 100%;">
																	<tr>
																		<th style="vertical-align: middle; text-transform: uppercase;">Jam Berangkat</th>
																		<td colspan="2">
																			: <?php echo $r['jam_berangkat']; ?> WIB
																		</td>
																	</tr>
																	<tr>
																		<th style="width: 23%; text-transform: uppercase;">Nama Supir</th>
																		<td>
																			: <?php echo $r['nm_supir']; ?>
																		</td>
																	</tr>
																</table>
															</div>
														</div>

														<div class="dived">&nbsp;</div>
															<div class="row">
																<div class="col-sm-4">
																	<div clas="pull-left">
																		<button type="button" onClick="window.location.href='apps.php?mod=jualTiketV2&menu=false'" class="btn btn-danger"><i class="icon icon-left mdi mdi-arrow-left"></i> KEMBALI</button>
																	</div>
																</div>
																<div class="col-sm-8">
																	<div class="btn-group pull-right">
																		<a href="#" data-modal="md-stickyUpPaketAC25" class="btn btn-primary md-trigger"><i class="icon icon-left mdi mdi-edit"></i> INPUT PAKET/BARANG</a>
																		<a href="#" data-modal="md-stickyUpListPaketAC25" class="btn btn-success md-trigger"><i class="icon mdi mdi-book"></i> DATA PAKET/BARANG</a>
																		<button data-modal="md-stickyUpMulti_AC_25" class="md-trigger btn btn-warning hover" type="button" id="tiketMulti" style="margin-left: 10px;">
																			<i class="icon icon-left mdi mdi-edit"></i> BELI TIKET BANYAK PENUMPANG
																		</button>
																	</div>
																</div>
															</div>

														<div id="md-stickyUpIsiKomis_ac_25" class="modal-container colored-header colored-header-primary modal-effect-11">
															<div class="modal-content" style="border-radius: 5px;">
																 <div class="modal-header" style="padding: 10px;">
																	<a href="#" data-dismiss="modal" aria-hidden="true" class="close modal-close"><span class="mdi mdi-close"></span></a>
																	<h3 class="modal-title">Input Komisi</h3>
																</div>
																<div class="modal-body">
																	<table class="table table-striped">
																		<tr>
																			<th style="width: 19%; vertical-align: middle;">Admin Kantor</th>
																			<td>
																				<div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input type="text" name="adminktr_ac_25" id="adminktr_ac_25" data-a-sep="." data-a-dec="," class="form-control input-xs" style="width: 180px;" /></div></td>
																		</tr>
																		<tr>
																			<th style="width: 19%; vertical-align: middle;">Tiket</th>
																			<td><div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input type="text" name="admintiket_ac_25" id="admintiket_ac_25" data-a-sep="." data-a-dec="," class="form-control input-xs" style="width: 180px;"/></div></td>
																		</tr>
																	</table>
																	<hr class="style15" />
																	<div class="pull-right" style="margin-bottom: 15px;">
																		<button type="button" id="cetakSJAC_Toilet_25" class="btn btn-success hover">
																			<i class="icon icon-left mdi mdi-print"></i> CETAK SURAT JALAN
																		</button>
																	</div>
																</div>
															</div>
														</div>
														<div class="modal-overlay"></div>
													</td>
											</tr>
										</table>
									 </form>
									 </div>

									 <table id="table2AC25_A" class="table table-striped table-fw-widget" style="border-top: 2px solid #CCC; width: 100%; background-color: #F8F8F8;">
										<thead>
										  <tr>
											<th style="width:12%; text-align: center; text-transform: uppercase;">No. Bangku</th>
											<th style="width:25%; text-transform: uppercase;">Nama Penumpang</th>
											<th style="width:20%; text-transform: uppercase;">Alamat</th>
											<th style="width:19%; text-transform: uppercase;">Tujuan</th>
											<th style="width:12%; text-transform: uppercase;">No.Hp</th>
											<th style="width:5%; text-transform: uppercase;"></th>
										  </tr>
										</thead>
                    					<tbody style="width: 100%;">
                    	<?php
												$query_AC25 = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='".$r['id']."' AND is_booking='0'";
												$hAC_Toilet_25asil = mysql_query($query_AC25);
												while($row = mysql_fetch_array($hAC_Toilet_25asil)){
															echo "
																		<tr>
																			<td><b><center>".$row[no_bangku]."</center></b></td>
																			<td class='user-avatar'>".$row[nm_penumpang]."
																			</td>
																			<td>".$row[alamat]."</td>
																			<td>".$row[tujuan]."</td>
																			<td>".$row[no_hp]."</td>
																			<td class='actions'>
																				<a class='btn btn-sm btn-danger hover' title='Hapus' href='delPenumpang.php?id_tiket=$row[id]&kursi=$row[no_bangku]&jadwal_code=$row[kd_jadwal]&mod=$_GET[mod]' onClick=\"return confirm('Yakinkan anda untuk menghapus penumpang dengan nama: $row[nm_penumpang] ?')\" class='icon'><i class='mdi mdi-delete'></i></a>
																			</td>
																		</tr>
																	 ";
												}
										  ?>
										</tbody>
									  </table>
								</div>
							  </div>
						 </div>
					</div>

					<form name="frmMultiKursi_ac_25" id="frmMultiKursi_ac_25" method="POST" action="#">
																		<div id="md-stickyUpMulti_AC_25" class="modal-container modal-effect-7">
																			<div class="modal-content">

																				<div class="modal-body">
																					<table id="penumpang_append_ac_25" class="info" width="100%">
																						<tr>
																							<td>Tujuan</td>
																							<td style="padding-left: 5px;">
																								<select name="txttujuanManualMulti_AC_25" id="txttujuanManualMulti_AC_25" style="width: 100%;" class="manualMulti_AC_32 form-control input-xs">
																									<option value="0">- Pilih Tujuan -</option>
																									<?php
																										$tujMan_AC_25 = "SELECT tujuan, harga FROM _tbl_harga_tiket WHERE class_bus='ac_toilet_21_25' ORDER BY tujuan ASC";
																										$htMan_AC_25  = mysql_query($tujMan_AC_25);
																										while($xMan_AC_25_r = mysql_fetch_array($htMan_AC_25)){
																												echo "
																													<option value='$xMan_AC_25_r[tujuan]#$xMan_AC_25_r[harga]'>$xMan_AC_25_r[tujuan]</option>
																												 ";
																										}
																									?>
																								</select>
																							</td>
																						</tr>
																						<tr id="buat_nama_ac_25">
																							<td style="width: 22%;">
																								Pilih Kursi
																							</td>
																							<td style="padding-left: 5px; " colspan="2">
																								<select name="pil_kursi_multi_ac_25" id="pil_kursi_multi_ac_25" multiple>
																									<?php
																										$tmp_kursi_ac_t25  = "SELECT kursi_num FROM _tbm_tempkursi WHERE sts_kursi='0' AND id_jadwal='$r[id]' AND no_plat='$r[no_plat]' AND tgl_berangkat='$r[tgl_berangkat]'";
																										$h_tmp_ac_25 	   = mysql_query($tmp_kursi_ac_t25);
																										while($r_kursi_ac_25 = mysql_fetch_array($h_tmp_ac_25)){
																											echo "<option vapue='$r_kursi_ac_25[kursi_num]'>$r_kursi_ac_25[kursi_num]</option>";
																										}
																									?>
																								</select>
																								<input type="hidden" name="tmp_kursi_ac_25" id="tmp_kursi_ac_25" />
																								<input type="hidden" name="txt_tujuanhideMulti_ac_25" value="<?php echo $r['tujuan']; ?>" />
																								<input type="hidden" name="txt_darinhideMulti_ac_25" value="<?php echo $r['dari']; ?>" />
																								<input type="hidden" name="txt_idhideMulti_ac_25" id="txt_idhideMulti_ac_25" value="<?php echo $r['id']; ?>" />
																							</td>
																						</tr>
																						<tr>
																							<td>
																								Alamat
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtAlamatMulti_ac_25" class="form-control input-sm">PEMATANGSIANTAR</textarea>
																							</td>
																						</tr>
																						<tr>
																							<td>
																								Nomor. HP
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<input name="txtNoHpMulti_ac_25" type="text" class="form-control input-xs" style="width: 243px;" maxlength="12" value="0">
																							</td>
																						</tr>
																						<tr>
																							<td>
																								Total Ongkos
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																							<div class="input-group"><span class="input-group-addon">Rp</span>
																								<input type="hidden" name="hiddenOngkos_AC_25" id="hiddenOngkos_AC_25" value="<?php echo $r['harga_tiket']; ?>" />
																								<input name="txtOngkosMulti_ac_25" id="txtOngkosMulti_ac_25" style="width: 200px;" value="<?php echo $r['harga_tiket']; ?>" type="number" class="form-control input-sm" readonly />
																							</td>
																						</tr>
																						<tr>
																							<td>
																								Keterangan
																							</td>
																							<td style="padding-left: 5px;" colspan="2">
																								<textarea name="txtket_ac_25" class="form-control input-sm">-</textarea>
																								<input type="hidden" name="hargaNormal_ac_25" id="hargaNormal_ac_25" value="<?php echo $r['harga_tiket']; ?>" />
																								<input type="hidden" name="temp_ongkosmulti_AC_25_TR" id="temp_ongkosmulti_AC_25_TR"  />
																							</td>
																						</tr>
																					</table>
																				</div>
																				<div class="modal-footer">
																					<div class="btn-group btn-space">
																						<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																						<button type="submit" class="btn btn-success hover"><i class="icon mdi mdi-print"></i> Cetak Tiket</button>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="modal-overlay"></div>
																	</form>


																	<form name="frmPaketAC25" id="frmPaketAC25" method="POST" action="#">
																		<div id="md-stickyUpPaketAC25" class="modal-container colored-header colored-header-success modal-effect-10">
																			<div class="modal-content" style="border-radius: 5px;">
																				<div class="modal-header" style="padding: 10px;">
																					<a href="#" data-dismiss="modal" aria-hidden="true" class="close modal-close"><span class="mdi mdi-close"></span></a>
																					<h3 class="modal-title"><i class="icon mdi mdi-book"></i> Input Paket/Barang</h3>
																				</div>
																				<div class="modal-body">
																					<table class="table table-striped" class="info" width="100%">
																						<tr>
																							<th style="width: 140px; vertical-align: middle">
																								Nama Barang/Paket
																							</th>
																							<td>
																								<input name="txtNamaBarang" id="txtNamaBarangAC25" type="text" class="form-control input-sm" required />
																							</td>
																						</tr>
																						<tr>
																							<th style="width: 140px; vertical-align: middle">
																								Biaya/Ongkos
																							</th>
																							<td>
																							<div class="input-group"><span class="input-group-addon">Rp</span>
																								<input type="hidden" name="hiddenOngkos" id="hiddenOngkos" />
																								<input name="txtBiayaPaket" id="txtBiayaPaketAC25" style="width: 200px;" type="text" class="txtBiaya form-control input-sm" required />
																							</td>
																						</tr>
																						<tr>
																							<th style="width: 140px; vertical-align: middle">
																								Satuan
																							</th>
																							<td>
																								<select name="txtsatuan" class="form-control input-sm" style="width: 242px;">
																									<option value="PCS">PCS</option>
																									<option value="Kotak">Kotak</option>
																									<option value="Bungkus">Bungkus</option>
																								</select>
																							</td>
																						</tr>
																						<tr>
																							<th style="width: 140px; vertical-align: middle">
																								Keterangan
																							</th>
																							<td>
																								<textarea name="txtketBarang" id="txtketBarangAC25" class="form-control input-sm"></textarea>
																							</td>
																						</tr>
																					</table>
																					<input type="hidden" name="idJadwalEko44" value="<?php echo $r['id']; ?>" />
																					<div class="msgPaketAC25" style="margin-bottom: -20px;"></div>
																				</div>
																				<div class="modal-footer">
																					<div class="btn-group">
																						<button type="submit" id="btnPaketAC25" class="btn btn-primary hover"><i class="icon mdi mdi-save"></i> Simpan Paket</button>
																						<button type="button" class="btn modal-close btn-danger hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="modal-overlay"></div>
																	</form>

																			<div id="md-stickyUpListPaketAC25" class="modal-container colored-header colored-header-primary modal-effect-14">
																			<div class="modal-content" style="border-radius: 5px; width: 980px; right: 28%;">
																				<div class="modal-header" style="padding: 10px;">
																					<a href="#" data-dismiss="modal" aria-hidden="true" class="close modal-close"><span class="mdi mdi-close"></span></a>
																					<h3 class="modal-title"><i class="icon mdi mdi-book"></i> Data Paket/Barang</h3>
																				</div>
																				<div class="modal-body">
																					<table class="table table-striped" class="info" width="100%">
																						<thead>
																							<tr style="background-color: #DCDCDC; border-bottom: 2px solid #BBB;">
																								<th>No.</th><th>Nama Barang</th><th>Satuan</th><th>Biaya/Ongkos</th><th>Keterangan</th><th>Aksi</th>
																							</tr>
																						</thead>
																						<tbody>
																							<?php
																								$sqlPaket6 = "SELECT * FROM _tbl_paket WHERE kd_jadwal='$r[id]'";
																								$hPaket6	  = mysql_query($sqlPaket6);
																								$noP6	  = 0;
																								while($xPaket6 = mysql_fetch_array($hPaket6)){
																									$noP6++;
																									echo "
																											<tr>
																												<td>$noP6.</td>
																												<td>$xPaket6[nm_barang]</td>
																												<td>$xPaket6[satuan]</td>
																												<td>$xPaket6[biaya]</td>
																												<td>$xPaket6[ket]</td>
																												<td><a href='delPaket.php?idPaket=$xPaket6[id]' onClick=\"return confirm('Yakinkan anda untuk menghapus paket ini ?')\" class='btn btn-sm btn-danger hover'><i class='icon mdi mdi-delete'></i></a></td>
																											</tr>
																									     ";
																								}
																							?>
																						</tbody>
																					</table>
																				</div>
																				<div class="modal-footer">
																					<hr class="hr5" />
																					<div class="btn-group">
																						<button type="button" class="btn modal-close btn-default hover"><i class="icon mdi mdi-power"></i> Tutup</button>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="modal-overlay"></div>
<script type="text/javascript" src="assets/js/autoNumeric.js"></script>
<script type="text/javascript">
jQuery(function($) {
    $('#adminktr_ac_25').autoNumeric('init');
	$('#admintiket_ac_25').autoNumeric('init');
});
</script>
 <script type="text/javascript">
		$(document).ready(function(){

			$(".msgPaketAC25").hide();

			$("#frmPaketAC25").submit(function(e) {
				savePaketAC25();
				e.preventDefault();
			});


			function savePaketAC25(){
				var str = $("#frmPaketAC25").serialize();
				$.ajax({
					type: "POST",
					url: "savePaket.php",
					data: str,
					success: function(pesan){
						if(pesan == "OK"){
							$(".msgPaketAC25").fadeIn("slow");
							$(".msgPaketAC25").html("<img src='assets/img/loading.gif' style='width: 48px;' /> <i>Sedang menyimpan data...</i>");
							$("#btnPaketAC25").attr("disabled",true);
							setTimeout("hideLoadingAC25()", 1800);
						}
						else{

						}
					}
				})
			}

			$(".Manual_AC_25A").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25A option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25A").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25B").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25B option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25B").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25C").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25C option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25C").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25D").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25D option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25D").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25E").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25E option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25E").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25F").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25F option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25F").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25G").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25G option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25G").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25H").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25H option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25H").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25I").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25I option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25I").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25J").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25J option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25J").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});


			$(".Manual_AC_25K").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25K option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25K").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25L").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25L option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25L").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25M").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25M option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25M").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25N").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25N option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25N").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25O").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25O option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25O").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25P").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25P option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25P").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25Q").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25Q option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25Q").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25R").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25R option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25R").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25S").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25S option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25S").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25T").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25T option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25T").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25U").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25U option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25U").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25V").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25V option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25V").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25W").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25W option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25W").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25W").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25W option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25W").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25X").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25X option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25X").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25Y").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25Y option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25Y").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25Z").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25Z option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25Z").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25A").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25A option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25A").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AA").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AA option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AA").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25AB").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AB option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AB").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25AC").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AC option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AC").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".Manual_AC_25AD").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AD option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AD").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AE").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AE option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AE").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AF").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AF option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AF").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AG").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AG option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AG").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AH").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AH option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AH").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AI").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AI option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AI").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AJ").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AJ option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AJ").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AK").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AK option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AK").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AL").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AL option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AL").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AM").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AM option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AM").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AN").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AN option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AN").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});
			$(".Manual_AC_25AO").change(function(){
				var ongkosManualAC25_JS = $(".Manual_AC_25AO option:selected").val();
				var resOngkosManAC25_JS = ongkosManualAC25_JS.split("#");
				$(".Ongkos_AC_25AO").val(resOngkosManAC25_JS[1]);
				console.log(resOngkosManAC25_JS[1]);
			});

			$(".manualMulti_AC_32").change(function(){
				var ongkosManualMulti_AC_32__TR = $(".manualMulti_AC_32 option:selected").val();
				var resOngkosManMulti_AC_32__TR = ongkosManualMulti_AC_32__TR.split("#");
				$("#temp_ongkosmulti_AC_25_TR").val(resOngkosManMulti_AC_32__TR[1]);

			});

			$("#pil_kursi_multi_ac_25").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Kursi tidak ada!",
				width: "100%"
			});

			$("#pil_kursi_multi_ac_25").chosen().change(function(){

				if($("#pil_kursi_multi_ac_25").val() == ""){
					$(markup_ac_25).remove();
				}
				else{
					arrData_ac_25  = new Array($("#pil_kursi_multi_ac_25").chosen().val());
					var valData_ac_25  = arrData_ac_25[0];
					arrKursi_ac_25 = valData_ac_25.pop();
					var jum_pen_ac_25 = arrData_ac_25[0].length
					if(jum_pen_ac_25 == 0){
						var hit_penumpang_ac_25 = 1;
					}{
						var hit_penumpang_ac_25 = 1 + jum_pen_ac_25;
					}

					var getOngkos_AC_25   = $("#temp_ongkosmulti_AC_25_TR").val();
					if($("#temp_ongkosmulti_AC_25_TR").val() == ""){
						var setOngkos_multi_ac25 = $("#hargaNormal_ac_25").val();
						var ongkosMulti_ac_25 = hit_penumpang_ac_25 * parseInt(setOngkos_multi_ac25);
						$("#txtOngkosMulti_ac_25").val(ongkosMulti_ac_25);

					}
					else{
						var setOngkos_multi_ac25 = getOngkos_AC_25;
						var ongkosMulti_ac_25 = hit_penumpang_ac_25 * parseInt(getOngkos_AC_25);
						$("#txtOngkosMulti_ac_25").val(ongkosMulti_ac_25);
					}

					$("#tmp_kursi_ac_25").val($("#pil_kursi_multi_ac_25").chosen().val());
					var markup_ac_25 = "<tr><td style='vertical-align: middle;'>Nama Penumpang </td><td style='padding-left: 5px; width: 250px;'><input name='txtNamaPenumpang_ac_25_" + arrKursi_ac_25 +"' id='txtNamaPenumpang_ac_25_"+ arrKursi_ac_25 +"' type='text' class='form-control input-xs' required></td><td style='vertical-align: bottom;'><div class='input-group'><span class='input-group-addon input-xs'>Rp</span><input name='txtOPMulti__ac_25_"+ arrKursi_ac_25 +"' id='txtOPMulti__ac_25_"+ arrKursi_ac_25 +"' style='width: 100px;' value='" + setOngkos_multi_ac25 + "' type='number' class='form-control input-xs' required></div></td></tr>";
					$(markup_ac_25).insertAfter("#buat_nama_ac_25");



				}
			});



			$("#frmMultiKursi_ac_25").submit(function(e) {
				saveMultiKursi_AC_25();
				e.preventDefault();
			});

			function saveMultiKursi_AC_25(){
				if($("#pil_kursi_multi_ac_25").chosen().val()==""){
					alert("Pilih Kursi Terlebih dahulu");
				}
				else{
					var confMsg = confirm('Yakinkan anda untuk melakukan Cetak Tiket ?');
					if(confMsg == true){
						var str = $("#frmMultiKursi_ac_25").serialize();
						$.ajax({
							type: "POST",
							url: "saveMulti_AC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>&jam_sel=<?php echo $_GET['jam_sel']; ?>&id=<?php echo $_GET['id']; ?>",
							data: str,
							success: function(msgNew){
								window.open('<?php echo $apps->setHost("printTiketMulti.php"); ?>?id='+ $("#txt_idhideMulti_ac_25").val() +'&no_kursi='+ $("#tmp_kursi_ac_25").val(),'PrintTiket', 'width=700, height=400');
								//window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>&jam_sel=<?php echo $_GET['jam_sel']; ?>&id=<?php echo $_GET['id']; ?>";
								location.reload();
							}
						})
					}
					else{
						return false;
					}
				}
			}


			/**
			$("#txtplat_AC25").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Nomor plat tidak ada!",
				width: "100%"
			});
			$("#txttujuan_ac_toilet25").chosen({
				disable_search_threshold: 10,
				no_results_text: "Oops, Tujuan tidak ada!",
				width: "100%"
			});
			**/

			$("#txtplat_AC25").change(function(){
				var nama_supir = $("#txtplat_AC25 option:selected").val();
				var has_nama   = nama_supir.split("-");
				$("#txtnmsupir_ac25").val(has_nama[1]);
				$("#txtnomor_ac25").val(has_nama[0]);
				//console.log(has_nama);
			});



			/**
			 * BUS AC
			 *
			 **/

			 // Kursi No. 1
      		$("#frmKursi1_AC25").submit(function(e) {
				saveAC_25_01();
				e.preventDefault();
			});

			function saveAC_25_01(){
				var str = $("#frmKursi1_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 2
      		$("#frmKursi2_AC25").submit(function(e) {
				saveAC_25_02();
				e.preventDefault();
			});

			function saveAC_25_02(){
				var str = $("#frmKursi2_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 3
      		$("#frmKursi3_AC25").submit(function(e) {
				saveAC_25_03();
				e.preventDefault();
			});

			function saveAC_25_03(){
				var str = $("#frmKursi3_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 4
      		$("#frmKursi4a_AC25").submit(function(e) {
				saveAC_25_04a();
				e.preventDefault();
			});

			function saveAC_25_04a(){
				var str = $("#frmKursi4a_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 5
      		$("#frmKursi5_AC25").submit(function(e) {
				saveAC_05();
				e.preventDefault();
			});

			function saveAC_05(){
				var str = $("#frmKursi5_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 6
      		$("#frmKursi6_AC25").submit(function(e) {
				saveAC_06();
				e.preventDefault();
			});

			function saveAC_06(){
				var str = $("#frmKursi6_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 7
      		$("#frmKursi7_AC25").submit(function(e) {
				saveAC_07();
				e.preventDefault();
			});

			function saveAC_07(){
				var str = $("#frmKursi7_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 8
      		$("#frmKursi8_AC25").submit(function(e) {
				saveAC_08();
				e.preventDefault();
			});

			function saveAC_08(){
				var str = $("#frmKursi8_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 9
      		$("#frmKursi9_AC25").submit(function(e) {
				saveAC_09();
				e.preventDefault();
			});

			function saveAC_09(){
				var str = $("#frmKursi9_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No.10
      		$("#frmKursi10_AC25").submit(function(e) {
				saveAC_10();
				e.preventDefault();
			});

			function saveAC_10(){
				var str = $("#frmKursi10_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 11
      		$("#frmKursi11_AC25").submit(function(e) {
				saveAC_11();
				e.preventDefault();
			});

			function saveAC_11(){
				var str = $("#frmKursi11_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 12
      		$("#frmKursi12_AC25").submit(function(e) {
				saveAC_12();
				e.preventDefault();
			});

			function saveAC_12(){
				var str = $("#frmKursi12_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}



			 // Kursi No. 13
      		$("#frmKursi13_AC25").submit(function(e) {
				saveAC_13();
				e.preventDefault();
			});

			function saveAC_13(){
				var str = $("#frmKursi13_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 14
      		$("#frmKursi14_AC25").submit(function(e) {
				saveAC_14();
				e.preventDefault();
			});

			function saveAC_14(){
				var str = $("#frmKursi14_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 15
      		$("#frmKursi15_AC25").submit(function(e) {
				saveAC_15();
				e.preventDefault();
			});

			function saveAC_15(){
				var str = $("#frmKursi15_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 16
      		$("#frmKursi16_AC25").submit(function(e) {
				saveAC_16();
				e.preventDefault();
			});

			function saveAC_16(){
				var str = $("#frmKursi16_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 17
      		$("#frmKursi17_AC25").submit(function(e) {
				saveAC_17();
				e.preventDefault();
			});

			function saveAC_17(){
				var str = $("#frmKursi17_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 18
      		$("#frmKursi18_AC25").submit(function(e) {
				saveAC_18();
				e.preventDefault();
			});

			function saveAC_18(){
				var str = $("#frmKursi18_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 19
      		$("#frmKursi19_AC25").submit(function(e) {
				saveAC_19();
				e.preventDefault();
			});

			function saveAC_19(){
				var str = $("#frmKursi19_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 20
      		$("#frmKursi20_AC25").submit(function(e) {
				saveAC_20();
				e.preventDefault();
			});

			function saveAC_20(){
				var str = $("#frmKursi20_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}

			 // Kursi No. 21
      		$("#frmKursi21_AC25").submit(function(e) {
				saveAC_21();
				e.preventDefault();
			});

			function saveAC_21(){
				var str = $("#frmKursi21_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 22
      		$("#frmKursi22_AC25").submit(function(e) {
				saveAC_22();
				e.preventDefault();
			});

			function saveAC_22(){
				var str = $("#frmKursi22_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 23
      		$("#frmKursi23_AC25").submit(function(e) {
				saveAC_23();
				e.preventDefault();
			});

			function saveAC_23(){
				var str = $("#frmKursi23_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 24
      		$("#frmKursi24_AC25").submit(function(e) {
				saveAC_24();
				e.preventDefault();
			});

			function saveAC_24(){
				var str = $("#frmKursi24_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 25
      		$("#frmKursi25_AC25").submit(function(e) {
				saveAC_25();
				e.preventDefault();
			});

			function saveAC_25(){
				var str = $("#frmKursi25_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 26
      		$("#frmKursi26_AC25").submit(function(e) {
				saveAC_26();
				e.preventDefault();
			});

			function saveAC_26(){
				var str = $("#frmKursi26_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(msg);
						if(obj.message == "exist"){
							alert("Kursi ini sudah ada penumpang!, Silahkan pilih kursi lain.\nKlik tombol Kembali ke Home lalu Refresh\ndan Jual Tiket kembali.");
						}
						else{
							window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
							window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
							window.location.reload();
						}
					}
				})
			}


			 // Kursi No. 27
      		$("#frmKursi27_AC25").submit(function(e) {
				saveAC_27();
				e.preventDefault();
			});

			function saveAC_27(){
				var str = $("#frmKursi27_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 28
      		$("#frmKursi28_AC25").submit(function(e) {
				saveAC_28();
				e.preventDefault();
			});

			function saveAC_28(){
				var str = $("#frmKursi28_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 29
      		$("#frmKursi29_AC25").submit(function(e) {
				saveAC_29();
				e.preventDefault();
			});

			function saveAC_29(){
				var str = $("#frmKursi29_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 30
      		$("#frmKursi30_AC25").submit(function(e) {
				saveAC_30();
				e.preventDefault();
			});

			function saveAC_30(){
				var str = $("#frmKursi30_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 31
      		$("#frmKursi31_AC25").submit(function(e) {
				saveAC_31();
				e.preventDefault();
			});

			function saveAC_31(){
				var str = $("#frmKursi31_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 32
      		$("#frmKursi32_AC25").submit(function(e) {
				saveAC_32();
				e.preventDefault();
			});

			function saveAC_32(){
				var str = $("#frmKursi32_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 33
      		$("#frmKursi33_AC25").submit(function(e) {
				saveAC_33();
				e.preventDefault();
			});

			function saveAC_33(){
				var str = $("#frmKursi33_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 34
      		$("#frmKursi34_AC25").submit(function(e) {
				saveAC_34();
				e.preventDefault();
			});

			function saveAC_34(){
				var str = $("#frmKursi34_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 35
      		$("#frmKursi35_AC25").submit(function(e) {
				saveAC_35();
				e.preventDefault();
			});

			function saveAC_35(){
				var str = $("#frmKursi35_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 36
      		$("#frmKursi36_AC25").submit(function(e) {
				saveAC_36();
				e.preventDefault();
			});

			function saveAC_36(){
				var str = $("#frmKursi36_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 37
      		$("#frmKursi37_AC25").submit(function(e) {
				saveAC_37();
				e.preventDefault();
			});

			function saveAC_37(){
				var str = $("#frmKursi37_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 38
      		$("#frmKursi38_AC25").submit(function(e) {
				saveAC_38();
				e.preventDefault();
			});

			function saveAC_38(){
				var str = $("#frmKursi38_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 39
      		$("#frmKursi39_AC25").submit(function(e) {
				saveAC_39();
				e.preventDefault();
			});

			function saveAC_39(){
				var str = $("#frmKursi39_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 40
      		$("#frmKursi40_AC25").submit(function(e) {
				saveAC_40();
				e.preventDefault();
			});

			function saveAC_40(){
				var str = $("#frmKursi40_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 41
      		$("#frmKursi41_AC25").submit(function(e) {
				saveAC_41();
				e.preventDefault();
			});

			function saveAC_41(){
				var str = $("#frmKursi41_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 42
      		$("#frmKursi42_AC25").submit(function(e) {
				saveAC_42();
				e.preventDefault();
			});

			function saveAC_42(){
				var str = $("#frmKursi42_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 43
      		$("#frmKursi43_AC25").submit(function(e) {
				saveAC_43();
				e.preventDefault();
			});

			function saveAC_43(){
				var str = $("#frmKursi43_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 44
      		$("#frmKursi44_AC25").submit(function(e) {
				saveAC_44();
				e.preventDefault();
			});

			function saveAC_44(){
				var str = $("#frmKursi44_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}

			 // Kursi No. 45
      		$("#frmKursi45_AC25").submit(function(e) {
				saveAC_45();
				e.preventDefault();
			});

			function saveAC_45(){
				var str = $("#frmKursi45_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 46
      		$("#frmKursi46_AC25").submit(function(e) {
				saveAC_46();
				e.preventDefault();
			});

			function saveAC_46(){
				var str = $("#frmKursi46_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=600, height=340');
					}
				})
			}


			 // Kursi No. 48
      		$("#frmKursi48_AC25").submit(function(e) {
				saveAC_48();
				e.preventDefault();
			});

			function saveAC_48(){
				var str = $("#frmKursi48_AC25").serialize();
				$.ajax({
					type: "POST",
					url: "saveAC_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>",
					data: str,
					success: function(msg){
						var obj = JSON.parse(msg);
						console.log(obj);
						window.location.reload();
						window.location.href="<?php echo $apps->setHost("apps.php"); ?>?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>";
						window.open('<?php echo $apps->setHost("printTiket.php"); ?>?id='+obj.kd_jadwal+'&no_kursi='+obj.no_bangku,'PrintTiket', 'width=650, height=400');
						if(msg == "OK"){
								//setTimeout("menyimpan()", 800);

						}
						else{

						}
					}
				})
			}

			/**
			 * Fungsi Simpan Nomor Plat, Nama Supir dan Tujuan
			 *
			 **/
			$("#frmAC_Toilet_25").submit(function(e) {
				saveKeberangkatan_AC_Toilet_25();
				e.preventDefault();
			});

			function saveKeberangkatan_AC_Toilet_25(){
				var str = $("#frmAC_Toilet_25").serialize();
				$.ajax({
					type: "POST",
					url: "saveKeberangkatan_AC_Toilet_25.php?nomor=<?php echo $_GET['nomor']; ?>&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=<?php echo $_GET['plut_num_ac_25']; ?>&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>&jam_sel=<?php echo $_GET['jam_sel']; ?>&id=<?php echo $_GET['id']; ?>",
					data: str,
					success: function(msg){
						console.log(msg);
						if(msg == "OK"){
							setTimeout("menyimpan_AC_Toilet_25()", 800);
						}
						else{

						}
					}
				})
			}



		})
			function displayMsg(){
					$.extend($.gritter.options, { position: 'bottom-right' });
					$.gritter.add({
							title: "<i class='icon mdi mdi-info'></i> Informasi",
							text: "Data berhasil disimpan",
							class_name: 'color success',
							sticky: true
					});
					return false;
			}
			function menyimpan(){
					$("#ic_simapn").hide();
					$("#txt_Simpan").text("SIMPAN...");
					setTimeout("displayMsg()", 1200);
					disableAll();
			}
			function disableAll(){
					$("#frmEkonomi :input").attr("disabled", true);
					$("#cetakSJ").attr("disabled", false);
					setTimeout("kembali()", 800);
			}

			function kembali(){
					$("#ic_simapn").show();
					$("#txt_Simpan").text("SIMPAN");
					window.location.href="apps.php?ekonomi=active";
			}



			/**
			 * Bagian AC
			 *
			 **/

			 function displayMsg_AC25(){
					$.extend($.gritter.options, { position: 'bottom-right' });
					$.gritter.add({
							title: "<i class='icon mdi mdi-info'></i> Informasi",
							text: "Data berhasil disimpan",
							class_name: 'color success',
							sticky: true
					});
					return false;
			}
			function menyimpan_AC_Toilet_25(){
					$("#ic_simapn_AC25").hide();
					$("#txt_Simpan_AC_25").text("SIMPAN...");
					//setTimeout("displayMsg_AC25()", 1200);
					disableAll_AC_Toilet_25();
			}

			function disableAll_AC_Toilet_25(){
					$("#frmAC_Toilet_25 :input").attr("disabled", true);
					$("#cetakSJAC_Toilet_25").attr("disabled", false);
					setTimeout("kembali_AC_Toilet_25()", 800);
			}

			function kembali_AC_Toilet_25(){
					$("#ic_simapn_AC25").show();
					$("#txt_Simpan_AC_25").text("SIMPAN");
					window.location.href="apps.php?mod=welcomeApp&view=ac_toilet_25&ac_toilet_25=active&menu=false&nomor=<?php echo $_GET['nomor']; ?>&&plut_num_ac_41=<?php echo $_GET['plut_num_ac_41']; ?>&plut_num_eko_41=<?php echo $_GET['plut_num_eko_41']; ?>&plut_num_ac_36=<?php echo $_GET['plut_num_ac_36']; ?>&plut_num_ac_32=<?php echo $_GET['plut_num_ac_32']; ?>&plut_num_ac_25=" + $("#txtnomor_ac25").val() + "&plut_num_ac_23=<?php echo $_GET['plut_num_ac_23']; ?>&jam_sel=<?php echo $_GET['jam_sel']; ?>&id=<?php echo $_GET['id']; ?>";
			}

			function hideLoadingAC25(){
				setTimeout("reNormalAC25()", 1800);
				$(".msgPaketAC25").html("<p style='color: green;'><i class='icon mdi mdi-check' style='font-size: 20px;'></i> <span style='margin-top: -5px;'>Paket berhasil disimpan</span></p>");
			}
			function reNormalAC25(){
				$("#btnPaketAC25").attr("disabled", false);
				$(".msgPaketAC25").html("");
				$("#txtNamaBarangAC25").val("");
				$("#txtBiayaPaketAC25").val("");
				$("#txtketBarangAC25").val("");
				$("#txtNamaBarangAC25").focus();
			}
	</script>
