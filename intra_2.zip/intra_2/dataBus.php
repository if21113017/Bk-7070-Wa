<?php
  require_once "Class/ConfigApp.php";
  $apps = new ConfigApp();
  $act = $_GET['act'];
  if($act == "addBus"){
      $judul = "TAMBAH DATA BUS";
  }
  elseif($act == "editBus"){
    $judul = "UBAH DATA BUS";
  }
  else{
    $judul = "DATA BUS";
  }
?>
<div class="col-md-12">
 <div class="panel panel-border-color panel-border-color-primary panel-contrast">
    <div class="panel-heading panel-heading-contrast"><?php echo $judul;  ?></div>
    <div class="panel-body">
      <?php
        
        switch($act){
          case "addBus":
               echo "
                        <form name='iTiket' method='POST' action='?mod=dataBus&act=addBus&api=simpan' onSubmit=\"return confirm('Anda yakin untuk menyimpan data ?')\">
                          <table class='table table-striped table-hover'>                    
                            <tr>
                              <th style='vertical-align: middle;'>
                                  Nomor Plat
                              </th>
                              <td colspan='2'>                           
                                  <input type='text' name='no_plat' id='no_plat' class='form-control input-sm' placeholder='Nomor Plat' required style='text-transform: uppercase; width: 180px;'/>
                              </td>
                            </tr>

                            <tr>
                              <th style='vertical-align: middle;'>
                                  Nama Bus
                              </th>
                              <td colspan='2'>
                                  <input type='text' name='nm_bus' class='form-control input-sm' required style='width: 350px;'/>
                              </td>
                            </tr>

                            <tr>
                              <th style='vertical-align: middle;'>
                                  Kelas Bus
                              </th>
                              <td colspan='2'>
                                  <select name='class_bus' id='class_bus' class='form-control input-sm' style='width: 200px;'>
									  ";
									  $sql_class = "SELECT * FROM _tbl_class_bus ORDER BY id ASC";
										$h_class   = mysql_query($sql_class);
										while($x_class = mysql_fetch_array($h_class)){
											echo "
													<option value='$x_class[kd_class]'>$x_class[nm_class]</option>
												 ";
										}
									  /**	
									  echo "
                                      <option value='PATAS/EKONOMI'>PATAS/EKONOMI</option>
                                      <option value='PATAS/AC'>PATAS/AC</option>
									  <option value='NON AC BIASA'>NON AC BIASA</option>";
									  **/
									echo "
                                  </select>
                              </td>
                            </tr>
                            <tr>
                              <th style='vertical-align: middle;'>
                                  Nama Supir
                              </th>
                              <td colspan='2'>
                                  <input type='text' name='nm_supir' class='form-control input-sm' required style='width: 350px;'/>
                              </td>
                            </tr>

                            <tr>
                              <th style='vertical-align: middle;'>
                                  Jumlah Kursi
                              </th>
                              <td colspan='2'>
                                  <input type='number' name='jum_kursi' class='form-control input-sm' required style='width: 90px;'/>
                              </td>
                            </tr>

                            <tr>
                              <th>&nbsp;</th>
                              <td colspan='2>
                                  <div class='btn-group'>
                                      <a href='?mod=dataBus' name='batal' class='btn btn-default'><i class='icon icon-left mdi mdi-arrow-left'></i> Kembali</a>
                                      <button type='submit' name='simpan' class='btn btn-success'><i class='icon icon-left mdi mdi-check-all'></i> Simpan Data</button>
                                  </div>
                              </td>
                            </tr>
      
                          </table>
                        </form>
                    ";
              $api = $_GET['api'];
              if($api == "simpan"){
                  $no_plat  = strtoupper($_POST['no_plat']);
                  $nm_bus   = strtoupper($_POST['nm_bus']);
                  $nm_supir = strtoupper($_POST['nm_supir']);
                  $data = array(
                      'tipe_bus'  => $_POST['class_bus'],
                      'nm_bus'    => $nm_bus,
                      'no_plat'   => $no_plat,
                      'nm_supir'  => $nm_supir,
                      'jum_kursi' => $_POST['jum_kursi']
                  );
                  $cek = "SELECT * FROM _tbl_bus WHERE no_plat='$no_plat' AND nm_supir='$nm_supir' AND nm_bus='$nm_bus'";
                  $hc  = mysql_query($cek);
                  $ada = mysql_num_rows($hc);
                  if($ada > 0){
                    echo "
                    <div role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
                      <div class='icon'><span class='mdi mdi-close-circle-o'></span></div>
                      <div class='message'>
                        <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data bus sudah ada!
                      </div>
                    </div>
                     ";
                  }
                  else{
                    $res = $apps->insertData('_tbl_bus', $data);
                    if($res == true){
                        echo "
                            <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                              <div class='icon'><span class='mdi mdi-check'></span></div>
                              <div class='message'>
                                <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data bus berhasil disimpan
                              </div>
                            </div>
                             ";
                    }
                  }
                 

              }
          break;

          case "editBus":
          $get = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_bus WHERE id='$_GET[id]'"));
          echo "
                <form name='iTiket' method='POST' action='?mod=dataBus&act=editBus&api=simpan' onSubmit=\"return confirm('Anda yakin untuk menyimpan data ?')\">
                  <table class='table table-striped table-hover'>                    
                    <tr>
                      <th style='vertical-align: middle;'>
                          Nomor Plat
                      </th>
                      <td colspan='2'>                           
                          <input type='text' value='$get[no_plat]' name='no_plat' id='no_plat' class='form-control input-sm' placeholder='Nomor Plat' required style='text-transform: uppercase; width: 180px;'/>
                      </td>
                    </tr>

                    <tr>
                      <th style='vertical-align: middle;'>
                          Nama Bus
                      </th>
                      <td colspan='2'>
                          <input type='text' name='nm_bus' value='$get[nm_bus]' class='form-control input-sm' required style='width: 350px;'/>
                      </td>
                    </tr>

                    <tr>
                      <th style='vertical-align: middle;'>
                          Kelas Bus
                      </th>
                      <td colspan='2'>
                          <select name='class_bus' id='class_bus' class='form-control input-sm' style='width: 200px;'>
                              ";
							  $sql_class = "SELECT * FROM _tbl_class_bus ORDER BY id ASC";
							  $h_class   = mysql_query($sql_class);
							  while($x_class = mysql_fetch_array($h_class)){
								if($x_class['kd_class'] == $get['tipe_bus']){
									echo "
										<option value='$x_class[kd_class]' selected>$x_class[nm_class]</option>
									";
								}
								else{
									echo "
										<option value='$x_class[kd_class]'>$x_class[nm_class]</option>
									";
								}
							  }
                              
                              echo "
                          </select>
                      </td>
                    </tr>
                    <tr>
                      <th style='vertical-align: middle;'>
                          Nama Supir
                      </th>
                      <td colspan='2'>
                          <input type='text' value='$get[nm_supir]' name='nm_supir' class='form-control input-sm' required style='width: 350px;'/>
                      </td>
                    </tr>
                    <tr>
                      <th style='vertical-align: middle;'>
                          Jumlah Kursi
                      </th>
                      <td colspan='2'>
                          <input type='number' name='jum_kursi' class='form-control input-sm' required style='width: 90px;' value='$get[jum_kursi]' />
                      </td>
                    </tr>
                    <tr>
                      <th>&nbsp;</th>
                      <td colspan='2>
                          <div class='btn-group'>
                              <input type='hidden' value='$get[id]' name='id' class='form-control input-sm' required style='width: 350px;'/>
                              <a href='?mod=dataBus' name='batal' class='btn btn-default'><i class='icon icon-left mdi mdi-arrow-left'></i> Kembali</a>
                              <button type='submit' name='simpan' class='btn btn-success'><i class='icon icon-left mdi mdi-check-all'></i> Ubah Data</button>
                          </div>
                      </td>
                    </tr>

                  </table>
                </form>
            ";
            $api = $_GET['api'];
            if($api == "simpan"){
                $no_plat  = strtoupper($_POST['no_plat']);
                $nm_bus   = strtoupper($_POST['nm_bus']);
                $nm_supir = strtoupper($_POST['nm_supir']);

                $sql = "UPDATE _tbl_bus SET tipe_bus='".$_POST['class_bus']."', nm_bus='$nm_bus', no_plat='$no_plat', nm_supir='$nm_supir', jum_kursi='$_POST[jum_kursi]' WHERE id='$_POST[id]'";
                
                $res = mysql_query($sql);
                if($res == true){
                    echo "
                        <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-check'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data bus berhasil diubah
                          </div>
                        </div>
                    ";
                }
                else{
                    echo "
                        <div role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-close-circle-o'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data bus tidak bisa ubah!
                          </div>
                        </div>
                    ";
                }
            }
          break;

          default:
            
            if($_GET['msg'] == "sukses"){
                echo "
                    <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                      <div class='icon'><span class='mdi mdi-check'></span></div>
                      <div class='message'>
                        <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data bus berhasil dihapus
                      </div>
                    </div>
                ";
            }
            echo "
				<div class='btn-group pull-right' style='margin-bottom: 5px;'>
                      <button type='button' class='btn btn-default' onClick='window.location.reload();'><i class='icon mdi mdi-refresh'></i> Refresh</button>";
				if($_SESSION['level'] == "3"){
					 echo "
                                                <a href='?mod=dataBus&act=addBus' class='btn btn-success'><i class='icon mdi mdi-plus-circle-o'></i> Tambah Bus</a>
                                                ";
				}
				else{
					echo "					 
						<a href='?mod=dataBus&act=addBus' class='btn btn-success'><i class='icon mdi mdi-plus-circle-o'></i> Tambah Bus</a>
						";
				}
				echo "
                </div>
				<hr class='style15' style='margin-top: 40px;' />
                <table id='table1' class='table table-striped table-hover' style='border-top: 1px solid #DDD;'>
                  <thead>
                    <tr>
                      <th style='width:5%;'>No.</th>
                      <th style='width:10%;'>No. Plat</th>
                      <th style='width:26%;'>Nama Bus</th>
                      <th style='width:20%;'>Tipe Bus</th>
                      <th style='width:20%;'>Nama Supir</th>
                      <th style='width:9%;'>Jum. Kursi</th>
                      <th style='width:10%;'>Aksi</th>
                    </tr>
                  </thead>
                <tbody>
                 ";
                $q  = "SELECT * FROM _tbl_bus ORDER BY nm_bus, nm_supir ASC";
                $h  = mysql_query($q);
                $no = 0;
                while($r = mysql_fetch_array($h)){
				  $get_class = mysql_fetch_array(mysql_query("SELECT nm_class FROM _tbl_class_bus WHERE kd_class='$r[tipe_bus]'"));
                  $no++;
                  echo "
                        <tr>
                          <td>$no.</td>
                          <td>$r[no_plat]</td>
                          <td>".strtoupper($r['nm_bus'])."</td>
                          <td>$get_class[nm_class]</td>
                          <td>$r[nm_supir]</td>
                          <td>$r[jum_kursi]</td>
                          <td>";
						  if($_SESSION['level'] == "3"){
							  echo "<div class='btn-group'>
									 <a href='?mod=dataBus&act=editBus&id=$r[id]' class='btn btn-sm btn-primary hover'><i class='mdi mdi-comment-edit'></i></a>
									</div> 
                              ";
						  }
						  else{
							  echo "
                              <div class='btn-group'>
                                <a href='?mod=dataBus&act=editBus&id=$r[id]' class='btn btn-sm btn-primary hover'><i class='mdi mdi-comment-edit'></i></a>
                                <a href='deltBus.php?id=$r[id]' onClick=\"return confirm('Yakinkan anda untuk menghapus data ini ?')\" class='btn btn-sm btn-danger hover'><i class='mdi mdi-delete'></i></a>
                              </div>";
						  }
						  echo "
                          </td>
                        </tr>
                       ";
                }
			echo "</table>";
        }
      ?>
      
    </div>
 </div>
</div>
