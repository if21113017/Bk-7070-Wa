<?php
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();
    $id  = $_GET['id'];
    $sql = "DELETE FROM _tbl_user WHERE user_id='$id'";
    $res = mysql_query($sql);
    if($res == true){
        ?>
            <script type="text/javascript">
                window.location.href="apps.php?mod=ManUser&menu=false"
            </script>
        <?php        
    }
    else{        
        ?>
            <script type="text/javascript">
                window.location.href="apps.php?mod=ManUser&menu=false"
            </script>
        <?php
    }
?>