<script src="assets/lib/jquery/jquery.min.js" type="text/javascript"></script>
<?php
  date_timezone_set("Asia/Jakarta");
  require_once "Class/ConfigApp.php";
  require_once "Class/ClassIndoTgl.php";
  $apps = new ConfigApp();
  $act = $_GET['act'];
  if($act == "addTiket"){
      $judul = "TAMBAH JADWAL KEBERANGKATAN";
  }
  elseif($act == "editTiket"){
    $judul = "UBAH JADWAL KEBERANGKATAN";
  }
  else{
    $judul = "DATA KEBERANGKATAN";
  }
  //$tgl_sekarang = date("Y-m-d");
  $tgl_sekarang="2019-02-09";
  echo $tgl_sekarang;
?>
<style type="text/css">
  .notifErr{
    padding: 5px;
    font-weight: bold;
    font-style: italic;
    color: red;
    padding-top: 3px;
    border: 1px solid #CCC;
  }
</style>
<div class="col-md-12" style="margin-top: 20px;">
 <div class="panel panel-border-color panel-border-color-primary panel-contrast">
    <div class="panel-heading panel-heading-contrast"><?php echo $judul;  ?></div>
    <div class="panel-body">
      <?php

        switch($act){
          case "addTiket":
               echo "
                        <form name='iTiket' id='iTiket' method='POST' onSubmit=\"return confirm('Anda yakin untuk menyimpan data ?')\">
                          <table class='table table-striped table-hover'>
                            <tr>
                              <th style='vertical-align: middle; width: 140px;'>
                                  Jam Keberangkatan
                              </th>
                              <td colspan='2'>
                              <input type='hidden' name='txtTgl' value='$tgl_sekarang' />
                              <div class='input-group'>
                              <select class='form-control input-xs' style='width: 160px; text-transform: uppercase; font-weight: bold;' required name='piljam' id='piljam'>";

                                    $qjam32  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
                                    $hjam32  = mysql_query($qjam32);
                                    while($rjam32 = mysql_fetch_array($hjam32)){
                                      if($rjam32['jam'] == $j_berangkat_AC_Toilet_32){
                                        echo "
                                            <option value='$rjam32[jam]' selected>$rjam32[jam] WIB</option>
                                          ";
                                      }
                                      else{
                                        echo "
                                            <option value='$rjam32[jam]'>$rjam32[jam] WIB</option>
                                          ";
                                      }

                                    }
                                echo "
                                </select>
                                <input type='text' name='tgl_berangkat' readonly  value='".tgl_indo($tgl_sekarang)."' class='form-control input-xs' style='width: 190px; text-transform: uppercase; font-weight: bold;' />
                                </div>
                              </td>
                            </tr>

                            <tr>
                              <th style='width: 170px; vertical-align: middle;'>Tujuan</th>
                              <td>
                                <select class='form-control input-sm' required name='tuj_book' id='tuj_book' style='width: 100%;'>
                                <option value=''>- Pilih Tujuan -</option>
                                ";
                                $tuj = "SELECT DISTINCT id, tujuan, class_bus, harga FROM _tbl_harga_tiket GROUP BY tujuan ASC";
                                $ht  = mysql_query($tuj);
                                while($x = mysql_fetch_array($ht)){
                                    echo "
                                      <option value='$x[id]#$x[tujuan]'>$x[tujuan]</option>
                                      ";
                                }
                                echo "
                                </select>
                              </td>
                            </tr>
                            <tr>
                              <th style='width: 170px; vertical-align: middle;'>Pilih Kelas Bus</th>
                              <td>
                                <select name='class_bus' id='class_bus' class='form-control input-sm' style='width: 200px;'>
                                  <option value=''>- Pilih Kelas Bus -</option>";
                                  $sql_class = "SELECT * FROM _tbl_class_bus ORDER BY id ASC";
                                  $h_class   = mysql_query($sql_class);
                                  while($x_class = mysql_fetch_array($h_class)){
                                    echo "
                                        <option value='$x_class[kd_class]'>$x_class[nm_class]</option>
                                      ";
                                  }
                                  echo "
                                </select>
                              </td>
                            </tr>
                            <tr>
                              <th style='width: 170px; vertical-align: middle;'>Pilih Plat Bus</th>
                              <td>
                                <div class='input-group'>
                                  <select class='form-control input-xs' style='width: 160px;' name='pil_bus_' id='pil_bus_'>
                                    <option value=''>- Pilih Plat Bus -</option>
                                  </select>
                                  <input type='text' name='txtsupir' id='txtsupir' class='form-control input-xs' style='width: 350px; font-weight: bold;' placeholder='Pilih Plat Bus Untuk Memilih Supir...' required />
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <th style='width: 170px; vertical-align: middle;'>Ongkos</th>
                              <td>
                                <input type='text' name='txtongkos' id='txtongkos' class='form-control input-xs' style='width: 250px; font-weight: bold;' />
                                <input type='hidden' name='txtongkos_tmp' id='txtongkos_tmp' class='form-control input-xs' style='width: 250px; font-weight: bold;' />
                                <div class='notifErr'>
                                   Tidak ada ongkos untuk tujuan <span id='xtujuan'></span>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <th>&nbsp;</th>
                              <td colspan='2>
                                  <div class='btn-group'>
                                      <a href='?mod=jualTiketV2&menu=false' name='batal' class='btn btn-default'><i class='icon icon-left mdi mdi-arrow-left'></i> Kembali</a>
                                      <button type='submit' name='simpan' id='simpan' class='btn btn-success'><i class='icon icon-left mdi mdi-check-all'></i> Simpan Jadwal Keberangkatan</button>
                                  </div>
                              </td>
                            </tr>
                          </table>
                        </form>
                        <div id='msgOK' role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-check'></span></div>
                          <div class='message'>
                              <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jadwal keberangkatan berhasil disimpan
                          </div>
                        </div>

                        <div id='msgErr' role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-info'></span></div>
                          <div class='message'>
                              <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Jadwal keberangkatan sudah ada
                          </div>
                        </div>
                    ";
              $api = $_GET['api'];
              if($api == "simpan"){
                  $jam  = $apps->escapeString($_POST['jam']);
                  $ket  = $apps->escapeString($_POST['ket']);
                  $data = array(
                      'jam'  => $jam,
                      'ket'  => $ket
                  );
                  $cek = "SELECT * FROM _tbl_jam WHERE jam='$jam'";
                  $hc  = mysql_query($cek);
                  $ada = mysql_num_rows($hc);
                  if($ada > 0){
                    echo "
                    <div role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
                      <div class='icon'><span class='mdi mdi-close-circle-o'></span></div>
                      <div class='message'>
                        <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan sudah ada!
                      </div>
                    </div>
                     ";
                  }
                  else{
                    $res = $apps->insertData('_tbl_jam', $data);
                    if($res == true){
                        echo "
                            <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                              <div class='icon'><span class='mdi mdi-check'></span></div>
                              <div class='message'>
                                <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan berhasil disimpan
                              </div>
                            </div>
                             ";
                    }
                  }


              }
          break;

          case "editTiket":
          $get = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_jadwal WHERE id='$_GET[id]'"));
          echo "
          <form name='eTiket' id='eTiket' method='POST' onSubmit=\"return confirm('Anda yakin untuk menyimpan data ?')\">
            <table class='table table-striped table-hover'>
              <tr>
                <th style='vertical-align: middle; width: 140px;'>
                    Jam Keberangkatan
                </th>
                <td colspan='2'>
                <input type='hidden' name='txtTgl' value='$tgl_sekarang' />
                <div class='input-group'>
                <select class='form-control input-xs' style='width: 160px; text-transform: uppercase; font-weight: bold;' required name='piljam' id='piljam'>";

                      $qjam32  = "SELECT * FROM _tbl_jam ORDER BY jam ASC";
                      $hjam32  = mysql_query($qjam32);
                      while($rjam32 = mysql_fetch_array($hjam32)){
                        if($rjam32['jam'] == $get['jam_berangkat']){
                          echo "
                              <option value='$rjam32[jam]' selected>$rjam32[jam] WIB</option>
                            ";
                        }
                        else{
                          echo "
                              <option value='$rjam32[jam]'>$rjam32[jam] WIB</option>
                            ";
                        }

                      }
                  echo "
                  </select>
                  <input type='text' name='tgl_berangkat' readonly  value='".tgl_indo($tgl_sekarang)."' class='form-control input-xs' style='width: 190px; text-transform: uppercase; font-weight: bold;' />
                  </div>
                </td>
              </tr>

              <tr>
                <th style='width: 170px; vertical-align: middle;'>Tujuan</th>
                <td>
                  <select class='form-control input-sm' required name='tuj_book' id='tuj_book' style='width: 100%;'>
                  <option value=''>- Pilih Tujuan -</option>
                  ";
                  $tuj = "SELECT DISTINCT id, tujuan, class_bus, harga FROM _tbl_harga_tiket GROUP BY tujuan ASC";
                  $ht  = mysql_query($tuj);
                  $dari_ke = $get['dari']." - ".$get['tujuan'];
                  while($x = mysql_fetch_array($ht)){
                      if($dari_ke == $x['tujuan']){
                        echo "
                          <option value='$x[id]#$x[tujuan]' selected>$x[tujuan]</option>
                          ";
                      }
                      else{
                        echo "
                          <option value='$x[id]#$x[tujuan]'>$x[tujuan]</option>
                          ";
                      }

                  }
                  echo "
                  </select>
                </td>
              </tr>
              <tr>
                <th style='width: 170px; vertical-align: middle;'>Pilih Kelas Bus</th>
                <td>
                  <select name='class_bus' id='class_bus' class='form-control input-sm' style='width: 200px;'>
                    <option value=''>- Pilih Kelas Bus -</option>";
                    $sql_class = "SELECT * FROM _tbl_class_bus ORDER BY id ASC";
                    $h_class   = mysql_query($sql_class);
                    while($x_class = mysql_fetch_array($h_class)){
                      if($get['kd_bus']==$x_class['kd_class']){
                        echo "
                            <option value='$x_class[kd_class]' selected>$x_class[nm_class]</option>
                          ";
                      }
                      else{
                        echo "
                            <option value='$x_class[kd_class]'>$x_class[nm_class]</option>
                          ";
                      }
                    }
                    echo "
                  </select>
                </td>
              </tr>
              <tr>
                <th style='width: 170px; vertical-align: middle;'>Pilih Plat Bus</th>
                <td>
                  <div class='input-group'>
                    <select class='form-control input-xs' style='width: 160px;' name='pil_bus_' id='pil_bus_'>
                      <option value=''>- Pilih Plat Bus -</option>
                      ";
                      if($get['no_plat']!=""){
                        echo "<option value='$get[no_plat]' selected>$get[no_plat]</option>";
                      }
                      else{

                      }
                      echo "
                    </select>
                    <input type='text' name='txtsupir' id='txtsupir' value='$get[nm_supir]' class='form-control input-xs' style='width: 350px; font-weight: bold;' placeholder='Pilih Plat Bus Untuk Memilih Supir...' required />
                  </div>
                </td>
              </tr>
              <tr>
                <th style='width: 170px; vertical-align: middle;'>Ongkos</th>
                <td>";
                $hg = explode(".", $get['harga_tiket']);
                $harganya = $hg[0];
                echo "
                  <input type='text' name='txtongkos' id='txtongkos' class='form-control input-xs' style='width: 250px; font-weight: bold;' value='$get[harga_tiket]' />
                  <input type='hidden' name='txtongkos_tmp' id='txtongkos_tmp' class='form-control input-xs' style='width: 250px; font-weight: bold;' value='$harganya' />
                  <div class='notifErr'>
                     Tidak ada ongkos untuk tujuan <span id='xtujuan'></span>
                  </div>
                </td>
              </tr>
              <tr>
                <th>&nbsp;</th>
                <td colspan='2>
                    <div class='btn-group'>
                        <a href='?mod=jualTiketV2&menu=false' name='batal' class='btn btn-default'><i class='icon icon-left mdi mdi-arrow-left'></i> Kembali</a>
                        <button type='submit' name='simpan' id='simpan_' class='btn btn-success'><i class='icon icon-left mdi mdi-check-all'></i> Simpan Jadwal Keberangkatan</button>
                    </div>
                    <input type='hidden' name='idEdit' value='$get[id]' />
                </td>
              </tr>
            </table>
          </form>
          <div id='msgOK' role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
            <div class='icon'><span class='mdi mdi-check'></span></div>
            <div class='message'>
                <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jadwal keberangkatan berhasil disimpan
            </div>
          </div>

          <div id='msgErr' role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
            <div class='icon'><span class='mdi mdi-info'></span></div>
            <div class='message'>
                <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Jadwal keberangkatan sudah ada
            </div>
          </div>
            ";
            $api = $_GET['api'];
            if($api == "simpan"){
                $jam  = $apps->escapeString($_POST['jam']);
                $ket  = $apps->escapeString($_POST['ket']);

                $sql = "UPDATE _tbl_jam SET jam='".$jam."', ket='$ket' WHERE id='$_POST[id]'";

                $res = mysql_query($sql);
                if($res == true){
                    echo "
                        <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-check'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan berhasil diubah
                          </div>
                        </div>
                    ";
                }
                else{
                    echo "
                        <div role='alert' class='alert alert-danger alert-icon alert-icon-border alert-dismissible'>
                          <div class='icon'><span class='mdi mdi-close-circle-o'></span></div>
                          <div class='message'>
                            <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan tidak bisa ubah!
                          </div>
                        </div>
                    ";
                }
            }
          break;

          default:

            if($_GET['msg'] == "sukses"){
                echo "
                    <div role='alert' class='alert alert-success alert-icon alert-icon-border alert-dismissible'>
                      <div class='icon'><span class='mdi mdi-check'></span></div>
                      <div class='message'>
                        <button type='button' data-dismiss='alert' aria-label='Close' class='close'><span aria-hidden='true' class='mdi mdi-close'></span></button>Data jam keberangkatan berhasil dihapus
                      </div>
                    </div>
                ";
            }
            echo "<div class='btn-group pull-right' style='margin-bottom: 5px;'>
                      <button type='button' class='btn btn-danger' onClick=\"window.location.href='apps.php'\"><i class='icon mdi mdi-home'></i> Kembali Ke Home</button>";
					  if($_SESSION['level'] == "3"){
                  echo "
                        <a href='?mod=jualTiketV2&act=addTiket&menu=false' class='btn btn-success'><i class='icon mdi mdi-plus-circle-o'></i> Tambah Keberangkatan</a>";

					  }
					  else{
		  echo "
			<a href='?mod=jualTiketV2&act=addTiket&menu=false' class='btn btn-success'><i class='icon mdi mdi-plus-circle-o'></i> Tambah Keberangkatan</a>";
					  }
					echo "
                  </div>

				  ";

            echo "
                <table id='table1_edit' class='table table-striped table-hover' style='border-top: 1px solid #DDD;'>
                  <thead>
                    <tr>
                      <th style='width:5%;'>No.</th>
                      <th style='width:12%;'>Tgl/Jam Berangkat</th>
                      <th style='width:10%;'>Plat Bus</th>
                      <th style='width:26%;'>Tujuan</th>
                      <th style='width:20%;'>Nama Supir</th>
                      <th style='width:18%;'>Kelas Bus</th>
                      <th style='width:19%; text-align: right'>Aksi</th>
                    </tr>
                  </thead>
                <tbody>
                 ";
                $q  = "SELECT * FROM _tbl_jadwal WHERE tgl_berangkat='$tgl_sekarang' ORDER BY jam_berangkat DESC";
                $h  = mysql_query($q);
                $no = 0;
                while($r = mysql_fetch_array($h)){
                  $no++;
                  $getClass = mysql_fetch_array(mysql_query("SELECT `mod`, nm_class FROM _tbl_class_bus WHERE kd_class='$r[kd_bus]'"));
                  $mod_tmp = explode(".", $getClass['mod']);
                  $module = $mod_tmp[0];
                  $getSJ = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_hissj WHERE kd_jadwal='$r[id]'"));
                  echo "
                        <tr>
                          <td>$no.</td>
                          <td>
                              $r[jam_berangkat] WIB<br />
                              ".tgl_indo($r['tgl_berangkat'])."
                          </td>
                          <td>$r[no_plat]</td>
                          <td>$r[dari] - $r[tujuan]</td>
                          <td>$r[nm_supir]</td>
                          <td>$getClass[nm_class]</td>
                          <td>";
							if($_SESSION['level'] == "10"){
							  echo " <div class='btn-group'>
										<a href='?mod=dataJam&act=editJam&id=$r[id]' class='btn btn-sm btn-primary hover'><i class='mdi mdi-comment-edit'></i></a>
									 </div>
                            ";
							}
							else{
                if($r['isCetakSJ'] == "1"){
                  $link = "href='#' id='printSJ_$no'";
                }
                else{
                  $link = "href='#' data-modal='md-stickyUpIsiKomis_$no' class='md-trigger'";
                }
                echo "
                      <div class='dropdown' style='float: right;'>
                        <button class='btn btn-sm btn-success dropdown-toggle' type='button' id='menu1' data-toggle='dropdown'>
                        <span class='caret'></span></button>
                        <ul class='dropdown-menu dropdown-menu-right' role='menu' aria-labelledby='menu1'>
                          <li role='presentation'><a role='menuitem' tabindex='-1' style='color: blue;' href='?mod=$module&id=$r[id]&menu=false'><i class='glyphicon glyphicon-share'></i> JUAL TIKET</a></li>
                          <li role='presentation'><a role='menuitem' tabindex='-1' $link><i class='glyphicon glyphicon-print'></i> CETAK SURAT JALAN</a></li>
                          <li role='presentation' class='divider'></li>
                          <li role='presentation'><a href='?mod=jualTiketV2&act=editTiket&menu=false&id=$r[id]' role='menuitem' tabindex='-1' style='color: green;' href='#'><i class='glyphicon glyphicon-edit'></i> UBAH JADWAL KEBERANGKATAN</a></li>
                          <li role='presentation'><a role='menuitem' tabindex='-1' href='#'  data-modal='md-sticky_$no' class='md-trigger' style='color: red;'><i class='glyphicon glyphicon-trash'></i> HAPUS</a></li>
                        </ul>
                      </div>


                      <div id='md-sticky_$no' class='modal-container colored-header colored-header-danger modal-effect-8'>
                        <div class='modal-content' style='border-radius: 5px;'>
                          <div class='modal-header' style='padding: 10px;'>
                          <a href='#' data-dismiss='modal' aria-hidden='true' class='close modal-close'><span class='mdi mdi-close'></span></a>
                          <h3 class='modal-title'>Hapus Jadwal Keberangkatan</h3>
                          </div>
                          <div class='modal-body'>
                              <p>
                                Yakinkah anda untuk menghapus jadwal keberangkatan berikut ini:
                                <br />
                                <div style='padding: 10px; border: 1px solid #CCC; background-color: #ffcdd2'>
                                Tanggal Berangkat: ".tgl_indo($r['tgl_berangkat'])."<br />
                                Jam Berangkat: $r[jam_berangkat] WIB<br />
                                Tujuan: $r[dari] - $r[tujuan]
                                </div>
                              </p>
                              <hr class='style15' />
                              <div class='btn-group pull-right' style='margin-bottom: 15px;'>
                                <a href='delJadwal.php?id=$r[id]' id='new_out' class='btn btn-danger hover'><i class='glyphicon glyphicon-trash'></i> HAPUS</a>
                                <button data-dismiss='modal' type='button' class='modal-close btn btn-default hover'><i class='icon icon-left mdi mdi-refresh'></i> BATAL</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class='modal-overlay'></div>


                      <div id='md-stickyUpIsiKomis_$no' class='modal-container colored-header colored-header-primary modal-effect-11'>
                        <div class='modal-content' style='border-radius: 5px;'>
                           <div class='modal-header' style='padding: 10px;'>
                            <a href='#' data-dismiss='modal' aria-hidden='true' class='close modal-close'><span class='mdi mdi-close'></span></a>
                            <h3 class='modal-title'>Input Komisi</h3>
                          </div>
                          <div class='modal-body'>
                            <table class='table table-striped'>
                              <tr>
                                <th style='width: 19%; vertical-align: middle;'>Admin Kantor</th>
                                <td>
                                  <div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input type='text' value='$getSJ[adm_kantor]' name='adminktr_ac_41' id='adminktr_$no' data-a-sep='.' data-a-dec=',' class='form-control input-xs' style='width: 180px;' /></div></td>
                              </tr>
                              <tr>
                                <th style='width: 19%; vertical-align: middle;'>Tiket</th>
                                <td><div class='input-group'><span class='input-group-addon input-xs'><b>Rp.</b></span><input type='text' value='$getSJ[adm_tiket]' name='admintiket_ac_41' id='admintiket_$no' data-a-sep='.' data-a-dec=',' class='form-control input-xs' style='width: 180px;'/></div></td>
                              </tr>
                            </table>
                            <hr class='style15' />
                            <div class='pull-right' style='margin-bottom: 15px;'>
                              <button type='button' id='printSJ_$no' class='btn btn-success hover'>
                                <i class='icon icon-left mdi mdi-print'></i> CETAK SURAT JALAN
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class='modal-overlay'></div>
                             ";
                      ?>
                      <script type="text/javascript" src="assets/js/autoNumeric.js"></script>
                      <script type="text/javascript">
                      jQuery(function($) {
                          $('#adminktr_<?php echo $no; ?>').autoNumeric('init');
                          $('#admintiket_<?php echo $no; ?>').autoNumeric('init');
                      });
                      </script>
                        <script type="text/javascript">
                          $(document).ready(function(){
                              $("#printSJ_<?php echo $no; ?>").click(function(){
                                if($('#adminktr_<?php echo $no; ?>').val() == ""){
                                  alert("Silakan isi komisi Admin Kantor!");
                                  $('#adminktr_<?php echo $no; ?>').focus();
                                }
                                else if($('#admintiket_<?php echo $no; ?>').val() == ""){
                                  alert("Silakan isi komisi Tiket");
                                  $('#admintiket_<?php echo $no; ?>').focus();
                                }
                                else{
                                  printSJ();
                                }
                              });

                              function printSJ(){
                                window.open('<?php echo $apps->setHost("printSJ.php"); ?>?id='+<?php echo $r['id']; ?>+'&admktr='+ $("#adminktr_<?php echo $no; ?>").val() +'&admtkt='+ $("#admintiket_<?php echo $no; ?>").val() + "&no_save=true",'CetakSuratJalan', 'width=800, height=780');
                              }
                          });
                        </script>
                      <?php
							}
							echo "
                          </td>
                        </tr>
                       ";
                }
        }
      ?>

    </div>
 </div>
</div>
<script type="text/javascript" src="assets/js/autoNumeric.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#msgOK").hide();
    $("#simpan").attr("disabled", true);
    $("#msgErr").hide();
    $(".notifErr").hide();
    $("#pil_bus_").change(function(){
        var no_bus = $("#pil_bus_").val();
        var has_nama   = no_bus.split("#");
				$("#txtsupir").val(has_nama[1]);
        $("#txtsupir").attr("readonly", true);

    });

    $("#class_bus").change(function(){
        var tipe   = $("#class_bus").val();
        var tujuan = $("#tuj_book").val();
				$.ajax({
					type: "POST",
					url: "getPlat.php",
					data: "nomor=" + tipe + "&tujuan=" + tujuan,
					success: function(msg){
            $("#pil_bus_").focus();
            $("#pil_bus_").html(msg);
            var no_bus = $("#pil_bus_").val();
            var has_nama   = no_bus.split("#");
            var tmpOngkos = has_nama[2];
            var setOngkos = tmpOngkos.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
            $("#txtongkos").val(setOngkos.replace(",", "."));
            $("#txtongkos_tmp").val(tmpOngkos);
            $("#txtongkos").attr("readonly", true);
            if($("#txtongkos").val() == ""){
              $("#simpan").attr("disabled", true);
              var xtujuan = $("#tuj_book").val();
              var pis = xtujuan.split("#");
              $(".notifErr").show();
              $("#xtujuan").html(pis[1]);
            }
            else{
              $("#simpan").attr("disabled", false);
              $(".notifErr").hide();
            }
					}
				})
    });


    $("#iTiket").submit(function(e) {
				saveJadwal();
				e.preventDefault();
		});

    function saveJadwal(){
      var str = $("#iTiket").serialize();
				$.ajax({
					type: "POST",
					url: "saveTiketV2.php",
					data: str,
					success: function(msg){
            console.log(msg);
            var obj = JSON.parse(msg);
            if(obj.response == "OK"){
              $("#msgErr").hide();
              $("#msgOK").show();
              setTimeout("showMgs()", 800);
            }
            else{
              $("#msgErr").show();
              $("#msgOK").hide();
            }
					}
				})
    }

    $("#eTiket").submit(function(e) {
				editJadwal();
				e.preventDefault();
		});

    function editJadwal(){
      var str = $("#eTiket").serialize();
				$.ajax({
					type: "POST",
					url: "editTiketV2.php",
					data: str,
					success: function(msg){
            console.log(msg);
            var obj = JSON.parse(msg);
            if(obj.response == "OK"){
              $("#msgErr").hide();
              $("#msgOK").show();
              setTimeout("showMgs()", 2000);
            }
            else{
              $("#msgErr").show();
              $("#msgOK").hide();
            }
					}
				})
    }



  });

  function showMgs(){
    $("#msgOK").hide();
    setTimeout("reloadPage()", 900);
  }

  function reloadPage(){
      window.location.href="apps.php?mod=jualTiketV2&menu=false";
  }

</script>
