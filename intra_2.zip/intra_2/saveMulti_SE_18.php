<?php
    session_start();
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/configApp.php";
    $apps = new configApp();

    $tmp_kursi = explode(',', $_POST['tmp_kursi_se_18']);
    $jum_kursi = count($tmp_kursi);

    $id_jadwal      = $_POST['txt_idhideMulti_se_18'];
    $harga_tiket    = $_POST['hiddenOngkos_se_18'];
    $tot_tiket      = $_POST['txtOngkosMulti_se_18'];
    $date_modif     = date("Y-m-d");
    $alamat         = $_POST['txtAlamatMulti_se_18'];
    $txtNoHp        = $_POST['txtNoHpMulti_se_18'];
	$tiketNormal	= $_POST['hargaNormal_se_18'];
	$ket			= $_POST['txtket_se_18'];
	
	$txttujuanManual = $_POST['txttujuanManualMulti_AC_18'];
		
	$pisah_temp      = explode(" - ", $txttujuanManual);
	$tujuan_temp     = $pisah_temp[1];
	$dari_temp       = $pisah_temp[0];
	
	$pisah_tujuan    = explode("#", $tujuan_temp);
	$tujuan_manual   = $pisah_tujuan[0];
	
	if($txttujuanManual == "0"){
		$PTujuan = $_POST['txt_tujuanhideMulti_se_18'];
		$dari_p   = $_POST['txt_darinhideMulti_se_18'];
	}
	else{
		$PTujuan = $tujuan_manual;
		$dari_p   = $dari_temp;
	}
	
	
	$n = 0;
    for($i=0; $i<=$jum_kursi; $i++){
		$n++;
        $nm_penumpang    = strtoupper($_POST['txtNamaPenumpang_se_18_'.$tmp_kursi[$i]]);
        $kursi_penumpang = $tmp_kursi[$i];
        $HargaTiketPen	= $_POST['txtOPMulti__se_18_'.$kursi_penumpang];
		
        if($nm_penumpang == ""){

        }
        else{
				
			if($HargaTiketPen == $tiketNormal || $HargaTiketPen == NULL){
				$remark  = "-";				
			}
			else{
				$remark  = $ket;				
            }
			$data = array(
					'kd_jadwal'     => $id_jadwal,
					'no_bangku'     => $kursi_penumpang,
					'nm_penumpang'  => $nm_penumpang,
					'alamat'        => $alamat,
					'no_hp'         => $txtNoHp,
					'dari'			=> $dari_p,
					'tujuan'		=> $PTujuan,
					'harga_tiket'   => $HargaTiketPen,
					'user_modify'   => $_SESSION['namauser'],
					'date_modify'   => $date_modif,
					'remark'		=> $remark
			);
            $apps->insertData('_tbl_tiket', $data);
            var_dump($data);           
			
            $tmp_kursi_up = "UPDATE _tbm_tempkursi SET sts_kursi='1' WHERE id_jadwal='$id_jadwal' AND kursi_num='$kursi_penumpang'";
            mysql_query($tmp_kursi_up);
			mysql_query("UPDATE _tbl_uri_temp SET uri=\"".$apps->urlGet()."\" WHERE id='1'");
        }        
    }