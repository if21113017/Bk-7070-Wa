<?php
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();
    $plat          = strtoupper($_POST['txtplat_AC_41']);
    $supir         = $_POST['txtnmsupir_ac41'];
    $tgl_berangkat = explode("/", $_POST['txttgl_ac_41']);
    $tahun         = $tgl_berangkat[2];
    $bulan         = $tgl_berangkat[1];
    $tgl           = $tgl_berangkat[0];
    $concat_tgl    = $tahun."-".$bulan."-".$tgl;
    $jam_berangkat = $_POST['txtjam_ac41'];    
    $tujuan_temp   = $_POST['txttujuan_ac41'];

    $tmp_jum_kursi = $_POST['tmp_jum_kursi_ac41'];

    $from_to       = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_harga_tiket WHERE id='$tujuan_temp'"));
    $pecah_from_to = explode("-", $from_to['tujuan']);

    $dari          = strtoupper($pecah_from_to[0]);
    $tujuan        = strtoupper($pecah_from_to[1]);
	$nomor         = explode("-", $plat);
    $data_new = array(
                'id_tujuan'     => $from_to['id'],
                'kd_bus'        => "AC",
                'no_plat'       => strtoupper($nomor[0]),
                'nm_supir'      => strtoupper($supir),
                'jam_berangkat' => $jam_berangkat,
                'tgl_berangkat' => $concat_tgl,
                'dari'          => $dari,
                'tujuan'        => $tujuan,
                'harga_tiket'   => $from_to['harga'],
                'status'        => '0'
            );

    $sql   = $apps->insertData('_tbl_jadwal', $data_new);    
	$id_tm = mysql_insert_id();
    for($x=1; $x<=$tmp_jum_kursi; $x++){
        $tmp_data = "INSERT INTO 
                        _tbm_tempkursi 
                     SET 
                        id_jadwal='$id_tm',
                        no_plat='".strtoupper($nomor[0])."', 
                        kursi_num='".$x."', 
                        tgl_berangkat='".$concat_tgl."',
                        jam_berangkat='$jam_berangkat',
                        sts_kursi='0'";
       mysql_query($tmp_data);
    }
	mysql_query("UPDATE _tbl_uri_temp SET uri=\"".$apps->urlGet()."\" WHERE id='1'");
	//var_dump($data_new);
    echo "OK";

