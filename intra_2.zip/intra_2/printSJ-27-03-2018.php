<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cetak Surat Jalan</title>
    <link rel="stylesheet" href="assets/css/invTiket.css" />
    <style type="text/css">
        body{
            font-family: 'Roboto', Arial, sans-serif;           
        }
        .box_tiket2{
            padding: 0px;
            border: 0px solid #000; 
			margin: 3px;
        }
        h3{
            text-align: center;
			text-decoration: underline;            
			margin-bottom: 0px;
        }
        .tabel_atas{
			margin-top: 10px;
            font-size: 7px;            
            border-bottom: 0px solid #000;            
            margin-right: 0px;			
            margin-bottom: -8px;			
        }
        .table_atas td{
            font-size: 11px;
        }
        .tabel_bawah{ 
            
            border-width: 0px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;            
            width:100%;
        }
        .tabel_bawah td{ 
			font-size: 5.5pt;
            padding: 0.2em;
            vertical-align: top;
            border-width: 1px;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            width:auto;
        }
         .tabel_bawah th{ 
            color: #000;
            font-size: 6.5pt;
            text-transform: uppercase;
            text-align: left;
            padding: 0.2em;
            border-width: 1px;
            border-bottom: 1px solid #000;
            border-style: solid;
            border-color: #333;
            border-collapse: collapse;
            background-color: #FFF;
        }
        .kepala_sj{
			text-align: center;
			padding: 5px;
			border-bottom: 3px double #000;
		}
		.nm_cv{
			font-weight: bold;
			font-size: 18px;
		}
		.cv_desc{
			font-weight: bold;
			font-size: 11px;
		}
		.cv_jalan{
			font-size: 10px;
		}
		/**
		p{
			width:1px;
			word-wrap: break-word;
		}
		**/
		.table_komisi{
			border: 0px solid #000;
		}
		.table_komisi td{
			border: 0px solid #000;
			padding: 0.2em;
			border-collapse: collapse;
		}
    </style>
</head>
<body onLoad="window.print();">
    <div class="box_tiket2">	
		<div class="kepala_sj">
			<div class="nm_cv">PT. INTRA</div>
			<div class="cv_desc">ANGKUTAN BUS UMUM</div>
			<div class="cv_jalan">Kantor Pusat: Jl. Sisingamangara No. 194. Telp: 24701 Fax: 430240</div>
			<div class="cv_kota">Pematang Siantar</div>
		</div>
        
    <?php
        error_reporting(0);
        date_default_timezone_set("Asia/Bangkok");
        require_once __DIR__."/Class/ConfigApp.php";
		
		$adm_kantor = str_replace(".", "", $_GET['admktr']);
		$adm_tiket  = str_replace(".", "", $_GET['admtkt']);
		
        $id_tiket = $_GET['id'];
		if($_GET['no_save'] == "true"){
			$sql = "SELECT * FROM _tbl_jadwal WHERE id='$id_tiket' ORDER BY id DESC";
		}
		else{
			$sql = "SELECT * FROM _tbl_jadwal WHERE id='$id_tiket' AND status='0' ORDER BY no_kursi ASC";
		}
		$h   = mysql_query($sql);
        $r   = mysql_fetch_array($h);

        $no_plat	 = $r['no_plat'];
		$nm_supir 	 = $r['nm_supir'];
		$j_berangkat = $r['jam_berangkat'];
		$berangkat   = explode("-", $r['tgl_berangkat']);
		$thn         = $berangkat[0];
		$bln         = $berangkat[1];
		$tglnya      = $berangkat[2];
		$t_berangkat = $tglnya."/".$bln."/".$thn;
		$dari        = $r['dari'];
		$tujuan      = $r['tujuan'];
        echo "
                <table class='tabel_atas'>
					<tr>
                        <td style='padding-left: 10px; width: 60px;'></td>
						<td></td>
						<td rowspan='4' style='width: 200px;'>&nbsp;</td>
						<td style='padding-left: 10px; width: 90px;'>NAMA SUPIR</td>
						<td>: $nm_supir</td>
                    </tr>
                    <tr>
                        <td style='padding-left: 10px;'>B K</td>
						<td>: $no_plat</td>
						
						<td style='padding-left: 10px;'>TANGGAL</td>
						<td>: $t_berangkat</td>
                    </tr>
                    
					<tr>
                        <td style='padding-left: 10px;'>TRIP</td>						
						<td>: </td>
						
						<td style='padding-left: 10px;'>DARI</td>						
						<td>: $dari</td>
                    </tr>
					
					<tr>
                        <td style='padding-left: 10px;'>JAM</td>
						<td>: $j_berangkat WIB</td>
						
						<td style='padding-left: 10px;'>KE</td>
						<td>: $tujuan</td>
                    </tr>
                    
                </table>
				<h3>SURAT JALAN</h3>
                <table class='tabel_bawah'>
                    <thead>
                        <tr>
                            <th style='width: 70px; text-align: center;'>BANGKU</th>
                            <th style='width: 160px;'>NAMA</th>                            
                            <th style='width: 130px;'>DARI</th>
							<th style='width: 190px;'>TUJUAN</th>
							<th style='width: 18px; text-align: center;'>ORG</th>								
							<th style='width: 90px; text-align: right;'>ONGKOS</th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
                $query = "SELECT * FROM _tbl_tiket WHERE kd_jadwal='".$r['id']."' GROUP BY nm_penumpang ORDER BY no_bangku ASC";				
				$hasil = mysql_query($query);
				$no = 0;				
				$jum_penumpang = mysql_fetch_array(mysql_query("SELECT COUNT(nm_penumpang) AS JUMLAH_PENUMPANG FROM _tbl_tiket WHERE kd_jadwal='".$r['id']."'"));
				while($row = mysql_fetch_array($hasil)){					
					$no++;					
					if($row['is_multi'] == "Y"){
						$no_bangku_penumpang = $row['no_bangku_multi'];
						$nomor = explode(',', $row['no_bangku_multi']);
						$jum_kursi           = count($nomor);
						$ongkos_tiket        = $jum_kursi * $row['harga_tiket'];
						$j_p                 = $jum_kursi;
					}
					else{
						$no_bangku_penumpang = $row['no_bangku'];
						$ongkos_tiket        = $row['harga_tiket'];
						$j_p                 = "1";
					}
                    echo "
						<tr>
						    <td><center>".$no_bangku_penumpang."</center></td>
							<td class='user-avatar'>".$row['nm_penumpang']."</td>							
							<td>$dari</td>
							<td>".$row[tujuan]."</td>
							<td style='text-align: center;'>$j_p</td>							
							<td style='text-align: right;'>Rp. ".number_format($ongkos_tiket, 0, ",", ".")."</td>
						</tr>						
						";
					//$total += $row['harga_tiket'];
					$total += $ongkos_tiket;
                }
				
				
				
				$admktr = $_GET['admktr'];
				$admtkt = $_GET['admtkt'];
				
				
                $jum = mysql_fetch_array(mysql_query("SELECT COUNT(nm_penumpang) AS JUM FROM _tbl_tiket WHERE kd_jadwal='".$r['id']."'"));
				$pisah_ktr = explode(",", $admktr);
				$h_ktr     = $pisah_ktr[0];
				
				$pisah_titik_ktr = explode(".", $h_ktr);
				$hasil_ktr       = $pisah_titik_ktr[0].$pisah_titik_ktr[1];
				
				$pisah_tkt = explode(",", $admtkt);
				$h_tkt     = $pisah_tkt[0];
				
				$pisah_titik_tkt = explode(".", $h_tkt);
				$hasil_tkt       = $pisah_titik_tkt[0].$pisah_titik_tkt[1];
				
				
				
				
            echo "</tbody>
			      <tr>
                    <th colspan='4' style='text-align: right; border-left: 1px solid #000;'>Jumlah Penumpang</th>
                    <th style='width: 100px; border-right: 1px solid #000;' colspan='3'>&nbsp; &nbsp; &nbsp; &nbsp;$jum_penumpang[JUMLAH_PENUMPANG] Orang</th>						
                  </tr>";
				$sqlPaket = "SELECT * FROM _tbl_paket WHERE kd_jadwal='$r[id]'";
				$resPaket = mysql_query($sqlPaket);
				$cekPaket = mysql_num_rows($resPaket);
				if($cekPaket > 0){
					echo "
						<tr>
						    <td colspan='6'>
								PAKET/BARANG
							</td>
						</tr>
				     ";
					$noPcs = 0;
					while($rPaket = mysql_fetch_array($resPaket)){
						$noPcs++;
						echo "<tr>
								<td colspan='4'>- $rPaket[nm_barang]</td>
								<td>1 $rPaket[satuan]</td>
								<td style='text-align: right;'>Rp. ".number_format($rPaket['biaya'], 0, ".", ".")."</td>
						      </tr>
						      ";
						$totalPaket += $rPaket['biaya'];
						
					}
					
					
					$newTotal   = $total + $totalPaket;
					//$komisi   = 10 * $total/100;
					$newkomisi  = 10 * $newTotal/100;
					//$grandTotal = $komisi + $hasil_ktr + $hasil_tkt;
					$grandTotal = $newkomisi + $hasil_ktr + $hasil_tkt;
					$finalTotal = $newTotal - $grandTotal;
					
					echo "
							<tr>
								<td colspan='4'>$rPaket[nm_barang]</td>
								<td> $noPcs Item</td>
								<td style='text-align: right;'>Rp. ".number_format($totalPaket, 0, ".", ".")."</td>
							</tr>
					     ";
				}
				else{
					$newTotal   = $total + $totalPaket;
					//$komisi   = 10 * $total/100;
					$newkomisi  = 10 * $newTotal/100;
					//$grandTotal = $komisi + $hasil_ktr + $hasil_tkt;
					$grandTotal = $newkomisi + $hasil_ktr + $hasil_tkt;
					$finalTotal = $newTotal - $grandTotal;
				}
			echo "
				  <tr>
                    <th colspan='4' style='text-align: right; border-left: 0px solid #000;'>&nbsp;</th>
                    <th style='width: 100px; border-right: 0px solid #000;' colspan='4'>
						<table class='table_komisi'>
							<tr>
								<td style='width: 20px;'>KOMISI</td><td style='text-align: right;'>: Rp. ".number_format($newkomisi, 0, ".",".")."</td>
							</tr>
							<tr>
								<td>AD/KTR</td><td style='text-align: right;'>: Rp. $h_ktr</td>
							</tr>
							<tr>
								<td>TIKET</td><td style='text-align: right;'>: Rp. $h_tkt</td>
							</tr>
							<tr>
								<td>JUMLAH</td><td style='text-align: right;'>: <span style='text-align: right;'>Rp. ".number_format($grandTotal, 0, ".", ".")."</span></td>
							</tr>
						</table>
					</th>						
                  </tr>
				  <tr>
                    <th colspan='4' style='text-align: right; border-left: 0px solid #000;'>Jumlah Bersih</th>
                    <th style='width: 100px; border-right: 0px solid #000; text-align: right;' colspan='4'>Rp. ".number_format($finalTotal, 0, ",", ".")."</th>						
                  </tr>
                </table>
                <table class='table_komisi' style='width: 100%; text-align: center; margin-top: 40px;'>
					<tr>
						<td style='width: 32%; font-size: 10px;'>
						 Yang menerima,
						 <br />
						 <br />
						 <br />
						 (________________________)
						</td>
						<td style='width: 32%; font-size: 10px;'>
						 Yang menyerahkan,
						 <br />
						 <br />
						 <br />	
						 (________________________)
						</td>
						<td style='width: 32%; font-size: 10px;'>
						 Disetujui,
						 <br />
						 <br />
						 <br />
						 (________________________)
						</td>
					</tr>
				</table>
				<p style='font-family: Lucida Calligraphy; text-align: center; font-size: 10px;'>
					\"Utamakan Keselamatan\"
				</p>
             ";
		if($_GET['no_save']=="true"){
			mysql_query("INSERT INTO _tbl_hissj SET kd_jadwal='$r[id]', tgl='$r[tgl_berangkat]', user='$_SESSION[user_id]', adm_kantor='".$adm_kantor."', adm_tiket='".$adm_tiket."'");
			mysql_query("UPDATE _tbl_jadwal SET status='1' WHERE id='$id_tiket'");
		}
		else{
			//mysql_query("INSERT INTO _tbl_hissj SET kd_jadwal='$r[id]', tgl='$r[tgl_berangkat]', user='$_SESSION[user_id]', adm_kantor='".$adm_kantor."', adm_tiket='".$adm_tiket."'");
			//mysql_query("UPDATE _tbl_jadwal SET status='1' WHERE id='$id_tiket'");
		}
?>
</div>
</body>
</html>
