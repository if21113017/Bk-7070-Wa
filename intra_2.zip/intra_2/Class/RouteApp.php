<?php
	require_once __DIR__."/ConfigApp.php";
	class RouteApp extends ConfigApp{
		
		public function setContent(){
			error_reporting(0);
			$mod = $_GET['mod'];
			if(isset($mod)){
				include "$mod".".php";
			}
			else{
				include "homePage.php";				
			}
		}
		
	}