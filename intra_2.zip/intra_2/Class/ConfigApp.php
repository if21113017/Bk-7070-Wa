<?php
	/**
	 *  Class untuk koneksi database
	 *  @Author  : Aminul Aprijal <dev.aprijal@gmail.com>
	 *  @Version : 1.0.1
	 **/
	require_once __DIR__."/SecureApps.php";
	Class ConfigApp extends SecureApps {

		private $db_host = "127.0.0.1";
		private $db_user = "root";
		private $db_pass = "";
		private $db_name = "_db_appstiket_092018";

		private $con 		= false;
		private $result 	= array();
		private $myQuery 	= "";
		private $numResults = "";

		private $url_host   = "http://localhost/intra_2/";
		private $url_auth   = "http://localhost/intra_2/Auth/";

		public function setHost($uri_api){
			return $this->url_host.$uri_api;
		}

		public function getHost(){
			return $this->url_host;
		}
		public function setLevel($userLevel){
			if($userLevel == "1"){
				$level	= "Superuser";
			}
			elseif($userLevel == "2"){
				$level	= "Administrator";
			}
			elseif($userLevel == "3"){
				$level	= "Tiketing";
			}
			return $level;
		}

		public function setPasswd($data){
			$makeSecure = md5($data);
			return $makeSecure;
		}
		public function urlGet_old(){
				if(isset($_GET['mod'])){
					$uri = explode("&", $_SERVER["QUERY_STRING"]);
					$jumlah = count($uri);
					for($jum=1;$jum<=$jumlah;$jum++){
						$resURI .= $uri[$jum]."&";
					}
					echo rtrim($resURI, "&");
				}
				else{
					echo $_SERVER["QUERY_STRING"];
				}
		}

		public function urlGet(){
			$uri_temp = $_SERVER['HTTP_REFERER'];
			return $uri_temp;
		}
		public function urlGetO(){
				if(isset($_GET['mod'])){
					$uri = explode("&", $_SERVER["QUERY_STRING"]);
					$jumlah = count($uri);
					for($jum=1;$jum<=$jumlah;$jum++){
						$resURI .= $uri[$jum]."&";
					}
					return rtrim($resURI, "&");
				}
				else{
					return $_SERVER["QUERY_STRING"];
				}
		}
		/**
		 * Fungsi koneksi ke Server Database <MySQL>
		 * Terlebih dahulu setting config diatas
		 **/
		public function AppKoneksi(){
			if(!$this->con){
				$myconn = @mysql_connect($this->db_host,$this->db_user,$this->db_pass);
				@mysql_set_charset('utf8', $myconn);
				if($myconn){
					$seldb = @mysql_select_db($this->db_name,$myconn);
					if($seldb){
						$this->con = true;
						return true;
					}else{
						array_push($this->result,mysql_error());
						return false;
					}
				}else{
					array_push($this->result,mysql_error());
					return false;
				}
			}else{
				return true;
			}
		}

		/**
		 * Fungsi diskoneksi ke Server Database <MySQL>
		 *
		 **/
		public function AppDiskoneksi(){
			if($this->con){
				if(@mysql_close()){
					$this->con = false;
					return true;
				}else{
					return false;
				}
			}
		}

		/**
		 * Query SQL <SELECT>
		 **/
		public function AppSql($sql){
			$query = @mysql_query($sql);
			$this->myQuery = $sql;
			if($query){
				$this->numResults = mysql_num_rows($query);
				for($i = 0; $i < $this->numResults; $i++){
					$r = mysql_fetch_array($query);
					$key = array_keys($r);
					for($x = 0; $x < count($key); $x++){
						if(!is_int($key[$x])){
							if(mysql_num_rows($query) >= 1){
								$this->result[$i][$key[$x]] = $r[$key[$x]];
							}else{
								$this->result = null;
							}
						}
					}
				}
				return true;
			}else{
				array_push($this->result,mysql_error());
				return false;
			}
		}


		/**
		 * Funsgi Query SQL <SELECT, JOIN TABLE>
		 **/
		public function selectData($table, $rows = '*', $join = null, $where = null, $order = null, $limit = null){
			$q = 'SELECT '.$rows.' FROM '.$table;
			if($join != null){
				$q .= ' JOIN '.$join;
			}
			if($where != null){
				$q .= ' WHERE '.$where;
			}
			if($order != null){
				$q .= ' ORDER BY '.$order;
			}
			if($limit != null){
				$q .= ' LIMIT '.$limit;
			}
			$this->myQuery = $q;
			if($this->tableExists($table)){
				$query = @mysql_query($q);
				if($query){
					$this->numResults = mysql_num_rows($query);
					for($i = 0; $i < $this->numResults; $i++){
						$r = mysql_fetch_array($query);
						$key = array_keys($r);
						for($x = 0; $x < count($key); $x++){
							if(!is_int($key[$x])){
								if(mysql_num_rows($query) >= 1){
									$this->result[$i][$key[$x]] = $r[$key[$x]];
								}else{
									$this->result = null;
								}
							}
						}
					}
					return true;
				}else{
					array_push($this->result,mysql_error());
					return false;
				}
			}else{
				return false;
			}
		}


		/**
		 * Fungsi INSERT DATA <SQL TABLE>
		 *
		 **/
		public function insertData($table, $params=array()){
			if($this->tableExists($table)){
				$sql='INSERT INTO `'.$table.'` (`'.implode('`, `',array_keys($params)).'`) VALUES ("' . implode('", "', $params) . '")';
				$this->myQuery = $sql;
				if($ins = @mysql_query($sql)){
					array_push($this->result,mysql_insert_id());
					return true;
				}else{
					array_push($this->result,mysql_error());
					return false;
				}
			}else{
				return false;
			}
		}


		/**
		 * Fungsi DELETE DATA <SQL TABLE>
		 * $where = null --> Bisa menghapus Table secara langsung
		 **/
		public function deleteData($table, $where = null){
			if($this->tableExists($table)){
				if($where == null){
					$delete = 'DROP TABLE '.$table;
				}else{
					$delete = 'DELETE FROM '.$table.' WHERE '.$where;
				}
				if($del = @mysql_query($delete)){
					array_push($this->result,mysql_affected_rows());
					$this->myQuery = $delete;
					return true;
				}else{
					array_push($this->result,mysql_error());
					return false;
				}
			}else{
				return false;
			}
		}

		/**
		 * Fungsi UPDATE DATA <SQL TABLE>
		 *
		 **/
		public function updateData($table, $params = array(), $where){
			if($this->tableExists($table)){
				$args=array();
				foreach($params as $field=>$value){
					$args[]=$field.'="'.$value.'"';
				}
				$sql='UPDATE '.$table.' SET '.implode(',',$args).' WHERE '.$where;
				$this->myQuery = $sql;
				if($query = @mysql_query($sql)){
					array_push($this->result,mysql_affected_rows());
					return true;
				}else{
					array_push($this->result,mysql_error());
					return false;
				}
			}else{
				return false;
			}
		}


		private function tableExists($table){
			$tableInDB = @mysql_query('SHOW TABLES FROM '.$this->db_name.' LIKE "'.$table.'"');
			if($tableInDB){
				if(mysql_num_rows($tableInDB)==1){
					return true;
				}
				else{
					array_push($this->result,$table." tidak ada didatabase!");
					return false;
				}
			}
		}

		public function getResult(){
			$val = $this->result;
			$this->result = array();
			return $val;
		}


		public function getSql(){
			$val = $this->myQuery;
			$this->myQuery = array();
			return $val;
		}


		public function numRows(){
			$val = $this->numResults;
			$this->numResults = array();
			return $val;
		}


		public function escapeString($data){
			return mysql_real_escape_string($data);
		}

		public function redirectPage($uri){
			if($uri=="sukses"){
				$header_response = "../apps.php?view=home";
			}
			elseif($uri=="attempt"){
				$header_response = "Auth/?msg=msg_attempt";
			}
			elseif($uri=="fail"){
				$header_response = $this->url_auth."?msg=msg_fail";
			}
			elseif($uri=="sig_out"){
				$header_response = $this->url_auth."?msg=msg_sukses";
			}
			elseif($uri=="index"){
				$header_response = $this->url_auth;
			}
			return header("location:$header_response");
		}

		public function linkActive($link){
			$link_segment = $_GET['mod'];
			if($link = $link_segment){
				$status = "class='active'";
			}
			else{
				$status = "";
			}
			return $status;
		}

		public function cekKursi($nomor, $id){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, `status` FROM _tbl_jadwal WHERE id='$id'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);			
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";

				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function cekKursiASLI($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='non_ac_biasa' AND no_plat='".$_GET['nomor']."' AND jam_berangkat='".$_GET['jam_sel']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function cekKursi_AC($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='non_ac_toilet' AND no_plat='".$_GET['plut_num_eko_41']."' AND jam_berangkat='".$_GET['jam_sel']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function cekKursi_AC41($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='ac_toilet_22_41' AND no_plat='".$_GET['plut_num_ac_41']."' AND jam_berangkat='".$_GET['jam_sel']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}


		public function cekKursi_AC32($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='ac_toilet_22_32' AND no_plat='".$_GET['plut_num_ac_32']."' AND jam_berangkat='".$_GET['jam_sel']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function cekKursi_AC36($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='ac_toilet_22_36' AND no_plat='".$_GET['plut_num_ac_36']."' AND jam_berangkat='".$_GET['jam_sel']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function cekKursi_AC25($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='ac_toilet_21_25' AND no_plat='".$_GET['plut_num_ac_25']."' AND jam_berangkat='".$_GET['jam_sel']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function cekKursi_AC23($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='ac_toilet_21_23' AND no_plat='".$_GET['plut_num_ac_23']."' AND jam_berangkat='".$_GET['jam_sel']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function cekKursi_SE18($nomor){
			$sekarang = date("Y-m-d");
			$cek_sj   = "SELECT id, status FROM _tbl_jadwal WHERE tgl_berangkat='".date('Y-m-d')."' AND `status`='0' AND kd_bus='ac_toilet_21_18' AND no_plat='".$_GET['plut_num_se_18']."'";
			$has      = mysql_query($cek_sj);
			$xrow     = mysql_fetch_array($has);
			if($xrow['status'] == "0"){
				$perintah = "SELECT no_bangku FROM _tbl_tiket WHERE no_bangku='".$nomor."' AND date_modify='".$sekarang."' AND kd_jadwal='$xrow[id]'";
				$hasil    = mysql_query($perintah);
				$ada      = mysql_num_rows($hasil);
				if($ada > 0){
					$terisi = "ADA";
				}
				else{
					$terisi = "";
				}
				return $terisi;
			}
			else{

			}
		}

		public function setURIAccess(){
			$nomor 		     = str_replace(" ", "%20", $_GET['nomor']);
			$plut_num_ac_41	 = str_replace(" ", "%20", $_GET['plut_num_ac_41']);
			$plut_num_eko_41 = str_replace(" ", "%20", $_GET['plut_num_eko_41']);
			$plut_num_ac_36  = str_replace(" ", "%20", $_GET['plut_num_ac_36']);
			$plut_num_ac_32  = str_replace(" ", "%20", $_GET['plut_num_ac_32']);
			$plut_num_ac_25  = str_replace(" ", "%20", $_GET['plut_num_ac_25']);
			$plut_num_ac_23	 = str_replace(" ", "%20", $_GET['plut_num_ac_23']);

			$view    = $_GET['view'];
			$uriSave = $this->url_host."apps.php?mod=welcomeApp&view=".$view."&".$view."=active&menu=false&nomor=".$nomor."&plut_num_ac_41=".$plut_num_ac_41."&plut_num_eko_41=".$plut_num_eko_41."&plut_num_ac_36=".$plut_num_ac_36."&plut_num_ac_32=".$plut_num_ac_32."&plut_num_ac_25=".$plut_num_ac_25."&plut_num_ac_23=".$plut_num_ac_23;
			return $uriSave;
		}




	}


	/**
	 * Koneksi Ke Server Database MySQL
	 *
	 **/
	 $App = new ConfigApp();
	 $App->AppKoneksi();
?>
