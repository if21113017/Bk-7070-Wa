<?php	
	Class SecureApps {
		public $izin_akses;
		
		public function __construct(){			
			/**
			if($izin_akses == 1){
				
			}
			else{
				exit("Error load modul");
			}
			**/
		}
	}