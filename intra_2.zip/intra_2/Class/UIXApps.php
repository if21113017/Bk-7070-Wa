<?php
	Class UIXApps {
		public $icons;
		public $titles;
		public $cols;
		
		public function openHTML(){
			$oHTML = "<!DOCTYPE html>
						<html lang='en'>
							<head>
							
					 ";
			echo $oHTML;
		}
		
		public function closeHTML(){
			$cHTML = "
						</html>
			         ";
			echo $cHTML;
		}
		
		
		
		/* Buat Cols */
		public function createCols($cols_type, $cols_width){			
			$cCols = "
						<div class='cols-".$cols_type."-".$cols_width."'>
			         ";
			echo $cCols;
		}
		
		public function closeDiv(){
			$divs = "</div>";
			echo $divs;
		}
		/* Tutup Tag Cols */
		
		public function createPanel($panel_style, $panel_border=null, $panel_border_color=null, $panel_contrast=null){
			/**
			 * Contoh Properties CreatePanel:
			 * $panel_border = panel-border-color | $panel_border_color = panel-border-color-primary | $panel_contrast = panel-contrast			 
			 **/
			$cPanel = "
						<div class='panel ".$panel_style." ".$panel_border." ".$panel_border_color." ".$panel_contrast."'>
			          ";
			echo $cPanel;
		}

		public function createHeading($icons = null, $title = null, $panel_contrast = null){
			/**
			 * Contoh Properties CreateHeading:
			 * $icon = icon mdi mdi-home | $title = Judul | $panel_contrast = panel-contrast			 
			 **/
			$heading = "
							<div class='panel-heading ".$panel_contrast."'><i class='".$icons."'></i> ".$title."</div>
			           ";
			echo $heading;
		}
		
		public function createBody(){
			$cBody  = "
						<div class='panel-body'>
			          ";
			echo $cBody;
		}
		
				
	}