<?php
	require_once "Class/ConfigApp.php";
	$apps = new ConfigApp();
	
	$tmp_kursi = explode(',', $_POST['tmp_kursi_book']);
    $jum_kursi = count($tmp_kursi);
	$alamat         = $_POST['txtAlamat'];
    $txtNoHp        = $_POST['txtNoHp'];	
	$date_modif     = date("Y-m-d");
	
	$tujuan_book	= $_POST['tujuanTemp'];
	$dari_book      = $_POST['dariTemp'];
	
	$tgl_book    	= $_POST['tglTemp'];
	$jam_book	    = $_POST['jamTemp'];	
	$class_bus_book	= $_POST['busTemp'];
		
	$lunas_panjar 	 = $_POST['txtpanjar_lunas'];
	$tot_ongkos_book = $_POST['txtOngkosBooking'];
	$ongkos_sisa	 = $_POST['txtOngkosSisa'];
	$kode_book		 = $_POST['kodeTemp'];
	
	if($lunas_panjar == $tot_ongkos_book){
		$sts_book   = "Lunas";
	}
	else{
		$sts_book   = "Panjar";
	}
	
	$n = 0;
    for($i=0; $i<=$jum_kursi; $i++){
		$n++;
		
		$nm_penumpang    = mysql_real_escape_string(strtoupper($_POST['txtNamaPenumpang_'.$tmp_kursi[$i]]));
        $kursi_penumpang = $tmp_kursi[$i];
        $HargaTiketPen	 = $_POST['txtOngkos_'.$kursi_penumpang];	
		
		if($nm_penumpang == ""){

        }
        else{
			$sql_tiket_book  = "
							  INSERT INTO 
								_tbl_booking 
							  SET
								kd_booking='".$kode_book."',
								tipe_bus='".$class_bus_book."',
								no_bangku='".$kursi_penumpang."',
								nm_penumpang='".$nm_penumpang."',
								alamat='".$alamat."',
								no_hp='".$txtNoHp."',
								dari='".$dari_book."',
								tujuan='".$tujuan_book."',
								harga_tiket='".$HargaTiketPen."',
								tot_hargatiket='".$tot_ongkos_book."',
								tgl_booking='".$tgl_book."',
								jam_booking='".$jam_book."',
								user_modify='Superuser',
								date_modify='".$date_modif."',
								sts_ongkos='".$sts_book."',
								panjar='".$lunas_panjar."',
								sisa='".$ongkos_sisa."',
								no_bangku_multi='".$_POST['tmp_kursi_book']."'
		                     ";
		
		
			$sql_kursi_temp  = "
								INSERT INTO 
									_tbm_tempkursi_booking
								SET
									kd_booking='".$kode_book."',
									kursi_num='".$kursi_penumpang."',
									tgl_booking='".$tgl_book."',
									jam_booking='".$jam_book."',
									tujuan='".$tujuan_book."',
									dari='".$dari_book."',
									tipe_bus='".$class_bus_book."'
			                   ";
                        /*$sql_add_jadwal =" INSERT INTO 
                                                    _tbl_jadwal
                                           SET 
                                                    kd_bus='".$class_bus_book."',
                                                    jam_berangkat='".$jam_book."', jam_berangkat=".$tgl_book."', harga_tiket
                                         ";
			*/
			mysql_query($sql_tiket_book);
			mysql_query($sql_kursi_temp);
			
			//var_dump($sql_tiket_book);			
			//var_dump($sql_kursi_temp);
		}
	}