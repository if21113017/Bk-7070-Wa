<?php
    session_start();
    date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();

    $id_jadwal      = $_POST['txt_idhide'];
    $no_bangku      = $_POST['txtNoKursi'];
    $nm_penumpang   = strtoupper($_POST['txtNamaPenumpang']);
    $alamat         = strtoupper($_POST['txtAlamat']);
    $no_hp          = $_POST['txtNoHp'];
    $harga_tiket    = $_POST['txtOngkos'];
    $date_modif     = date("Y-m-d");

    $data = array(
        'kd_jadwal'     => $id_jadwal,
        'no_bangku'     => $no_bangku,
        'nm_penumpang'  => $nm_penumpang,
        'alamat'        => $alamat,
        'no_hp'         => $no_hp,
        'harga_tiket'   => $harga_tiket,
        'user_modify'   => '',
        'date_modify'   => $date_modif
    );


    $apps->insertData('_tbl_tiket', $data);
    $response = json_encode($data);
    echo $response;