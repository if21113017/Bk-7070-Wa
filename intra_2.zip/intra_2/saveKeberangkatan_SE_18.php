<?php
	session_start();
	date_default_timezone_set("Asia/Bangkok");
    require_once __DIR__."/Class/ConfigApp.php";
    $apps = new ConfigApp();
    $plat          = strtoupper($_POST['txtplat_SE_18']);
    $supir         = $_POST['txtnmsupir_SE_18'];
    $tgl_berangkat = explode("/", $_POST['txttgl_se_18']);
    $tahun         = $tgl_berangkat[2];
    $bulan         = $tgl_berangkat[1];
    $tgl           = $tgl_berangkat[0];
    $concat_tgl    = $tahun."-".$bulan."-".$tgl;
    $jam_berangkat = $_POST['txtjam_se_18'];    
    $tujuan_temp   = $_POST['txttujuan_se_18'];
	$date_modif     = date("Y-m-d");
	
    $tmp_jum_kursi = $_POST['tmp_jum_kursi_se_18'];

    $from_to       = mysql_fetch_array(mysql_query("SELECT * FROM _tbl_harga_tiket WHERE id='$tujuan_temp'"));
    $pecah_from_to = explode("-", $from_to['tujuan']);

    $dari          = strtoupper($pecah_from_to[0]);
    $tujuan        = strtoupper($pecah_from_to[1]);
	$nomor         = explode("-", $plat);
    $data_new = array(
                'id_tujuan'     => $from_to['id'],
                'kd_bus'        => "ac_toilet_21_18",
                'no_plat'       => strtoupper($nomor[0]),
                'nm_supir'      => strtoupper($supir),
                'jam_berangkat' => $jam_berangkat,
                'tgl_berangkat' => $concat_tgl,
                'dari'          => $dari,
                'tujuan'        => $tujuan,
                'harga_tiket'   => $from_to['harga'],
                'status'        => '0'
            );

    $sql   = $apps->insertData('_tbl_jadwal', $data_new);    
	$id_tm = mysql_insert_id();
    for($x=1; $x<=$tmp_jum_kursi; $x++){
        $tmp_data = "INSERT INTO 
                        _tbm_tempkursi 
                     SET 
                        id_jadwal='$id_tm',
                        no_plat='".strtoupper($nomor[0])."', 
                        kursi_num='".$x."', 
                        tgl_berangkat='".$concat_tgl."',
                        jam_berangkat='$jam_berangkat',
                        sts_kursi='0'";
       mysql_query($tmp_data);
    }
	
	$cek  = "SELECT * FROM _tbl_booking WHERE tgl_booking='$concat_tgl' AND jam_booking='$jam_berangkat' AND tipe_bus='ac_toilet_21_18' AND sts_ongkos='Lunas'";
	$hcek = mysql_query($cek);
	$ada  = mysql_num_rows($hcek);
	if($ada > 0){
		while($rows = mysql_fetch_array($hcek)){
			$kode        = $rows['kd_booking'];	
			$saveToTiket = "INSERT INTO 
								_tbl_tiket 
							SET
								kd_bus='$rows[tipe_bus]',
								kd_jadwal='$id_tm',
								no_bangku='$rows[no_bangku]',
								nm_penumpang='$rows[nm_penumpang]',
								alamat='$rows[alamat]',
								no_hp='$rows[no_hp]',
								dari='$rows[dari]',
								tujuan='$rows[tujuan]',
								harga_tiket='$rows[harga_tiket]',
								user_modify='$_SESSION[namauser]',
								date_modify='$date_modif'";
			
			$delFromBook  = "DELETE FROM _tbl_booking WHERE kd_booking='$kode'";
			$delFromTemp  = "DELETE FROM _tbm_tempkursi_booking WHERE kd_booking='$kode'";
			$tmp_kursi    = "UPDATE _tbm_tempkursi SET sts_kursi='1' WHERE id_jadwal='$id_tm' AND kursi_num='$rows[no_bangku]'";
			mysql_query($saveToTiket);
			mysql_query($delFromBook);
			mysql_query($delFromTemp);
			mysql_query($tmp_kursi);
			//echo $delFromBook;
		}
	}
	else{
		
	}
	
	mysql_query("UPDATE _tbl_uri_temp SET uri=\"".$apps->urlGet()."\" WHERE id='1'");
	//echo json_encode($data_new);
    echo "OK";

